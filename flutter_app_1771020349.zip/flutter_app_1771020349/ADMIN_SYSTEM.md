# Hệ thống Admin - Restaurant App

## Tổng quan
Hệ thống admin được tách riêng hoàn toàn khỏi giao diện người dùng thông thường, cung cấp các chức năng quản lý toàn diện cho nhà hàng.

## Cách truy cập Admin
1. **Từ màn hình đăng nhập chính**: Nhấn vào biểu tượng admin (⚙️) ở góc trên bên phải
2. **Thông tin đăng nhập demo**:
   - Username: `admin`
   - Password: `admin123`

## Cấu trúc hệ thống Admin

### 1. Admin Provider (`lib/providers/admin_provider.dart`)
- Quản lý authentication riêng cho admin
- Kiểm tra quyền admin
- Hardcoded credentials cho demo

### 2. Admin Login Screen (`lib/screens/admin/admin_login_screen.dart`)
- Giao diện đăng nhập riêng cho admin
- Form validation
- Hiển thị thông tin đăng nhập demo
- UI/UX chuyên nghiệp với theme màu cam

### 3. Admin Dashboard (`lib/screens/admin/admin_dashboard_screen.dart`)
- Trang chủ admin với grid layout
- 4 module chính:
  - 👥 Quản lý khách hàng (màu xanh dương)
  - 🍽️ Quản lý thực đơn (màu xanh lá)
  - 📅 Quản lý đặt bàn (màu tím)
  - 📊 Thống kê (màu cam - coming soon)

## Chức năng CRUD hoàn chỉnh

### 1. Quản lý khách hàng (`manage_customers_screen.dart`)
**Chức năng:**
- ✅ **Create**: Thêm khách hàng mới
- ✅ **Read**: Xem danh sách và tìm kiếm khách hàng
- ✅ **Update**: Sửa thông tin khách hàng
- ✅ **Delete**: Xóa khách hàng

**Tính năng nâng cao:**
- Tìm kiếm theo tên, email, số điện thoại
- Lọc theo vai trò (khách hàng/admin)
- Cấp/hủy quyền admin
- Hiển thị badge admin
- Form validation đầy đủ

### 2. Quản lý thực đơn (`manage_menu_items_screen.dart`)
**Chức năng:**
- ✅ **Create**: Thêm món ăn mới
- ✅ **Read**: Xem danh sách và tìm kiếm món ăn
- ✅ **Update**: Sửa thông tin món ăn
- ✅ **Delete**: Xóa/ẩn món ăn

**Tính năng nâng cao:**
- Tìm kiếm theo tên và mô tả
- Lọc theo danh mục (Main Course, Appetizer, Soup, Beverage, Dessert)
- Quản lý trạng thái có sẵn/hết món
- Quản lý nguyên liệu
- Checkbox cho món chay/cay
- Quản lý giá, thời gian chế biến, đánh giá

### 3. Quản lý đặt bàn (`manage_reservations_screen.dart`)
**Chức năng:**
- ✅ **Read**: Xem tất cả đặt bàn
- ✅ **Update**: Cập nhật trạng thái đặt bàn
- ✅ **Confirm**: Xác nhận và gán bàn

**Tính năng nâng cao:**
- Lọc theo trạng thái (pending, confirmed, seated, completed, cancelled, no_show)
- Xem chi tiết khách hàng và món đã đặt
- Workflow quản lý: Chờ xác nhận → Xác nhận → Nhận bàn → Hoàn thành
- Gán số bàn khi xác nhận
- Hiển thị tổng tiền và chi tiết order

## Tích hợp với hệ thống chính

### 1. Main App (`lib/main.dart`)
- Thêm `AdminProvider` vào MultiProvider
- Tích hợp admin system vào app routing

### 2. Login Screen (`lib/screens/auth/login_screen.dart`)
- Thêm nút truy cập admin ở AppBar
- Thông tin hướng dẫn cho admin
- Navigation đến AdminLoginScreen

## Bảo mật
- Authentication riêng biệt cho admin
- Hardcoded credentials cho demo (có thể thay đổi thành database authentication)
- Kiểm tra quyền admin từ Firestore
- Session management riêng

## UI/UX Design
- **Theme màu**: Cam chủ đạo, màu phụ theo chức năng
- **Icons**: Material Design icons phù hợp
- **Layout**: Card-based design, responsive
- **Navigation**: Intuitive với back buttons và breadcrumbs
- **Feedback**: SnackBar notifications cho mọi action
- **Loading states**: CircularProgressIndicator khi cần

## Cấu trúc file
```
lib/
├── providers/
│   └── admin_provider.dart          # Admin authentication & state
├── screens/
│   ├── admin/
│   │   ├── admin_login_screen.dart      # Admin login
│   │   ├── admin_dashboard_screen.dart  # Admin dashboard
│   │   ├── manage_customers_screen.dart # Customer CRUD
│   │   ├── manage_menu_items_screen.dart # Menu CRUD
│   │   └── manage_reservations_screen.dart # Reservation management
│   └── auth/
│       └── login_screen.dart        # Updated with admin access
└── main.dart                        # Updated with AdminProvider
```

## Hướng dẫn sử dụng

### Đăng nhập Admin
1. Mở app → Màn hình đăng nhập
2. Nhấn biểu tượng ⚙️ ở góc trên phải
3. Nhập: username `admin`, password `admin123`
4. Nhấn "Đăng nhập"

### Quản lý khách hàng
1. Dashboard → "Quản lý khách hàng"
2. **Thêm**: Nhấn nút ➕ → Điền form → "Thêm"
3. **Sửa**: Menu ⋮ → "Sửa" → Cập nhật → "Cập nhật"
4. **Xóa**: Menu ⋮ → "Xóa" → Xác nhận
5. **Cấp quyền admin**: Menu ⋮ → "Làm admin"

### Quản lý thực đơn
1. Dashboard → "Quản lý thực đơn"
2. **Thêm món**: Nhấn nút ➕ → Điền đầy đủ thông tin → "Thêm"
3. **Sửa món**: Menu ⋮ → "Sửa" → Cập nhật → "Cập nhật"
4. **Ẩn/hiện món**: Menu ⋮ → "Ẩn món"/"Hiện món"
5. **Xóa món**: Menu ⋮ → "Xóa" → Xác nhận

### Quản lý đặt bàn
1. Dashboard → "Quản lý đặt bàn"
2. **Xác nhận đặt bàn**: Menu ⋮ → "Xác nhận" → Nhập số bàn → "Xác nhận"
3. **Nhận bàn**: Menu ⋮ → "Nhận bàn"
4. **Hủy đặt bàn**: Menu ⋮ → "Hủy"

## Tính năng sẽ phát triển
- [ ] Thống kê và báo cáo
- [ ] Quản lý nhân viên
- [ ] Quản lý kho
- [ ] Tích hợp thanh toán
- [ ] Notification system
- [ ] Export data
- [ ] Advanced analytics

## Kết luận
Hệ thống admin đã được tách riêng hoàn toàn với đầy đủ chức năng CRUD cho tất cả các entity chính. Giao diện thân thiện, dễ sử dụng và có thể mở rộng dễ dàng trong tương lai.