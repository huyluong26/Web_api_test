# Restaurant App - 2151061234

Ứng dụng Flutter quản lý nhà hàng với Firebase Firestore.

## Tính năng chính

### 🔐 Xác thực người dùng
- Đăng ký tài khoản khách hàng
- Đăng nhập bằng email
- Quản lý thông tin cá nhân
- Hệ thống điểm tích lũy

### 🍽️ Quản lý Menu
- Xem danh sách món ăn với hình ảnh
- Tìm kiếm món ăn theo tên, mô tả, nguyên liệu
- Lọc theo danh mục (Appetizer, Main Course, Dessert, Beverage)
- Lọc món chay, món cay
- Hiển thị trạng thái còn hàng/hết hàng
- Xem chi tiết món ăn với đầy đủ thông tin

### 📅 Đặt bàn
- Tạo đặt bàn mới với ngày giờ, số khách
- Thêm yêu cầu đặc biệt
- Thêm món ăn vào đơn hàng
- Tính toán tự động: tạm tính, phí phục vụ (10%), tổng cộng
- Xác nhận đặt bàn

### 💳 Thanh toán
- Áp dụng điểm tích lũy (1 điểm = 1,000đ, tối đa 50% tổng bill)
- Chọn phương thức thanh toán: tiền mặt, thẻ, online
- Tự động cộng điểm tích lũy (1% tổng bill)
- Cập nhật trạng thái đặt bàn

### 📋 Quản lý đặt bàn
- Xem danh sách đặt bàn của khách hàng
- Theo dõi trạng thái: chờ xác nhận, đã xác nhận, đã nhận bàn, hoàn thành
- Xem chi tiết từng đặt bàn
- Thanh toán trực tiếp từ ứng dụng

## Cấu trúc dự án

```
lib/
├── models/                 # Data models
│   ├── customer.dart
│   ├── menu_item.dart
│   ├── order_item.dart
│   └── reservation.dart
├── providers/              # State management
│   ├── auth_provider.dart
│   ├── menu_provider.dart
│   └── reservation_provider.dart
├── repositories/           # Data access layer
│   ├── customer_repository.dart
│   ├── menu_item_repository.dart
│   └── reservation_repository.dart
├── screens/               # UI screens
│   ├── auth/
│   ├── home/
│   ├── menu/
│   └── reservation/
├── services/              # External services
│   └── firebase_service.dart
├── utils/                 # Utilities
│   └── sample_data.dart
└── main.dart
```

## Cơ sở dữ liệu Firestore

### Collections:

1. **customers**
   - customerId, email, fullName, phoneNumber, address
   - preferences (Array), loyaltyPoints, createdAt, isActive

2. **menu_items**
   - itemId, name, description, category, price, imageUrl
   - ingredients (Array), isVegetarian, isSpicy, preparationTime
   - isAvailable, rating, createdAt

3. **reservations**
   - reservationId, customerId, reservationDate, numberOfGuests
   - tableNumber, status, specialRequests, orderItems (Array)
   - subtotal, serviceCharge, discount, total
   - paymentMethod, paymentStatus, createdAt, updatedAt

## Cài đặt và chạy

1. **Cài đặt dependencies:**
   ```bash
   flutter pub get
   ```

2. **Cấu hình Firebase:**
   - Tạo project Firebase mới
   - Thêm ứng dụng Android/iOS
   - Tải file `google-services.json` (Android) hoặc `GoogleService-Info.plist` (iOS)
   - Cập nhật `firebase_options.dart` với thông tin project

3. **Chạy ứng dụng:**
   ```bash
   flutter run
   ```

## Tài khoản test

Email: `test@example.com`
(Tạo tài khoản mới qua màn hình đăng ký)

## Ghi chú kỹ thuật

- **State Management:** Provider pattern
- **Database:** Firebase Firestore với real-time updates
- **Architecture:** Repository pattern với separation of concerns
- **UI:** Material Design 3 với theme màu cam
- **Error Handling:** Comprehensive error handling với user-friendly messages
- **Performance:** Lazy loading và caching cho optimal performance

## Tác giả

Sinh viên: 2151061234
Môn: Lập trình Mobile
Đề tài: Ứng dụng quản lý nhà hàng với Firebase
