# 🍽️ Restaurant App Setup Guide

## 📋 Tổng quan
Ứng dụng Flutter quản lý nhà hàng với Firebase Firestore, không cần tạo composite index.

## 🚀 Cách chạy ứng dụng

### 1. Cài đặt dependencies
```bash
flutter pub get
```

### 2. Chạy ứng dụng
```bash
flutter run
```

## 🔥 Firebase Setup

### 1. Tạo Firebase Project
1. Vào [Firebase Console](https://console.firebase.google.com)
2. Tạo project mới: `dbexam1771020349` (đã cấu hình)

### 2. Tạo Firestore Database
1. Vào **Firestore Database** → **Create database**
2. Chọn **Start in test mode**
3. Chọn location: `asia-southeast1`

### 3. Firestore Rules (Test mode)
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

## 📊 Collections sẽ được tạo tự động:
- `customers` - Thông tin khách hàng
- `menu_items` - Danh sách món ăn
- `reservations` - Đặt bàn

## 🎯 Tính năng chính

### 👤 Đăng ký/Đăng nhập
- Email: `test@example.com` (sẽ được tạo tự động)
- Hoặc đăng ký tài khoản mới

### 🍽️ Menu
- Xem danh sách món ăn
- Tìm kiếm và lọc
- Chi tiết món ăn

### 📅 Đặt bàn
- Tạo đặt bàn mới
- Thêm món vào đơn
- Tính toán tự động

### 💳 Thanh toán
- Áp dụng điểm tích lũy
- Chọn phương thức thanh toán
- Cập nhật điểm tự động

## 🔧 Architecture

### Repository Pattern
- `SimpleRepository` - Queries đơn giản, không cần index
- `BackupRepository` - Fallback khi có lỗi
- Client-side filtering và sorting

### State Management
- Provider pattern
- Real-time updates từ Firestore
- Error handling với fallback

## 🐛 Troubleshooting

### Lỗi Index
✅ **Đã giải quyết** - Sử dụng client-side filtering

### Lỗi Type Casting
✅ **Đã giải quyết** - Safe casting với null checks

### Lỗi Network
- Kiểm tra internet connection
- Kiểm tra Firestore rules

## 📱 Test Flow

1. **Khởi động app** → Xem logs Firebase connection
2. **Đăng ký** → Tạo tài khoản mới
3. **Xem menu** → Browse món ăn
4. **Đặt bàn** → Tạo reservation
5. **Thêm món** → Add items to order
6. **Thanh toán** → Complete payment

## 🎉 Features Completed

- ✅ Firebase integration
- ✅ Model classes với safe casting
- ✅ Repository pattern
- ✅ CRUD operations
- ✅ UI screens
- ✅ State management
- ✅ Real-time updates
- ✅ Error handling
- ✅ No index requirements

## 📞 Support

Nếu gặp lỗi, kiểm tra:
1. Console logs
2. Firestore rules
3. Network connection
4. Firebase project settings

**Mã sinh viên**: 2151061234
**Ứng dụng**: Restaurant Management với Firebase