import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/customer.dart';
import '../models/menu_item.dart';
import '../models/reservation.dart';
import '../services/firebase_service.dart';

/// Repository đơn giản không sử dụng composite queries
/// Tất cả filtering và sorting được thực hiện ở client side
class SimpleRepository {
  
  // === CUSTOMER METHODS ===
  
  static Future<String> addCustomer(Customer customer) async {
    try {
      DocumentReference docRef = await FirebaseService.customersCollection.add(customer.toFirestore());
      return docRef.id;
    } catch (e) {
      throw Exception('Lỗi khi thêm khách hàng: $e');
    }
  }

  static Future<Customer?> getCustomerById(String customerId) async {
    try {
      DocumentSnapshot doc = await FirebaseService.customersCollection.doc(customerId).get();
      if (doc.exists) {
        return Customer.fromFirestore(doc);
      }
      return null;
    } catch (e) {
      throw Exception('Lỗi khi lấy thông tin khách hàng: $e');
    }
  }

  static Future<Customer?> getCustomerByEmail(String email) async {
    try {
      // Lấy tất cả customers và filter ở client
      QuerySnapshot querySnapshot = await FirebaseService.customersCollection.get();
      
      for (var doc in querySnapshot.docs) {
        Customer customer = Customer.fromFirestore(doc);
        if (customer.email == email && customer.isActive) {
          return customer;
        }
      }
      return null;
    } catch (e) {
      throw Exception('Lỗi khi tìm khách hàng theo email: $e');
    }
  }

  static Future<void> updateCustomer(String customerId, Map<String, dynamic> updates) async {
    try {
      await FirebaseService.customersCollection.doc(customerId).update(updates);
    } catch (e) {
      throw Exception('Lỗi khi cập nhật khách hàng: $e');
    }
  }

  static Future<void> updateLoyaltyPoints(String customerId, int points) async {
    try {
      await FirebaseService.customersCollection.doc(customerId).update({
        'loyaltyPoints': FieldValue.increment(points),
      });
    } catch (e) {
      throw Exception('Lỗi khi cập nhật điểm tích lũy: $e');
    }
  }

  // === MENU ITEM METHODS ===

  static Future<String> addMenuItem(MenuItem menuItem) async {
    try {
      DocumentReference docRef = await FirebaseService.menuItemsCollection.add(menuItem.toFirestore());
      return docRef.id;
    } catch (e) {
      throw Exception('Lỗi khi thêm món ăn: $e');
    }
  }

  static Future<MenuItem?> getMenuItemById(String itemId) async {
    try {
      DocumentSnapshot doc = await FirebaseService.menuItemsCollection.doc(itemId).get();
      if (doc.exists) {
        return MenuItem.fromFirestore(doc);
      }
      return null;
    } catch (e) {
      throw Exception('Lỗi khi lấy thông tin món ăn: $e');
    }
  }

  static Future<List<MenuItem>> getAllMenuItems() async {
    try {
      QuerySnapshot querySnapshot = await FirebaseService.menuItemsCollection.get();
      
      List<MenuItem> items = querySnapshot.docs
          .map((doc) => MenuItem.fromFirestore(doc))
          .toList();
      
      // Sort ở client side
      items.sort((a, b) {
        int categoryCompare = a.category.compareTo(b.category);
        if (categoryCompare != 0) return categoryCompare;
        return a.name.compareTo(b.name);
      });
      
      return items;
    } catch (e) {
      throw Exception('Lỗi khi lấy danh sách món ăn: $e');
    }
  }

  static Future<List<MenuItem>> getAvailableMenuItems() async {
    try {
      QuerySnapshot querySnapshot = await FirebaseService.menuItemsCollection.get();
      
      List<MenuItem> allItems = querySnapshot.docs
          .map((doc) => MenuItem.fromFirestore(doc))
          .toList();
      
      // Filter available items ở client side
      List<MenuItem> availableItems = allItems.where((item) => item.isAvailable).toList();
      
      // Sort ở client side
      availableItems.sort((a, b) {
        int categoryCompare = a.category.compareTo(b.category);
        if (categoryCompare != 0) return categoryCompare;
        return a.name.compareTo(b.name);
      });
      
      return availableItems;
    } catch (e) {
      throw Exception('Lỗi khi lấy món ăn có sẵn: $e');
    }
  }

  // === RESERVATION METHODS ===

  static Future<String> createReservation(Reservation reservation) async {
    try {
      DocumentReference docRef = await FirebaseService.reservationsCollection.add(reservation.toFirestore());
      return docRef.id;
    } catch (e) {
      throw Exception('Lỗi khi tạo đặt bàn: $e');
    }
  }

  static Future<Reservation?> getReservationById(String reservationId) async {
    try {
      DocumentSnapshot doc = await FirebaseService.reservationsCollection.doc(reservationId).get();
      if (doc.exists) {
        return Reservation.fromFirestore(doc);
      }
      return null;
    } catch (e) {
      throw Exception('Lỗi khi lấy thông tin đặt bàn: $e');
    }
  }

  static Future<List<Reservation>> getReservationsByCustomer(String customerId) async {
    try {
      // Lấy tất cả reservations và filter ở client
      QuerySnapshot querySnapshot = await FirebaseService.reservationsCollection.get();
      
      List<Reservation> allReservations = querySnapshot.docs
          .map((doc) => Reservation.fromFirestore(doc))
          .toList();
      
      // Filter theo customerId ở client side
      List<Reservation> customerReservations = allReservations
          .where((reservation) => reservation.customerId == customerId)
          .toList();
      
      // Sort ở client side
      customerReservations.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      
      return customerReservations;
    } catch (e) {
      throw Exception('Lỗi khi lấy đặt bàn theo khách hàng: $e');
    }
  }

  static Future<void> updateReservation(String reservationId, Map<String, dynamic> updates) async {
    try {
      updates['updatedAt'] = Timestamp.fromDate(DateTime.now());
      await FirebaseService.reservationsCollection.doc(reservationId).update(updates);
    } catch (e) {
      throw Exception('Lỗi khi cập nhật đặt bàn: $e');
    }
  }

  // === STREAM METHODS (Simple versions) ===

  static Stream<List<MenuItem>> menuItemsStream() {
    return FirebaseService.menuItemsCollection.snapshots().map((snapshot) {
      List<MenuItem> items = snapshot.docs
          .map((doc) => MenuItem.fromFirestore(doc))
          .toList();
      
      // Sort ở client side
      items.sort((a, b) {
        int categoryCompare = a.category.compareTo(b.category);
        if (categoryCompare != 0) return categoryCompare;
        return a.name.compareTo(b.name);
      });
      
      return items;
    });
  }

  static Stream<List<Reservation>> customerReservationsStream(String customerId) {
    return FirebaseService.reservationsCollection.snapshots().map((snapshot) {
      List<Reservation> allReservations = snapshot.docs
          .map((doc) => Reservation.fromFirestore(doc))
          .toList();
      
      // Filter và sort ở client side
      List<Reservation> customerReservations = allReservations
          .where((reservation) => reservation.customerId == customerId)
          .toList();
      
      customerReservations.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      
      return customerReservations;
    });
  }
}