import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/reservation.dart';
import '../models/order_item.dart';
import '../models/menu_item.dart';
import '../services/firebase_service.dart';
import 'menu_item_repository.dart';
import 'customer_repository.dart';
import 'simple_repository.dart';

class ReservationRepository {
  final CollectionReference _reservationsRef = FirebaseService.reservationsCollection;
  final MenuItemRepository _menuItemRepository = MenuItemRepository();
  final CustomerRepository _customerRepository = CustomerRepository();

  // ===== RESERVATION REPOSITORY METHODS (14 điểm) =====

  /// 1. Đặt Bàn (5 điểm)
  Future<String> createReservation(
    String customerId,
    DateTime reservationDate,
    int numberOfGuests,
    String? specialRequests,
  ) async {
    try {
      // Kiểm tra không đặt trùng thời gian (optional)
      await _checkDuplicateReservation(customerId, reservationDate);

      Reservation reservation = Reservation(
        reservationId: '',
        customerId: customerId,
        reservationDate: reservationDate,
        numberOfGuests: numberOfGuests,
        specialRequests: specialRequests,
        status: 'pending', // Tạo với status = "pending"
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      DocumentReference docRef = await _reservationsRef.add(reservation.toFirestore());
      return docRef.id;
    } catch (e) {
      throw Exception('Lỗi khi đặt bàn: $e');
    }
  }

  /// 2. Thêm Món vào Đơn (3 điểm)
  Future<void> addItemToReservation(String reservationId, String itemId, int quantity) async {
    try {
      // Kiểm tra item isAvailable
      MenuItem? menuItem = await _menuItemRepository.getMenuItemById(itemId);
      if (menuItem == null || !menuItem.isAvailable) {
        throw Exception('Món ăn không có sẵn');
      }

      // Lấy reservation hiện tại
      DocumentSnapshot reservationDoc = await _reservationsRef.doc(reservationId).get();
      if (!reservationDoc.exists) {
        throw Exception('Không tìm thấy đặt bàn');
      }

      Reservation reservation = Reservation.fromFirestore(reservationDoc);
      
      // Tạo order item mới
      OrderItem newOrderItem = OrderItem(
        itemId: itemId,
        itemName: menuItem.name,
        quantity: quantity,
        price: menuItem.price,
        subtotal: menuItem.price * quantity,
      );

      // Thêm vào orderItems array
      List<OrderItem> updatedOrderItems = List.from(reservation.orderItems);
      int existingIndex = updatedOrderItems.indexWhere((item) => item.itemId == itemId);
      
      if (existingIndex >= 0) {
        // Cập nhật quantity nếu item đã tồn tại
        OrderItem existingItem = updatedOrderItems[existingIndex];
        updatedOrderItems[existingIndex] = existingItem.copyWith(
          quantity: existingItem.quantity + quantity,
          subtotal: (existingItem.quantity + quantity) * existingItem.price,
        );
      } else {
        // Thêm item mới
        updatedOrderItems.add(newOrderItem);
      }

      // Tính lại subtotal, serviceCharge, total
      double newSubtotal = updatedOrderItems.fold(0.0, (sum, item) => sum + item.subtotal);
      double newServiceCharge = newSubtotal * 0.1; // 10% service charge
      double newTotal = newSubtotal + newServiceCharge - reservation.discount;

      // Cập nhật reservation
      await _reservationsRef.doc(reservationId).update({
        'orderItems': updatedOrderItems.map((item) => item.toMap()).toList(),
        'subtotal': newSubtotal,
        'serviceCharge': newServiceCharge,
        'total': newTotal,
        'updatedAt': Timestamp.fromDate(DateTime.now()),
      });
    } catch (e) {
      throw Exception('Lỗi khi thêm món vào đơn: $e');
    }
  }

  /// 3. Xác nhận Đặt Bàn (2 điểm)
  Future<void> confirmReservation(String reservationId, String tableNumber) async {
    try {
      await _reservationsRef.doc(reservationId).update({
        'status': 'confirmed', // Set status = "confirmed"
        'tableNumber': tableNumber, // Set tableNumber
        'updatedAt': Timestamp.fromDate(DateTime.now()),
      });
    } catch (e) {
      throw Exception('Lỗi khi xác nhận đặt bàn: $e');
    }
  }

  /// 4. Thanh toán (3 điểm)
  Future<void> payReservation(String reservationId, String paymentMethod) async {
    try {
      // Lấy reservation hiện tại
      DocumentSnapshot reservationDoc = await _reservationsRef.doc(reservationId).get();
      if (!reservationDoc.exists) {
        throw Exception('Không tìm thấy đặt bàn');
      }

      Reservation reservation = Reservation.fromFirestore(reservationDoc);
      
      // Lấy thông tin customer để tính discount
      var customer = await _customerRepository.getCustomerById(reservation.customerId);
      if (customer == null) {
        throw Exception('Không tìm thấy khách hàng');
      }

      // Tính discount từ loyaltyPoints (1 point = 1000đ, tối đa 50% total)
      double maxDiscount = (reservation.subtotal + reservation.serviceCharge) * 0.5;
      double availableDiscount = customer.loyaltyPoints * 1000.0;
      double actualDiscount = availableDiscount > maxDiscount ? maxDiscount : availableDiscount;
      
      int pointsUsed = (actualDiscount / 1000).floor();
      
      // Tính lại total sau discount
      double newTotal = reservation.subtotal + reservation.serviceCharge - actualDiscount;
      
      // Cộng loyaltyPoints cho customer (1% total)
      int newLoyaltyPoints = (newTotal * 0.01).floor();

      // Set paymentStatus = "paid", status = "completed"
      await _reservationsRef.doc(reservationId).update({
        'discount': actualDiscount,
        'total': newTotal,
        'paymentMethod': paymentMethod,
        'paymentStatus': 'paid',
        'status': 'completed',
        'updatedAt': Timestamp.fromDate(DateTime.now()),
      });

      // Trừ loyaltyPoints đã dùng và cộng points mới
      int finalLoyaltyPoints = customer.loyaltyPoints - pointsUsed + newLoyaltyPoints;
      await _customerRepository.updateLoyaltyPoints(
        reservation.customerId, 
        finalLoyaltyPoints - customer.loyaltyPoints
      );
    } catch (e) {
      throw Exception('Lỗi khi thanh toán: $e');
    }
  }

  /// 5. Lấy Đặt Bàn (1 điểm)
  Future<List<Reservation>> getReservationsByCustomer(String customerId) async {
    try {
      QuerySnapshot querySnapshot = await _reservationsRef.get();
      
      List<Reservation> reservations = [];
      for (var doc in querySnapshot.docs) {
        try {
          Reservation reservation = Reservation.fromFirestore(doc);
          if (reservation.customerId == customerId) {
            reservations.add(reservation);
          }
        } catch (e) {
          print('⚠️ Lỗi parse reservation ${doc.id}: $e');
          continue;
        }
      }
      
      // Sort theo createdAt
      reservations.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      
      return reservations;
    } catch (e) {
      throw Exception('Lỗi khi lấy đặt bàn theo khách hàng: $e');
    }
  }

  Future<List<Reservation>> getReservationsByDate(String date) async {
    try {
      DateTime targetDate = DateTime.parse('${date}T00:00:00');
      DateTime startDate = DateTime(targetDate.year, targetDate.month, targetDate.day);
      DateTime endDate = DateTime(targetDate.year, targetDate.month, targetDate.day, 23, 59, 59);
      
      QuerySnapshot querySnapshot = await _reservationsRef.get();
      
      List<Reservation> reservations = [];
      for (var doc in querySnapshot.docs) {
        try {
          Reservation reservation = Reservation.fromFirestore(doc);
          if (reservation.reservationDate.isAfter(startDate.subtract(const Duration(seconds: 1))) &&
              reservation.reservationDate.isBefore(endDate.add(const Duration(seconds: 1)))) {
            reservations.add(reservation);
          }
        } catch (e) {
          print('⚠️ Lỗi parse reservation ${doc.id}: $e');
          continue;
        }
      }
      
      // Sort theo reservationDate
      reservations.sort((a, b) => a.reservationDate.compareTo(b.reservationDate));
      
      return reservations;
    } catch (e) {
      throw Exception('Lỗi khi lấy đặt bàn theo ngày: $e');
    }
  }

  // ===== ADDITIONAL METHODS =====

  // Lấy reservation theo ID
  Future<Reservation?> getReservationById(String reservationId) async {
    try {
      DocumentSnapshot doc = await _reservationsRef.doc(reservationId).get();
      if (doc.exists) {
        return Reservation.fromFirestore(doc);
      }
      return null;
    } catch (e) {
      throw Exception('Lỗi khi lấy thông tin đặt bàn: $e');
    }
  }

  // Cập nhật status reservation
  Future<void> updateReservationStatus(String reservationId, String status) async {
    try {
      await _reservationsRef.doc(reservationId).update({
        'status': status,
        'updatedAt': Timestamp.fromDate(DateTime.now()),
      });
    } catch (e) {
      throw Exception('Lỗi khi cập nhật trạng thái đặt bàn: $e');
    }
  }

  // Xóa item khỏi reservation
  Future<void> removeItemFromReservation(String reservationId, String itemId) async {
    try {
      DocumentSnapshot reservationDoc = await _reservationsRef.doc(reservationId).get();
      if (!reservationDoc.exists) {
        throw Exception('Không tìm thấy đặt bàn');
      }

      Reservation reservation = Reservation.fromFirestore(reservationDoc);
      
      // Xóa item khỏi order
      List<OrderItem> updatedOrderItems = reservation.orderItems
          .where((item) => item.itemId != itemId)
          .toList();

      // Tính lại tổng tiền
      double newSubtotal = updatedOrderItems.fold(0.0, (sum, item) => sum + item.subtotal);
      double newServiceCharge = newSubtotal * 0.1;
      double newTotal = newSubtotal + newServiceCharge - reservation.discount;

      await _reservationsRef.doc(reservationId).update({
        'orderItems': updatedOrderItems.map((item) => item.toMap()).toList(),
        'subtotal': newSubtotal,
        'serviceCharge': newServiceCharge,
        'total': newTotal,
        'updatedAt': Timestamp.fromDate(DateTime.now()),
      });
    } catch (e) {
      throw Exception('Lỗi khi xóa món khỏi đơn: $e');
    }
  }

  // Stream để theo dõi reservations của customer
  Stream<List<Reservation>> customerReservationsStream(String customerId) {
    return _reservationsRef
        .where('customerId', isEqualTo: customerId)
        .snapshots()
        .map((snapshot) {
          List<Reservation> reservations = [];
          for (var doc in snapshot.docs) {
            try {
              Reservation reservation = Reservation.fromFirestore(doc);
              if (reservation.customerId == customerId) {
                reservations.add(reservation);
              }
            } catch (e) {
              print('Error parsing reservation in stream: $e');
              continue;
            }
          }
          
          // Sort ở client side
          reservations.sort((a, b) => b.createdAt.compareTo(a.createdAt));
          
          return reservations;
        });
  }

  // ===== HELPER METHODS =====

  /// Kiểm tra không đặt trùng thời gian
  Future<void> _checkDuplicateReservation(String customerId, DateTime reservationDate) async {
    try {
      // Kiểm tra trong khoảng 2 tiếng trước và sau
      DateTime startCheck = reservationDate.subtract(const Duration(hours: 2));
      DateTime endCheck = reservationDate.add(const Duration(hours: 2));
      
      List<Reservation> existingReservations = await getReservationsByCustomer(customerId);
      
      for (Reservation reservation in existingReservations) {
        if (reservation.status != 'cancelled' && reservation.status != 'no_show') {
          if (reservation.reservationDate.isAfter(startCheck) && 
              reservation.reservationDate.isBefore(endCheck)) {
            throw Exception('Bạn đã có đặt bàn trong khoảng thời gian này');
          }
        }
      }
    } catch (e) {
      if (e.toString().contains('Bạn đã có đặt bàn')) {
        rethrow;
      }
      // Ignore other errors, allow reservation to proceed
      print('⚠️ Không thể kiểm tra trùng lịch: $e');
    }
  }

  // === SIMPLE METHODS USING SimpleRepository ===
  
  // Lấy reservations bằng SimpleRepository (không cần index)
  Future<List<Reservation>> getReservationsByCustomerSimple(String customerId) async {
    return await SimpleRepository.getReservationsByCustomer(customerId);
  }

  // Stream sử dụng SimpleRepository
  Stream<List<Reservation>> customerReservationsStreamSimple(String customerId) {
    return SimpleRepository.customerReservationsStream(customerId);
  }
}