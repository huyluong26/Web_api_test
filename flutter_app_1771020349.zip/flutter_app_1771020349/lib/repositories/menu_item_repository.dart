import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/menu_item.dart';
import '../services/firebase_service.dart';
import 'simple_repository.dart';

class MenuItemRepository {
  final CollectionReference _menuItemsRef = FirebaseService.menuItemsCollection;

  // ===== MENU ITEM REPOSITORY METHODS (14 điểm) =====

  /// 1. Thêm MenuItem (3 điểm)
  Future<String> addMenuItem(MenuItem menuItem) async {
    try {
      DocumentReference docRef = await _menuItemsRef.add(menuItem.toFirestore());
      return docRef.id;
    } catch (e) {
      // Fallback to SimpleRepository
      try {
        return await SimpleRepository.addMenuItem(menuItem);
      } catch (e2) {
        throw Exception('Lỗi khi thêm món ăn: $e');
      }
    }
  }

  /// 2. Lấy MenuItem theo ID (2 điểm)
  Future<MenuItem?> getMenuItemById(String itemId) async {
    try {
      DocumentSnapshot doc = await _menuItemsRef.doc(itemId).get();
      if (doc.exists) {
        return MenuItem.fromFirestore(doc);
      }
      return null;
    } catch (e) {
      // Fallback to SimpleRepository
      try {
        return await SimpleRepository.getMenuItemById(itemId);
      } catch (e2) {
        throw Exception('Lỗi khi lấy thông tin món ăn: $e');
      }
    }
  }

  /// 3. Lấy tất cả MenuItems (2 điểm)
  Future<List<MenuItem>> getAllMenuItems() async {
    try {
      QuerySnapshot querySnapshot = await _menuItemsRef.get();
      
      List<MenuItem> menuItems = [];
      for (var doc in querySnapshot.docs) {
        try {
          MenuItem menuItem = MenuItem.fromFirestore(doc);
          menuItems.add(menuItem);
        } catch (e) {
          print('⚠️ Lỗi parse menu item ${doc.id}: $e');
          continue;
        }
      }
      
      // Sort theo category và name
      menuItems.sort((a, b) {
        int categoryCompare = a.category.compareTo(b.category);
        if (categoryCompare != 0) return categoryCompare;
        return a.name.compareTo(b.name);
      });
      
      return menuItems;
    } catch (e) {
      // Fallback to SimpleRepository
      try {
        return await SimpleRepository.getAllMenuItems();
      } catch (e2) {
        throw Exception('Lỗi khi lấy danh sách món ăn: $e');
      }
    }
  }

  /// 4. Tìm kiếm MenuItems (4 điểm) - Tìm trong name, description, ingredients
  Future<List<MenuItem>> searchMenuItems(String searchTerm) async {
    try {
      String searchLower = searchTerm.toLowerCase();
      List<MenuItem> allItems = await getAllMenuItems();
      
      List<MenuItem> searchResults = allItems.where((item) {
        // Tìm trong name
        bool nameMatch = item.name.toLowerCase().contains(searchLower);
        
        // Tìm trong description
        bool descriptionMatch = item.description.toLowerCase().contains(searchLower);
        
        // Tìm trong ingredients
        bool ingredientsMatch = item.ingredients.any((ingredient) => 
            ingredient.toLowerCase().contains(searchLower));
        
        return nameMatch || descriptionMatch || ingredientsMatch;
      }).toList();
      
      return searchResults;
    } catch (e) {
      throw Exception('Lỗi khi tìm kiếm món ăn: $e');
    }
  }

  /// 5. Lọc MenuItems (3 điểm) - Theo category, isVegetarian, isSpicy
  Future<List<MenuItem>> filterMenuItems({
    String? category,
    bool? isVegetarian,
    bool? isSpicy,
  }) async {
    try {
      List<MenuItem> allItems = await getAllMenuItems();
      
      List<MenuItem> filteredItems = allItems.where((item) {
        // Lọc theo category
        if (category != null && item.category != category) {
          return false;
        }
        
        // Lọc theo isVegetarian
        if (isVegetarian != null && item.isVegetarian != isVegetarian) {
          return false;
        }
        
        // Lọc theo isSpicy
        if (isSpicy != null && item.isSpicy != isSpicy) {
          return false;
        }
        
        return true;
      }).toList();
      
      return filteredItems;
    } catch (e) {
      throw Exception('Lỗi khi lọc món ăn: $e');
    }
  }

  // ===== ADDITIONAL METHODS =====

  // Lọc MenuItems theo category
  Future<List<MenuItem>> getMenuItemsByCategory(String category) async {
    return await filterMenuItems(category: category);
  }

  // Lọc MenuItems theo isVegetarian
  Future<List<MenuItem>> getVegetarianMenuItems() async {
    return await filterMenuItems(isVegetarian: true);
  }

  // Lọc MenuItems theo isSpicy
  Future<List<MenuItem>> getSpicyMenuItems() async {
    return await filterMenuItems(isSpicy: true);
  }

  // Lọc MenuItems có sẵn
  Future<List<MenuItem>> getAvailableMenuItems() async {
    try {
      List<MenuItem> allItems = await getAllMenuItems();
      return allItems.where((item) => item.isAvailable).toList();
    } catch (e) {
      // Fallback to SimpleRepository
      try {
        return await SimpleRepository.getAvailableMenuItems();
      } catch (e2) {
        throw Exception('Lỗi khi lấy món ăn có sẵn: $e');
      }
    }
  }

  // Cập nhật MenuItem
  Future<void> updateMenuItem(String itemId, Map<String, dynamic> updates) async {
    try {
      await _menuItemsRef.doc(itemId).update(updates);
    } catch (e) {
      throw Exception('Lỗi khi cập nhật món ăn: $e');
    }
  }

  // Stream để theo dõi thay đổi menu items
  Stream<List<MenuItem>> menuItemsStream() {
    return _menuItemsRef.snapshots().map((snapshot) {
      List<MenuItem> items = [];
      for (var doc in snapshot.docs) {
        try {
          MenuItem item = MenuItem.fromFirestore(doc);
          items.add(item);
        } catch (e) {
          print('Error parsing menu item in stream: $e');
          continue;
        }
      }
      
      // Sort ở client side
      items.sort((a, b) {
        int categoryCompare = a.category.compareTo(b.category);
        if (categoryCompare != 0) return categoryCompare;
        return a.name.compareTo(b.name);
      });
      
      return items;
    });
  }

  // Stream cho available menu items
  Stream<List<MenuItem>> availableMenuItemsStream() {
    return menuItemsStream().map((items) {
      return items.where((item) => item.isAvailable).toList();
    });
  }

  // Lấy danh sách categories
  Future<List<String>> getCategories() async {
    try {
      List<MenuItem> allItems = await getAllMenuItems();
      Set<String> categorySet = allItems.map((item) => item.category).toSet();
      List<String> categories = categorySet.toList();
      categories.sort();
      return categories;
    } catch (e) {
      throw Exception('Lỗi khi lấy danh sách categories: $e');
    }
  }
}