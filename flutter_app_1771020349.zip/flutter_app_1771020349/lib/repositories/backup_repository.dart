import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/customer.dart';
import '../models/menu_item.dart';
import '../models/reservation.dart';
import '../services/firebase_service.dart';

/// Backup repository với queries đơn giản nhất có thể
class BackupRepository {
  
  // === CUSTOMER METHODS ===
  
  static Future<String> addCustomer(Customer customer) async {
    DocumentReference docRef = await FirebaseService.customersCollection.add(customer.toFirestore());
    return docRef.id;
  }

  static Future<Customer?> getCustomerById(String customerId) async {
    DocumentSnapshot doc = await FirebaseService.customersCollection.doc(customerId).get();
    if (doc.exists) {
      return Customer.fromFirestore(doc);
    }
    return null;
  }

  static Future<Customer?> getCustomerByEmail(String email) async {
    QuerySnapshot querySnapshot = await FirebaseService.customersCollection.get();
    
    for (var doc in querySnapshot.docs) {
      try {
        Customer customer = Customer.fromFirestore(doc);
        if (customer.email == email && customer.isActive) {
          return customer;
        }
      } catch (e) {
        print('Error parsing customer: $e');
        continue;
      }
    }
    return null;
  }

  static Future<void> updateCustomer(String customerId, Map<String, dynamic> updates) async {
    await FirebaseService.customersCollection.doc(customerId).update(updates);
  }

  static Future<void> updateLoyaltyPoints(String customerId, int points) async {
    await FirebaseService.customersCollection.doc(customerId).update({
      'loyaltyPoints': FieldValue.increment(points),
    });
  }

  // === MENU ITEM METHODS ===

  static Future<String> addMenuItem(MenuItem menuItem) async {
    DocumentReference docRef = await FirebaseService.menuItemsCollection.add(menuItem.toFirestore());
    return docRef.id;
  }

  static Future<MenuItem?> getMenuItemById(String itemId) async {
    DocumentSnapshot doc = await FirebaseService.menuItemsCollection.doc(itemId).get();
    if (doc.exists) {
      return MenuItem.fromFirestore(doc);
    }
    return null;
  }

  static Future<List<MenuItem>> getAllMenuItems() async {
    QuerySnapshot querySnapshot = await FirebaseService.menuItemsCollection.get();
    
    List<MenuItem> items = [];
    for (var doc in querySnapshot.docs) {
      try {
        items.add(MenuItem.fromFirestore(doc));
      } catch (e) {
        print('Error parsing menu item: $e');
        continue;
      }
    }
    
    // Sort ở client side
    items.sort((a, b) => a.name.compareTo(b.name));
    return items;
  }

  static Future<List<MenuItem>> getAvailableMenuItems() async {
    List<MenuItem> allItems = await getAllMenuItems();
    return allItems.where((item) => item.isAvailable).toList();
  }

  // === RESERVATION METHODS ===

  static Future<String> createReservation(Reservation reservation) async {
    DocumentReference docRef = await FirebaseService.reservationsCollection.add(reservation.toFirestore());
    return docRef.id;
  }

  static Future<Reservation?> getReservationById(String reservationId) async {
    DocumentSnapshot doc = await FirebaseService.reservationsCollection.doc(reservationId).get();
    if (doc.exists) {
      return Reservation.fromFirestore(doc);
    }
    return null;
  }

  static Future<List<Reservation>> getReservationsByCustomer(String customerId) async {
    QuerySnapshot querySnapshot = await FirebaseService.reservationsCollection.get();
    
    List<Reservation> reservations = [];
    for (var doc in querySnapshot.docs) {
      try {
        Reservation reservation = Reservation.fromFirestore(doc);
        if (reservation.customerId == customerId) {
          reservations.add(reservation);
        }
      } catch (e) {
        print('Error parsing reservation: $e');
        continue;
      }
    }
    
    // Sort ở client side
    reservations.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return reservations;
  }

  static Future<void> updateReservation(String reservationId, Map<String, dynamic> updates) async {
    updates['updatedAt'] = Timestamp.fromDate(DateTime.now());
    await FirebaseService.reservationsCollection.doc(reservationId).update(updates);
  }
}