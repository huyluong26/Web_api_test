import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/customer.dart';
import '../models/menu_item.dart';
import '../models/reservation.dart';
import '../models/order_item.dart';
import '../services/firebase_service.dart';

/// Repository để test tất cả các chức năng theo yêu cầu đề bài
class TestRepository {
  
  // ===== CUSTOMER REPOSITORY METHODS (12 điểm) =====
  
  /// 1. Thêm Customer (3 điểm)
  static Future<String> addCustomer(Customer customer) async {
    try {
      DocumentReference docRef = await FirebaseService.customersCollection.add(customer.toFirestore());
      print('✅ Đã thêm customer: ${customer.fullName} với ID: ${docRef.id}');
      return docRef.id;
    } catch (e) {
      print('❌ Lỗi khi thêm customer: $e');
      throw Exception('Lỗi khi thêm khách hàng: $e');
    }
  }

  /// 2. Lấy Customer theo ID (2 điểm)
  static Future<Customer?> getCustomerById(String customerId) async {
    try {
      DocumentSnapshot doc = await FirebaseService.customersCollection.doc(customerId).get();
      if (doc.exists) {
        Customer customer = Customer.fromFirestore(doc);
        print('✅ Lấy customer thành công: ${customer.fullName}');
        return customer;
      } else {
        print('⚠️ Không tìm thấy customer với ID: $customerId');
        return null;
      }
    } catch (e) {
      print('❌ Lỗi khi lấy customer: $e');
      throw Exception('Lỗi khi lấy thông tin khách hàng: $e');
    }
  }

  /// 3. Lấy tất cả Customers (2 điểm)
  static Future<List<Customer>> getAllCustomers() async {
    try {
      QuerySnapshot querySnapshot = await FirebaseService.customersCollection.get();
      
      List<Customer> customers = [];
      for (var doc in querySnapshot.docs) {
        try {
          Customer customer = Customer.fromFirestore(doc);
          if (customer.isActive) {
            customers.add(customer);
          }
        } catch (e) {
          print('⚠️ Lỗi parse customer ${doc.id}: $e');
          continue;
        }
      }
      
      // Sort theo createdAt
      customers.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      
      print('✅ Lấy ${customers.length} customers thành công');
      return customers;
    } catch (e) {
      print('❌ Lỗi khi lấy tất cả customers: $e');
      throw Exception('Lỗi khi lấy danh sách khách hàng: $e');
    }
  }

  /// 4. Cập nhật Customer (3 điểm)
  static Future<void> updateCustomer(String customerId, Map<String, dynamic> updates) async {
    try {
      await FirebaseService.customersCollection.doc(customerId).update(updates);
      print('✅ Cập nhật customer $customerId thành công');
    } catch (e) {
      print('❌ Lỗi khi cập nhật customer: $e');
      throw Exception('Lỗi khi cập nhật khách hàng: $e');
    }
  }

  /// 5. Cập nhật Loyalty Points (2 điểm)
  static Future<void> updateLoyaltyPoints(String customerId, int points) async {
    try {
      await FirebaseService.customersCollection.doc(customerId).update({
        'loyaltyPoints': FieldValue.increment(points),
      });
      print('✅ Cập nhật loyalty points cho customer $customerId: ${points > 0 ? '+' : ''}$points điểm');
    } catch (e) {
      print('❌ Lỗi khi cập nhật loyalty points: $e');
      throw Exception('Lỗi khi cập nhật điểm tích lũy: $e');
    }
  }

  // ===== MENU ITEM REPOSITORY METHODS (14 điểm) =====

  /// 1. Thêm MenuItem (3 điểm)
  static Future<String> addMenuItem(MenuItem menuItem) async {
    try {
      DocumentReference docRef = await FirebaseService.menuItemsCollection.add(menuItem.toFirestore());
      print('✅ Đã thêm menu item: ${menuItem.name} với ID: ${docRef.id}');
      return docRef.id;
    } catch (e) {
      print('❌ Lỗi khi thêm menu item: $e');
      throw Exception('Lỗi khi thêm món ăn: $e');
    }
  }

  /// 2. Lấy MenuItem theo ID (2 điểm)
  static Future<MenuItem?> getMenuItemById(String itemId) async {
    try {
      DocumentSnapshot doc = await FirebaseService.menuItemsCollection.doc(itemId).get();
      if (doc.exists) {
        MenuItem menuItem = MenuItem.fromFirestore(doc);
        print('✅ Lấy menu item thành công: ${menuItem.name}');
        return menuItem;
      } else {
        print('⚠️ Không tìm thấy menu item với ID: $itemId');
        return null;
      }
    } catch (e) {
      print('❌ Lỗi khi lấy menu item: $e');
      throw Exception('Lỗi khi lấy thông tin món ăn: $e');
    }
  }

  /// 3. Lấy tất cả MenuItems (2 điểm)
  static Future<List<MenuItem>> getAllMenuItems() async {
    try {
      QuerySnapshot querySnapshot = await FirebaseService.menuItemsCollection.get();
      
      List<MenuItem> menuItems = [];
      for (var doc in querySnapshot.docs) {
        try {
          MenuItem menuItem = MenuItem.fromFirestore(doc);
          menuItems.add(menuItem);
        } catch (e) {
          print('⚠️ Lỗi parse menu item ${doc.id}: $e');
          continue;
        }
      }
      
      // Sort theo category và name
      menuItems.sort((a, b) {
        int categoryCompare = a.category.compareTo(b.category);
        if (categoryCompare != 0) return categoryCompare;
        return a.name.compareTo(b.name);
      });
      
      print('✅ Lấy ${menuItems.length} menu items thành công');
      return menuItems;
    } catch (e) {
      print('❌ Lỗi khi lấy tất cả menu items: $e');
      throw Exception('Lỗi khi lấy danh sách món ăn: $e');
    }
  }

  /// 4. Tìm kiếm MenuItems (4 điểm) - Tìm trong name, description, ingredients
  static Future<List<MenuItem>> searchMenuItems(String searchTerm) async {
    try {
      String searchLower = searchTerm.toLowerCase();
      List<MenuItem> allItems = await getAllMenuItems();
      
      List<MenuItem> searchResults = allItems.where((item) {
        // Tìm trong name
        bool nameMatch = item.name.toLowerCase().contains(searchLower);
        
        // Tìm trong description
        bool descriptionMatch = item.description.toLowerCase().contains(searchLower);
        
        // Tìm trong ingredients
        bool ingredientsMatch = item.ingredients.any((ingredient) => 
            ingredient.toLowerCase().contains(searchLower));
        
        return nameMatch || descriptionMatch || ingredientsMatch;
      }).toList();
      
      print('✅ Tìm kiếm "$searchTerm": ${searchResults.length} kết quả');
      return searchResults;
    } catch (e) {
      print('❌ Lỗi khi tìm kiếm menu items: $e');
      throw Exception('Lỗi khi tìm kiếm món ăn: $e');
    }
  }

  /// 5. Lọc MenuItems (3 điểm) - Theo category, isVegetarian, isSpicy
  static Future<List<MenuItem>> filterMenuItems({
    String? category,
    bool? isVegetarian,
    bool? isSpicy,
  }) async {
    try {
      List<MenuItem> allItems = await getAllMenuItems();
      
      List<MenuItem> filteredItems = allItems.where((item) {
        // Lọc theo category
        if (category != null && item.category != category) {
          return false;
        }
        
        // Lọc theo isVegetarian
        if (isVegetarian != null && item.isVegetarian != isVegetarian) {
          return false;
        }
        
        // Lọc theo isSpicy
        if (isSpicy != null && item.isSpicy != isSpicy) {
          return false;
        }
        
        return true;
      }).toList();
      
      String filterDesc = '';
      List<String> filterParts = [];
      if (category != null) filterParts.add('category: $category');
      if (isVegetarian != null) filterParts.add('vegetarian: $isVegetarian');
      if (isSpicy != null) filterParts.add('spicy: $isSpicy');
      filterDesc = filterParts.join(', ');
      
      print('✅ Lọc menu items [$filterDesc]: ${filteredItems.length} kết quả');
      return filteredItems;
    } catch (e) {
      print('❌ Lỗi khi lọc menu items: $e');
      throw Exception('Lỗi khi lọc món ăn: $e');
    }
  }

  // ===== RESERVATION REPOSITORY METHODS (14 điểm) =====

  /// 1. Đặt Bàn (5 điểm)
  static Future<String> createReservation(
    String customerId,
    DateTime reservationDate,
    int numberOfGuests,
    String? specialRequests,
  ) async {
    try {
      // Kiểm tra không đặt trùng thời gian (optional)
      await _checkDuplicateReservation(customerId, reservationDate);

      Reservation reservation = Reservation(
        reservationId: '',
        customerId: customerId,
        reservationDate: reservationDate,
        numberOfGuests: numberOfGuests,
        specialRequests: specialRequests,
        status: 'pending',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      DocumentReference docRef = await FirebaseService.reservationsCollection.add(reservation.toFirestore());
      print('✅ Tạo reservation thành công với ID: ${docRef.id}');
      return docRef.id;
    } catch (e) {
      print('❌ Lỗi khi tạo reservation: $e');
      throw Exception('Lỗi khi đặt bàn: $e');
    }
  }

  /// 2. Thêm Món vào Đơn (3 điểm)
  static Future<void> addItemToReservation(String reservationId, String itemId, int quantity) async {
    try {
      // Kiểm tra item isAvailable
      MenuItem? menuItem = await getMenuItemById(itemId);
      if (menuItem == null || !menuItem.isAvailable) {
        throw Exception('Món ăn không có sẵn');
      }

      // Lấy reservation hiện tại
      DocumentSnapshot reservationDoc = await FirebaseService.reservationsCollection.doc(reservationId).get();
      if (!reservationDoc.exists) {
        throw Exception('Không tìm thấy đặt bàn');
      }

      Reservation reservation = Reservation.fromFirestore(reservationDoc);
      
      // Tạo order item mới
      OrderItem newOrderItem = OrderItem(
        itemId: itemId,
        itemName: menuItem.name,
        quantity: quantity,
        price: menuItem.price,
        subtotal: menuItem.price * quantity,
      );

      // Thêm vào orderItems array
      List<OrderItem> updatedOrderItems = List.from(reservation.orderItems);
      int existingIndex = updatedOrderItems.indexWhere((item) => item.itemId == itemId);
      
      if (existingIndex >= 0) {
        // Cập nhật quantity nếu item đã tồn tại
        OrderItem existingItem = updatedOrderItems[existingIndex];
        updatedOrderItems[existingIndex] = existingItem.copyWith(
          quantity: existingItem.quantity + quantity,
          subtotal: (existingItem.quantity + quantity) * existingItem.price,
        );
      } else {
        // Thêm item mới
        updatedOrderItems.add(newOrderItem);
      }

      // Tính lại subtotal, serviceCharge, total
      double newSubtotal = updatedOrderItems.fold(0.0, (sum, item) => sum + item.subtotal);
      double newServiceCharge = newSubtotal * 0.1; // 10% service charge
      double newTotal = newSubtotal + newServiceCharge - reservation.discount;

      // Cập nhật reservation
      await FirebaseService.reservationsCollection.doc(reservationId).update({
        'orderItems': updatedOrderItems.map((item) => item.toMap()).toList(),
        'subtotal': newSubtotal,
        'serviceCharge': newServiceCharge,
        'total': newTotal,
        'updatedAt': Timestamp.fromDate(DateTime.now()),
      });

      print('✅ Thêm món ${menuItem.name} x$quantity vào reservation $reservationId');
    } catch (e) {
      print('❌ Lỗi khi thêm món vào đơn: $e');
      throw Exception('Lỗi khi thêm món vào đơn: $e');
    }
  }

  /// 3. Xác nhận Đặt Bàn (2 điểm)
  static Future<void> confirmReservation(String reservationId, String tableNumber) async {
    try {
      await FirebaseService.reservationsCollection.doc(reservationId).update({
        'status': 'confirmed',
        'tableNumber': tableNumber,
        'updatedAt': Timestamp.fromDate(DateTime.now()),
      });
      print('✅ Xác nhận reservation $reservationId, bàn số $tableNumber');
    } catch (e) {
      print('❌ Lỗi khi xác nhận đặt bàn: $e');
      throw Exception('Lỗi khi xác nhận đặt bàn: $e');
    }
  }

  /// 4. Thanh toán (3 điểm)
  static Future<void> payReservation(String reservationId, String paymentMethod) async {
    try {
      // Lấy reservation hiện tại
      DocumentSnapshot reservationDoc = await FirebaseService.reservationsCollection.doc(reservationId).get();
      if (!reservationDoc.exists) {
        throw Exception('Không tìm thấy đặt bàn');
      }

      Reservation reservation = Reservation.fromFirestore(reservationDoc);
      
      // Lấy thông tin customer để tính discount
      Customer? customer = await getCustomerById(reservation.customerId);
      if (customer == null) {
        throw Exception('Không tìm thấy khách hàng');
      }

      // Tính discount từ loyaltyPoints (1 point = 1000đ, tối đa 50% total)
      double maxDiscount = (reservation.subtotal + reservation.serviceCharge) * 0.5;
      double availableDiscount = customer.loyaltyPoints * 1000.0;
      double actualDiscount = availableDiscount > maxDiscount ? maxDiscount : availableDiscount;
      
      int pointsUsed = (actualDiscount / 1000).floor();
      
      // Tính lại total sau discount
      double newTotal = reservation.subtotal + reservation.serviceCharge - actualDiscount;
      
      // Cộng loyaltyPoints cho customer (1% total)
      int newLoyaltyPoints = (newTotal * 0.01).floor();

      // Set paymentStatus = "paid", status = "completed"
      await FirebaseService.reservationsCollection.doc(reservationId).update({
        'discount': actualDiscount,
        'total': newTotal,
        'paymentMethod': paymentMethod,
        'paymentStatus': 'paid',
        'status': 'completed',
        'updatedAt': Timestamp.fromDate(DateTime.now()),
      });

      // Trừ loyaltyPoints đã dùng và cộng points mới
      int finalLoyaltyPoints = customer.loyaltyPoints - pointsUsed + newLoyaltyPoints;
      await updateLoyaltyPoints(reservation.customerId, finalLoyaltyPoints - customer.loyaltyPoints);

      print('✅ Thanh toán reservation $reservationId: ${newTotal.toStringAsFixed(0)}đ');
      print('   - Discount: ${actualDiscount.toStringAsFixed(0)}đ (${pointsUsed} points)');
      print('   - Loyalty points earned: $newLoyaltyPoints');
    } catch (e) {
      print('❌ Lỗi khi thanh toán: $e');
      throw Exception('Lỗi khi thanh toán: $e');
    }
  }

  /// 5. Lấy Đặt Bàn (1 điểm)
  static Future<List<Reservation>> getReservationsByCustomer(String customerId) async {
    try {
      QuerySnapshot querySnapshot = await FirebaseService.reservationsCollection.get();
      
      List<Reservation> reservations = [];
      for (var doc in querySnapshot.docs) {
        try {
          Reservation reservation = Reservation.fromFirestore(doc);
          if (reservation.customerId == customerId) {
            reservations.add(reservation);
          }
        } catch (e) {
          print('⚠️ Lỗi parse reservation ${doc.id}: $e');
          continue;
        }
      }
      
      // Sort theo createdAt
      reservations.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      
      print('✅ Lấy ${reservations.length} reservations cho customer $customerId');
      return reservations;
    } catch (e) {
      print('❌ Lỗi khi lấy reservations theo customer: $e');
      throw Exception('Lỗi khi lấy đặt bàn theo khách hàng: $e');
    }
  }

  static Future<List<Reservation>> getReservationsByDate(String date) async {
    try {
      DateTime targetDate = DateTime.parse('${date}T00:00:00');
      DateTime startDate = DateTime(targetDate.year, targetDate.month, targetDate.day);
      DateTime endDate = DateTime(targetDate.year, targetDate.month, targetDate.day, 23, 59, 59);
      
      QuerySnapshot querySnapshot = await FirebaseService.reservationsCollection.get();
      
      List<Reservation> reservations = [];
      for (var doc in querySnapshot.docs) {
        try {
          Reservation reservation = Reservation.fromFirestore(doc);
          if (reservation.reservationDate.isAfter(startDate.subtract(const Duration(seconds: 1))) &&
              reservation.reservationDate.isBefore(endDate.add(const Duration(seconds: 1)))) {
            reservations.add(reservation);
          }
        } catch (e) {
          print('⚠️ Lỗi parse reservation ${doc.id}: $e');
          continue;
        }
      }
      
      // Sort theo reservationDate
      reservations.sort((a, b) => a.reservationDate.compareTo(b.reservationDate));
      
      print('✅ Lấy ${reservations.length} reservations cho ngày $date');
      return reservations;
    } catch (e) {
      print('❌ Lỗi khi lấy reservations theo ngày: $e');
      throw Exception('Lỗi khi lấy đặt bàn theo ngày: $e');
    }
  }

  // ===== HELPER METHODS =====

  /// Kiểm tra không đặt trùng thời gian
  static Future<void> _checkDuplicateReservation(String customerId, DateTime reservationDate) async {
    try {
      // Kiểm tra trong khoảng 2 tiếng trước và sau
      DateTime startCheck = reservationDate.subtract(const Duration(hours: 2));
      DateTime endCheck = reservationDate.add(const Duration(hours: 2));
      
      List<Reservation> existingReservations = await getReservationsByCustomer(customerId);
      
      for (Reservation reservation in existingReservations) {
        if (reservation.status != 'cancelled' && reservation.status != 'no_show') {
          if (reservation.reservationDate.isAfter(startCheck) && 
              reservation.reservationDate.isBefore(endCheck)) {
            throw Exception('Bạn đã có đặt bàn trong khoảng thời gian này');
          }
        }
      }
    } catch (e) {
      if (e.toString().contains('Bạn đã có đặt bàn')) {
        rethrow;
      }
      // Ignore other errors, allow reservation to proceed
      print('⚠️ Không thể kiểm tra trùng lịch: $e');
    }
  }
}