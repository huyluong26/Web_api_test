import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/customer.dart';
import '../services/firebase_service.dart';
import 'simple_repository.dart';

class CustomerRepository {
  final CollectionReference _customersRef = FirebaseService.customersCollection;

  // ===== CUSTOMER REPOSITORY METHODS (12 điểm) =====
  
  /// 1. Thêm Customer (3 điểm)
  Future<String> addCustomer(Customer customer) async {
    try {
      // Kiểm tra email đã tồn tại chưa
      Customer? existingCustomer = await getCustomerByEmail(customer.email);
      if (existingCustomer != null) {
        throw Exception('Email đã được sử dụng');
      }

      DocumentReference docRef = await _customersRef.add(customer.toFirestore());
      return docRef.id;
    } catch (e) {
      // Fallback to SimpleRepository
      try {
        return await SimpleRepository.addCustomer(customer);
      } catch (e2) {
        throw Exception('Lỗi khi thêm khách hàng: $e');
      }
    }
  }

  /// 2. Lấy Customer theo ID (2 điểm)
  Future<Customer?> getCustomerById(String customerId) async {
    try {
      DocumentSnapshot doc = await _customersRef.doc(customerId).get();
      if (doc.exists) {
        return Customer.fromFirestore(doc);
      }
      return null;
    } catch (e) {
      // Fallback to SimpleRepository
      try {
        return await SimpleRepository.getCustomerById(customerId);
      } catch (e2) {
        throw Exception('Lỗi khi lấy thông tin khách hàng: $e');
      }
    }
  }

  /// 3. Lấy tất cả Customers (2 điểm)
  Future<List<Customer>> getAllCustomers() async {
    try {
      QuerySnapshot querySnapshot = await _customersRef.get();
      
      List<Customer> customers = [];
      for (var doc in querySnapshot.docs) {
        try {
          Customer customer = Customer.fromFirestore(doc);
          if (customer.isActive) {
            customers.add(customer);
          }
        } catch (e) {
          print('⚠️ Lỗi parse customer ${doc.id}: $e');
          continue;
        }
      }
      
      // Sort theo createdAt (mới nhất trước)
      customers.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      
      return customers;
    } catch (e) {
      throw Exception('Lỗi khi lấy danh sách khách hàng: $e');
    }
  }

  /// 4. Cập nhật Customer (3 điểm)
  Future<void> updateCustomer(String customerId, Map<String, dynamic> updates) async {
    try {
      await _customersRef.doc(customerId).update(updates);
    } catch (e) {
      // Fallback to SimpleRepository
      try {
        await SimpleRepository.updateCustomer(customerId, updates);
      } catch (e2) {
        throw Exception('Lỗi khi cập nhật khách hàng: $e');
      }
    }
  }

  /// 5. Cập nhật Loyalty Points (2 điểm)
  Future<void> updateLoyaltyPoints(String customerId, int points) async {
    try {
      await _customersRef.doc(customerId).update({
        'loyaltyPoints': FieldValue.increment(points),
      });
    } catch (e) {
      // Fallback to SimpleRepository
      try {
        await SimpleRepository.updateLoyaltyPoints(customerId, points);
      } catch (e2) {
        throw Exception('Lỗi khi cập nhật điểm tích lũy: $e');
      }
    }
  }

  // ===== ADDITIONAL METHODS =====

  Future<Customer?> getCustomerByEmail(String email) async {
    try {
      QuerySnapshot querySnapshot = await _customersRef.get();
      
      for (var doc in querySnapshot.docs) {
        try {
          Customer customer = Customer.fromFirestore(doc);
          if (customer.email == email && customer.isActive) {
            return customer;
          }
        } catch (e) {
          continue;
        }
      }
      return null;
    } catch (e) {
      // Fallback to SimpleRepository
      try {
        return await SimpleRepository.getCustomerByEmail(email);
      } catch (e2) {
        throw Exception('Lỗi khi tìm khách hàng theo email: $e');
      }
    }
  }

  // Stream để theo dõi thay đổi customer
  Stream<Customer?> customerStream(String customerId) {
    return _customersRef.doc(customerId).snapshots().map((doc) {
      if (doc.exists) {
        try {
          return Customer.fromFirestore(doc);
        } catch (e) {
          print('Error parsing customer stream: $e');
          return null;
        }
      }
      return null;
    });
  }

  // Stream để theo dõi tất cả customers
  Stream<List<Customer>> allCustomersStream() {
    return _customersRef.snapshots().map((snapshot) {
      List<Customer> customers = [];
      for (var doc in snapshot.docs) {
        try {
          Customer customer = Customer.fromFirestore(doc);
          if (customer.isActive) {
            customers.add(customer);
          }
        } catch (e) {
          print('Error parsing customer in stream: $e');
          continue;
        }
      }
      customers.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return customers;
    });
  }
}