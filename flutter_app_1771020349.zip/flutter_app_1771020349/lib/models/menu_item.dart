import 'package:cloud_firestore/cloud_firestore.dart';

class MenuItem {
  final String itemId;
  final String name;
  final String description;
  final String category;
  final double price;
  final String imageUrl;
  final List<String> ingredients;
  final bool isVegetarian;
  final bool isSpicy;
  final int preparationTime;
  final bool isAvailable;
  final double rating;
  final DateTime createdAt;

  MenuItem({
    required this.itemId,
    required this.name,
    required this.description,
    required this.category,
    required this.price,
    required this.imageUrl,
    required this.ingredients,
    this.isVegetarian = false,
    this.isSpicy = false,
    required this.preparationTime,
    this.isAvailable = true,
    this.rating = 0.0,
    required this.createdAt,
  });

  // Convert from Firestore document
  factory MenuItem.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    
    // Safe casting cho ingredients array
    List<String> ingredients = [];
    if (data['ingredients'] != null) {
      final ingredientsData = data['ingredients'];
      if (ingredientsData is List) {
        ingredients = ingredientsData.map((item) => item.toString()).toList();
      }
    }
    
    return MenuItem(
      itemId: doc.id,
      name: data['name']?.toString() ?? '',
      description: data['description']?.toString() ?? '',
      category: data['category']?.toString() ?? '',
      price: (data['price'] as num?)?.toDouble() ?? 0.0,
      imageUrl: data['imageUrl']?.toString() ?? '',
      ingredients: ingredients,
      isVegetarian: data['isVegetarian'] as bool? ?? false,
      isSpicy: data['isSpicy'] as bool? ?? false,
      preparationTime: (data['preparationTime'] as num?)?.toInt() ?? 0,
      isAvailable: data['isAvailable'] as bool? ?? true,
      rating: (data['rating'] as num?)?.toDouble() ?? 0.0,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  // Convert to Firestore document
  Map<String, dynamic> toFirestore() {
    return {
      'name': name,
      'description': description,
      'category': category,
      'price': price,
      'imageUrl': imageUrl,
      'ingredients': ingredients,
      'isVegetarian': isVegetarian,
      'isSpicy': isSpicy,
      'preparationTime': preparationTime,
      'isAvailable': isAvailable,
      'rating': rating,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }

  // Copy with method for updates
  MenuItem copyWith({
    String? name,
    String? description,
    String? category,
    double? price,
    String? imageUrl,
    List<String>? ingredients,
    bool? isVegetarian,
    bool? isSpicy,
    int? preparationTime,
    bool? isAvailable,
    double? rating,
  }) {
    return MenuItem(
      itemId: itemId,
      name: name ?? this.name,
      description: description ?? this.description,
      category: category ?? this.category,
      price: price ?? this.price,
      imageUrl: imageUrl ?? this.imageUrl,
      ingredients: ingredients ?? this.ingredients,
      isVegetarian: isVegetarian ?? this.isVegetarian,
      isSpicy: isSpicy ?? this.isSpicy,
      preparationTime: preparationTime ?? this.preparationTime,
      isAvailable: isAvailable ?? this.isAvailable,
      rating: rating ?? this.rating,
      createdAt: createdAt,
    );
  }
}