import 'package:cloud_firestore/cloud_firestore.dart';
import 'order_item.dart';

class Reservation {
  final String reservationId;
  final String customerId;
  final DateTime reservationDate;
  final int numberOfGuests;
  final String? tableNumber;
  final String status; // "pending", "confirmed", "seated", "completed", "cancelled", "no_show"
  final String? specialRequests;
  final List<OrderItem> orderItems;
  final double subtotal;
  final double serviceCharge;
  final double discount;
  final double total;
  final String? paymentMethod; // "cash", "card", "online"
  final String paymentStatus; // "pending", "paid", "refunded"
  final DateTime createdAt;
  final DateTime updatedAt;

  Reservation({
    required this.reservationId,
    required this.customerId,
    required this.reservationDate,
    required this.numberOfGuests,
    this.tableNumber,
    this.status = 'pending',
    this.specialRequests,
    this.orderItems = const [],
    this.subtotal = 0.0,
    this.serviceCharge = 0.0,
    this.discount = 0.0,
    this.total = 0.0,
    this.paymentMethod,
    this.paymentStatus = 'pending',
    required this.createdAt,
    required this.updatedAt,
  });

  // Convert from Firestore document
  factory Reservation.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    
    // Safe casting cho orderItems array
    List<OrderItem> orderItems = [];
    if (data['orderItems'] != null) {
      final orderItemsData = data['orderItems'];
      if (orderItemsData is List) {
        orderItems = orderItemsData
            .map((item) {
              if (item is Map<String, dynamic>) {
                return OrderItem.fromMap(item);
              }
              return null;
            })
            .where((item) => item != null)
            .cast<OrderItem>()
            .toList();
      }
    }

    return Reservation(
      reservationId: doc.id,
      customerId: data['customerId']?.toString() ?? '',
      reservationDate: (data['reservationDate'] as Timestamp?)?.toDate() ?? DateTime.now(),
      numberOfGuests: (data['numberOfGuests'] as num?)?.toInt() ?? 0,
      tableNumber: data['tableNumber']?.toString(),
      status: data['status']?.toString() ?? 'pending',
      specialRequests: data['specialRequests']?.toString(),
      orderItems: orderItems,
      subtotal: (data['subtotal'] as num?)?.toDouble() ?? 0.0,
      serviceCharge: (data['serviceCharge'] as num?)?.toDouble() ?? 0.0,
      discount: (data['discount'] as num?)?.toDouble() ?? 0.0,
      total: (data['total'] as num?)?.toDouble() ?? 0.0,
      paymentMethod: data['paymentMethod']?.toString(),
      paymentStatus: data['paymentStatus']?.toString() ?? 'pending',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  // Convert to Firestore document
  Map<String, dynamic> toFirestore() {
    return {
      'customerId': customerId,
      'reservationDate': Timestamp.fromDate(reservationDate),
      'numberOfGuests': numberOfGuests,
      'tableNumber': tableNumber,
      'status': status,
      'specialRequests': specialRequests,
      'orderItems': orderItems.map((item) => item.toMap()).toList(),
      'subtotal': subtotal,
      'serviceCharge': serviceCharge,
      'discount': discount,
      'total': total,
      'paymentMethod': paymentMethod,
      'paymentStatus': paymentStatus,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
    };
  }

  // Copy with method for updates
  Reservation copyWith({
    String? customerId,
    DateTime? reservationDate,
    int? numberOfGuests,
    String? tableNumber,
    String? status,
    String? specialRequests,
    List<OrderItem>? orderItems,
    double? subtotal,
    double? serviceCharge,
    double? discount,
    double? total,
    String? paymentMethod,
    String? paymentStatus,
    DateTime? updatedAt,
  }) {
    return Reservation(
      reservationId: reservationId,
      customerId: customerId ?? this.customerId,
      reservationDate: reservationDate ?? this.reservationDate,
      numberOfGuests: numberOfGuests ?? this.numberOfGuests,
      tableNumber: tableNumber ?? this.tableNumber,
      status: status ?? this.status,
      specialRequests: specialRequests ?? this.specialRequests,
      orderItems: orderItems ?? this.orderItems,
      subtotal: subtotal ?? this.subtotal,
      serviceCharge: serviceCharge ?? this.serviceCharge,
      discount: discount ?? this.discount,
      total: total ?? this.total,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      paymentStatus: paymentStatus ?? this.paymentStatus,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
    );
  }
}