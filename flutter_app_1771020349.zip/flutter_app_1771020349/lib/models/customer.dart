import 'package:cloud_firestore/cloud_firestore.dart';

class Customer {
  final String customerId;
  final String email;
  final String fullName;
  final String phoneNumber;
  final String address;
  final List<String> preferences;
  final int loyaltyPoints;
  final DateTime createdAt;
  final bool isActive;
  final String role; // 'customer' hoặc 'admin'

  Customer({
    required this.customerId,
    required this.email,
    required this.fullName,
    required this.phoneNumber,
    required this.address,
    required this.preferences,
    this.loyaltyPoints = 0,
    required this.createdAt,
    this.isActive = true,
    this.role = 'customer',
  });

  // Convert from Firestore document
  factory Customer.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    
    // Safe casting cho preferences array
    List<String> preferences = [];
    if (data['preferences'] != null) {
      final prefsData = data['preferences'];
      if (prefsData is List) {
        preferences = prefsData.map((item) => item.toString()).toList();
      }
    }
    
    return Customer(
      customerId: doc.id,
      email: data['email']?.toString() ?? '',
      fullName: data['fullName']?.toString() ?? '',
      phoneNumber: data['phoneNumber']?.toString() ?? '',
      address: data['address']?.toString() ?? '',
      preferences: preferences,
      loyaltyPoints: (data['loyaltyPoints'] as num?)?.toInt() ?? 0,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isActive: data['isActive'] as bool? ?? true,
      role: data['role']?.toString() ?? 'customer',
    );
  }

  // Convert to Firestore document
  Map<String, dynamic> toFirestore() {
    return {
      'email': email,
      'fullName': fullName,
      'phoneNumber': phoneNumber,
      'address': address,
      'preferences': preferences,
      'loyaltyPoints': loyaltyPoints,
      'createdAt': Timestamp.fromDate(createdAt),
      'isActive': isActive,
      'role': role,
    };
  }

  // Copy with method for updates
  Customer copyWith({
    String? email,
    String? fullName,
    String? phoneNumber,
    String? address,
    List<String>? preferences,
    int? loyaltyPoints,
    bool? isActive,
    String? role,
  }) {
    return Customer(
      customerId: customerId,
      email: email ?? this.email,
      fullName: fullName ?? this.fullName,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      address: address ?? this.address,
      preferences: preferences ?? this.preferences,
      loyaltyPoints: loyaltyPoints ?? this.loyaltyPoints,
      createdAt: createdAt,
      isActive: isActive ?? this.isActive,
      role: role ?? this.role,
    );
  }

  // Check if user is admin
  bool get isAdmin => role == 'admin';
}