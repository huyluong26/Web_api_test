import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../firebase_options.dart';

class FirebaseService {
  static FirebaseFirestore? _firestore;
  
  static FirebaseFirestore get firestore {
    _firestore ??= FirebaseFirestore.instance;
    return _firestore!;
  }

  // Initialize Firebase
  static Future<void> initialize() async {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  }

  // Collection references
  static CollectionReference get customersCollection =>
      firestore.collection('customers');
  
  static CollectionReference get menuItemsCollection =>
      firestore.collection('menu_items');
  
  static CollectionReference get reservationsCollection =>
      firestore.collection('reservations');
}