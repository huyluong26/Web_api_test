import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../models/reservation.dart';
import '../../providers/reservation_provider.dart';
import '../../providers/auth_provider.dart';

class ReservationDetailScreen extends StatefulWidget {
  final Reservation reservation;

  const ReservationDetailScreen({super.key, required this.reservation});

  @override
  State<ReservationDetailScreen> createState() => _ReservationDetailScreenState();
}

class _ReservationDetailScreenState extends State<ReservationDetailScreen> {
  String? _selectedPaymentMethod;

  Color _getStatusColor(String status) {
    switch (status) {
      case 'pending':
        return Colors.orange;
      case 'confirmed':
        return Colors.blue;
      case 'seated':
        return Colors.green;
      case 'completed':
        return Colors.grey;
      case 'cancelled':
        return Colors.red;
      case 'no_show':
        return Colors.red[300]!;
      default:
        return Colors.grey;
    }
  }

  String _getStatusText(String status) {
    switch (status) {
      case 'pending':
        return 'Chờ xác nhận';
      case 'confirmed':
        return 'Đã xác nhận';
      case 'seated':
        return 'Đã nhận bàn';
      case 'completed':
        return 'Hoàn thành';
      case 'cancelled':
        return 'Đã hủy';
      case 'no_show':
        return 'Không đến';
      default:
        return status;
    }
  }

  Future<void> _payReservation() async {
    if (_selectedPaymentMethod == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Vui lòng chọn phương thức thanh toán'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final reservationProvider = Provider.of<ReservationProvider>(context, listen: false);
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    
    bool success = await reservationProvider.payReservation(
      widget.reservation.reservationId,
      _selectedPaymentMethod!,
    );

    if (success && mounted) {
      // Refresh customer data để cập nhật loyalty points
      await authProvider.refreshCustomerData();
      
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Thanh toán thành công!'),
          backgroundColor: Colors.green,
        ),
      );
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(reservationProvider.error ?? 'Thanh toán thất bại'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chi Tiết Đặt Bàn'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Status and basic info
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Trạng thái:',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: _getStatusColor(widget.reservation.status),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Text(
                            _getStatusText(widget.reservation.status),
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    _buildInfoRow('Ngày giờ:', DateFormat('dd/MM/yyyy HH:mm').format(widget.reservation.reservationDate)),
                    _buildInfoRow('Số khách:', '${widget.reservation.numberOfGuests} người'),
                    if (widget.reservation.tableNumber != null)
                      _buildInfoRow('Số bàn:', widget.reservation.tableNumber!),
                    if (widget.reservation.specialRequests != null && widget.reservation.specialRequests!.isNotEmpty)
                      _buildInfoRow('Yêu cầu đặc biệt:', widget.reservation.specialRequests!),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            
            // Order items
            if (widget.reservation.orderItems.isNotEmpty) ...[
              const Text(
                'Món đã đặt:',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      ...widget.reservation.orderItems.map((orderItem) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text('${orderItem.itemName} x${orderItem.quantity}'),
                              ),
                              Text('${orderItem.subtotal.toStringAsFixed(0)}đ'),
                            ],
                          ),
                        );
                      }),
                      const Divider(),
                      _buildPriceRow('Tạm tính:', '${widget.reservation.subtotal.toStringAsFixed(0)}đ'),
                      _buildPriceRow('Phí phục vụ (10%):', '${widget.reservation.serviceCharge.toStringAsFixed(0)}đ'),
                      if (widget.reservation.discount > 0)
                        _buildPriceRow('Giảm giá:', '-${widget.reservation.discount.toStringAsFixed(0)}đ', color: Colors.green),
                      const Divider(),
                      _buildPriceRow(
                        'Tổng cộng:',
                        '${widget.reservation.total.toStringAsFixed(0)}đ',
                        isTotal: true,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],
            
            // Payment section
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Thanh toán:',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    _buildInfoRow('Trạng thái thanh toán:', widget.reservation.paymentStatus == 'paid' ? 'Đã thanh toán' : 'Chưa thanh toán'),
                    if (widget.reservation.paymentMethod != null)
                      _buildInfoRow('Phương thức:', widget.reservation.paymentMethod!),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            
            // Loyalty points info
            Consumer<AuthProvider>(
              builder: (context, authProvider, child) {
                if (authProvider.currentCustomer != null) {
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Điểm tích lũy:',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          _buildInfoRow('Điểm hiện có:', '${authProvider.currentCustomer!.loyaltyPoints} điểm'),
                          const Text(
                            'Lưu ý: 1 điểm = 1,000đ giảm giá (tối đa 50% tổng bill)',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }
                return const SizedBox.shrink();
              },
            ),
            const SizedBox(height: 24),
            
            // Payment button
            if (widget.reservation.status == 'seated' && widget.reservation.paymentStatus == 'pending')
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Chọn phương thức thanh toán:',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  ...['cash', 'card', 'online'].map((method) {
                    String methodText = method == 'cash' ? 'Tiền mặt' : 
                                      method == 'card' ? 'Thẻ' : 'Online';
                    return RadioListTile<String>(
                      title: Text(methodText),
                      value: method,
                      groupValue: _selectedPaymentMethod,
                      onChanged: (value) {
                        setState(() {
                          _selectedPaymentMethod = value;
                        });
                      },
                    );
                  }),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: Consumer<ReservationProvider>(
                      builder: (context, reservationProvider, child) {
                        return ElevatedButton(
                          onPressed: reservationProvider.isLoading ? null : _payReservation,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.orange,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                          ),
                          child: reservationProvider.isLoading
                              ? const CircularProgressIndicator(color: Colors.white)
                              : const Text(
                                  'Thanh Toán',
                                  style: TextStyle(fontSize: 16),
                                ),
                        );
                      },
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  Widget _buildPriceRow(String label, String value, {bool isTotal = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
              color: color,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
              color: color ?? (isTotal ? Colors.orange : null),
            ),
          ),
        ],
      ),
    );
  }
}