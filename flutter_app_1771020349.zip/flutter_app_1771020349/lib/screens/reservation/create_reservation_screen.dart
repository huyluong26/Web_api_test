import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/auth_provider.dart';
import '../../providers/reservation_provider.dart';
import '../../providers/menu_provider.dart';
import '../../models/menu_item.dart';

class CreateReservationScreen extends StatefulWidget {
  const CreateReservationScreen({super.key});

  @override
  State<CreateReservationScreen> createState() => _CreateReservationScreenState();
}

class _CreateReservationScreenState extends State<CreateReservationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _specialRequestsController = TextEditingController();
  
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  int _numberOfGuests = 2;
  String? _currentReservationId;
  
  @override
  void dispose() {
    _specialRequestsController.dispose();
    super.dispose();
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  Future<void> _createReservation() async {
    if (_formKey.currentState!.validate()) {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final reservationProvider = Provider.of<ReservationProvider>(context, listen: false);
      
      if (authProvider.currentCustomer == null) return;

      DateTime reservationDateTime = DateTime(
        _selectedDate.year,
        _selectedDate.month,
        _selectedDate.day,
        _selectedTime.hour,
        _selectedTime.minute,
      );

      String? reservationId = await reservationProvider.createReservation(
        customerId: authProvider.currentCustomer!.customerId,
        reservationDate: reservationDateTime,
        numberOfGuests: _numberOfGuests,
        specialRequests: _specialRequestsController.text.trim().isEmpty 
            ? null 
            : _specialRequestsController.text.trim(),
      );

      if (reservationId != null && mounted) {
        setState(() {
          _currentReservationId = reservationId;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Đặt bàn thành công! Bây giờ bạn có thể thêm món.'),
            backgroundColor: Colors.green,
          ),
        );
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(reservationProvider.error ?? 'Đặt bàn thất bại'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  } 
 @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Đặt Bàn Mới',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 24),
              
              // Date Selection
              Card(
                child: ListTile(
                  leading: const Icon(Icons.calendar_today),
                  title: const Text('Ngày đặt bàn'),
                  subtitle: Text(DateFormat('dd/MM/yyyy').format(_selectedDate)),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: _selectDate,
                ),
              ),
              const SizedBox(height: 16),
              
              // Time Selection
              Card(
                child: ListTile(
                  leading: const Icon(Icons.access_time),
                  title: const Text('Giờ đặt bàn'),
                  subtitle: Text(_selectedTime.format(context)),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: _selectTime,
                ),
              ),
              const SizedBox(height: 16),
              
              // Number of Guests
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Số lượng khách',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          IconButton(
                            onPressed: _numberOfGuests > 1
                                ? () => setState(() => _numberOfGuests--)
                                : null,
                            icon: const Icon(Icons.remove),
                          ),
                          Text(
                            '$_numberOfGuests',
                            style: const TextStyle(fontSize: 18),
                          ),
                          IconButton(
                            onPressed: _numberOfGuests < 20
                                ? () => setState(() => _numberOfGuests++)
                                : null,
                            icon: const Icon(Icons.add),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              
              // Special Requests
              TextFormField(
                controller: _specialRequestsController,
                decoration: const InputDecoration(
                  labelText: 'Yêu cầu đặc biệt (tùy chọn)',
                  border: OutlineInputBorder(),
                  hintText: 'Ví dụ: Bàn gần cửa sổ, không gia vị...',
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 24),
              
              // Create Reservation Button
              if (_currentReservationId == null)
                SizedBox(
                  width: double.infinity,
                  child: Consumer<ReservationProvider>(
                    builder: (context, reservationProvider, child) {
                      return ElevatedButton(
                        onPressed: reservationProvider.isLoading ? null : _createReservation,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                        ),
                        child: reservationProvider.isLoading
                            ? const CircularProgressIndicator(color: Colors.white)
                            : const Text(
                                'Tạo Đặt Bàn',
                                style: TextStyle(fontSize: 16),
                              ),
                      );
                    },
                  ),
                ),
              
              // Add Items Section
              if (_currentReservationId != null) ...[
                const Divider(height: 32),
                const Text(
                  'Thêm Món Ăn',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                _buildMenuItemsList(),
                const SizedBox(height: 16),
                _buildCurrentOrder(),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMenuItemsList() {
    return Consumer<MenuProvider>(
      builder: (context, menuProvider, child) {
        if (menuProvider.isLoading) {
          return const Center(child: CircularProgressIndicator());
        }

        if (menuProvider.menuItems.isEmpty) {
          return const Text('Không có món ăn nào');
        }

        return SizedBox(
          height: 200,
          child: ListView.builder(
            itemCount: menuProvider.menuItems.length,
            itemBuilder: (context, index) {
              final menuItem = menuProvider.menuItems[index];
              return Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundImage: menuItem.imageUrl.isNotEmpty
                        ? NetworkImage(menuItem.imageUrl)
                        : null,
                    child: menuItem.imageUrl.isEmpty
                        ? const Icon(Icons.restaurant)
                        : null,
                  ),
                  title: Text(menuItem.name),
                  subtitle: Text('${menuItem.price.toStringAsFixed(0)}đ'),
                  trailing: menuItem.isAvailable
                      ? IconButton(
                          onPressed: () => _addItemToReservation(menuItem),
                          icon: const Icon(Icons.add_circle, color: Colors.orange),
                        )
                      : const Text('Hết món', style: TextStyle(color: Colors.red)),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildCurrentOrder() {
    return Consumer<ReservationProvider>(
      builder: (context, reservationProvider, child) {
        final currentReservation = reservationProvider.currentReservation;
        
        if (currentReservation == null || currentReservation.orderItems.isEmpty) {
          return const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('Chưa có món nào được thêm'),
            ),
          );
        }

        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Đơn hàng hiện tại:',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                ...currentReservation.orderItems.map((orderItem) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text('${orderItem.itemName} x${orderItem.quantity}'),
                        ),
                        Text('${orderItem.subtotal.toStringAsFixed(0)}đ'),
                      ],
                    ),
                  );
                }),
                const Divider(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Tổng cộng:', style: TextStyle(fontWeight: FontWeight.bold)),
                    Text(
                      '${currentReservation.total.toStringAsFixed(0)}đ',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.orange,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _addItemToReservation(MenuItem menuItem) async {
    if (_currentReservationId == null) return;

    final reservationProvider = Provider.of<ReservationProvider>(context, listen: false);
    
    bool success = await reservationProvider.addItemToReservation(
      _currentReservationId!,
      menuItem.itemId,
      1,
    );

    if (success && mounted) {
      // Set current reservation để hiển thị order items
      reservationProvider.setCurrentReservation(_currentReservationId!);
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Đã thêm ${menuItem.name} vào đơn'),
          backgroundColor: Colors.green,
        ),
      );
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(reservationProvider.error ?? 'Thêm món thất bại'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
}