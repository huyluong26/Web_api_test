import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/menu_provider.dart';
import '../../models/menu_item.dart';
import 'menu_item_detail_screen.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Search and Filter Section
        Container(
          padding: const EdgeInsets.all(16),
          color: Colors.grey[100],
          child: Column(
            children: [
              // Search Bar
              TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Tìm kiếm món ăn...',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: IconButton(
                    onPressed: () {
                      _searchController.clear();
                      Provider.of<MenuProvider>(context, listen: false)
                          .searchMenuItems('');
                    },
                    icon: const Icon(Icons.clear),
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                onChanged: (value) {
                  Provider.of<MenuProvider>(context, listen: false)
                      .searchMenuItems(value);
                },
              ),
              const SizedBox(height: 12),
              // Filter Chips
              Consumer<MenuProvider>(
                builder: (context, menuProvider, child) {
                  return SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        // Category Filter
                        ...menuProvider.categories.map((category) {
                          return Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: FilterChip(
                              label: Text(category),
                              selected: menuProvider.selectedCategory == category,
                              onSelected: (selected) {
                                menuProvider.filterByCategory(
                                  selected ? category : null,
                                );
                              },
                            ),
                          );
                        }),
                        // Vegetarian Filter
                        FilterChip(
                          label: const Text('Chay'),
                          selected: menuProvider.showVegetarianOnly,
                          onSelected: menuProvider.toggleVegetarianFilter,
                        ),
                        const SizedBox(width: 8),
                        // Spicy Filter
                        FilterChip(
                          label: const Text('Cay'),
                          selected: menuProvider.showSpicyOnly,
                          onSelected: menuProvider.toggleSpicyFilter,
                        ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        ),     
   // Menu Items List
        Expanded(
          child: Consumer<MenuProvider>(
            builder: (context, menuProvider, child) {
              if (menuProvider.isLoading) {
                return const Center(child: CircularProgressIndicator());
              }

              if (menuProvider.error != null) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Lỗi: ${menuProvider.error}',
                        style: const TextStyle(color: Colors.red),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => menuProvider.refresh(),
                        child: const Text('Thử lại'),
                      ),
                    ],
                  ),
                );
              }

              if (menuProvider.menuItems.isEmpty) {
                return const Center(
                  child: Text('Không tìm thấy món ăn nào'),
                );
              }

              return GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.75,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemCount: menuProvider.menuItems.length,
                itemBuilder: (context, index) {
                  final menuItem = menuProvider.menuItems[index];
                  return _MenuItemCard(menuItem: menuItem);
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class _MenuItemCard extends StatelessWidget {
  final MenuItem menuItem;

  const _MenuItemCard({required this.menuItem});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => MenuItemDetailScreen(menuItem: menuItem),
            ),
          );
        },
        borderRadius: BorderRadius.circular(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image
            Expanded(
              flex: 3,
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                  color: Colors.grey[300],
                ),
                child: menuItem.imageUrl.isNotEmpty
                    ? ClipRRect(
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                        child: Image.network(
                          menuItem.imageUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return const Icon(Icons.restaurant, size: 50);
                          },
                        ),
                      )
                    : const Icon(Icons.restaurant, size: 50),
              ),
            ),
            // Content
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Name and badges
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            menuItem.name,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (menuItem.isVegetarian)
                          const Icon(Icons.eco, color: Colors.green, size: 16),
                        if (menuItem.isSpicy)
                          const Icon(Icons.local_fire_department, color: Colors.red, size: 16),
                      ],
                    ),
                    const SizedBox(height: 4),
                    // Price and rating
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '${menuItem.price.toStringAsFixed(0)}đ',
                          style: const TextStyle(
                            color: Colors.orange,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Row(
                          children: [
                            const Icon(Icons.star, color: Colors.amber, size: 16),
                            Text(
                              menuItem.rating.toStringAsFixed(1),
                              style: const TextStyle(fontSize: 12),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    // Availability badge
                    if (!menuItem.isAvailable)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Text(
                          'Hết món',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}