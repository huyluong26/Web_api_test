import 'package:flutter/material.dart';
import '../../repositories/customer_repository.dart';
import '../../repositories/menu_item_repository.dart';
import '../../repositories/reservation_repository.dart';
import '../../models/customer.dart';
import '../../models/menu_item.dart';
import '../../models/reservation.dart';
import '../../utils/rich_sample_data.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> with TickerProviderStateMixin {
  late TabController _tabController;
  final CustomerRepository _customerRepository = CustomerRepository();
  final MenuItemRepository _menuItemRepository = MenuItemRepository();
  final ReservationRepository _reservationRepository = ReservationRepository();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel - 2151061234'),
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.people), text: 'Customers'),
            Tab(icon: Icon(Icons.restaurant_menu), text: 'Menu Items'),
            Tab(icon: Icon(Icons.book_online), text: 'Reservations'),
          ],
        ),
        actions: [
          IconButton(
            onPressed: _initializeRichData,
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh Data',
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildCustomersTab(),
          _buildMenuItemsTab(),
          _buildReservationsTab(),
        ],
      ),
    );
  }

  Widget _buildCustomersTab() {
    return FutureBuilder<List<Customer>>(
      future: _customerRepository.getAllCustomers(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Error: ${snapshot.error}'),
                ElevatedButton(
                  onPressed: () => setState(() {}),
                  child: const Text('Retry'),
                ),
              ],
            ),
          );
        }

        List<Customer> customers = snapshot.data ?? [];

        return Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Text(
                    'Total Customers: ${customers.length}',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  ElevatedButton.icon(
                    onPressed: _showAddCustomerDialog,
                    icon: const Icon(Icons.add),
                    label: const Text('Add Customer'),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: customers.length,
                itemBuilder: (context, index) {
                  Customer customer = customers[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.blue,
                        child: Text(customer.fullName[0]),
                      ),
                      title: Text(customer.fullName),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(customer.email),
                          Text('Phone: ${customer.phoneNumber}'),
                          Text('Loyalty Points: ${customer.loyaltyPoints}'),
                          Text('Preferences: ${customer.preferences.join(', ')}'),
                        ],
                      ),
                      trailing: PopupMenuButton(
                        itemBuilder: (context) => [
                          PopupMenuItem(
                            value: 'edit',
                            child: const Text('Edit'),
                          ),
                          PopupMenuItem(
                            value: 'points',
                            child: const Text('Update Points'),
                          ),
                        ],
                        onSelected: (value) {
                          if (value == 'edit') {
                            _showEditCustomerDialog(customer);
                          } else if (value == 'points') {
                            _showUpdatePointsDialog(customer);
                          }
                        },
                      ),
                      isThreeLine: true,
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildMenuItemsTab() {
    return FutureBuilder<List<MenuItem>>(
      future: _menuItemRepository.getAllMenuItems(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Error: ${snapshot.error}'),
                ElevatedButton(
                  onPressed: () => setState(() {}),
                  child: const Text('Retry'),
                ),
              ],
            ),
          );
        }

        List<MenuItem> menuItems = snapshot.data ?? [];

        return Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Text(
                    'Total Menu Items: ${menuItems.length}',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  ElevatedButton.icon(
                    onPressed: _showAddMenuItemDialog,
                    icon: const Icon(Icons.add),
                    label: const Text('Add Menu Item'),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: menuItems.length,
                itemBuilder: (context, index) {
                  MenuItem item = menuItems[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: item.isAvailable ? Colors.green : Colors.red,
                        child: Text(item.name[0]),
                      ),
                      title: Text(item.name),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Category: ${item.category}'),
                          Text('Price: ${item.price.toStringAsFixed(0)}đ'),
                          Text('Rating: ${item.rating}/5.0'),
                          Row(
                            children: [
                              if (item.isVegetarian) 
                                const Chip(label: Text('Chay'), backgroundColor: Colors.green),
                              if (item.isSpicy) 
                                const Chip(label: Text('Cay'), backgroundColor: Colors.red),
                              if (!item.isAvailable) 
                                const Chip(label: Text('Hết món'), backgroundColor: Colors.grey),
                            ],
                          ),
                        ],
                      ),
                      trailing: PopupMenuButton(
                        itemBuilder: (context) => [
                          PopupMenuItem(
                            value: 'edit',
                            child: const Text('Edit'),
                          ),
                          PopupMenuItem(
                            value: 'toggle',
                            child: Text(item.isAvailable ? 'Mark Unavailable' : 'Mark Available'),
                          ),
                        ],
                        onSelected: (value) {
                          if (value == 'edit') {
                            _showEditMenuItemDialog(item);
                          } else if (value == 'toggle') {
                            _toggleMenuItemAvailability(item);
                          }
                        },
                      ),
                      isThreeLine: true,
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildReservationsTab() {
    return FutureBuilder<List<Reservation>>(
      future: _getAllReservations(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Error: ${snapshot.error}'),
                ElevatedButton(
                  onPressed: () => setState(() {}),
                  child: const Text('Retry'),
                ),
              ],
            ),
          );
        }

        List<Reservation> reservations = snapshot.data ?? [];

        return Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              child: Text(
                'Total Reservations: ${reservations.length}',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: reservations.length,
                itemBuilder: (context, index) {
                  Reservation reservation = reservations[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: _getStatusColor(reservation.status),
                        child: Text('${reservation.numberOfGuests}'),
                      ),
                      title: Text('Reservation ${reservation.reservationId.substring(0, 8)}...'),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Date: ${reservation.reservationDate.toString().substring(0, 16)}'),
                          Text('Status: ${reservation.status}'),
                          Text('Guests: ${reservation.numberOfGuests}'),
                          if (reservation.tableNumber != null)
                            Text('Table: ${reservation.tableNumber}'),
                          Text('Total: ${reservation.total.toStringAsFixed(0)}đ'),
                        ],
                      ),
                      trailing: PopupMenuButton(
                        itemBuilder: (context) => [
                          if (reservation.status == 'pending')
                            PopupMenuItem(
                              value: 'confirm',
                              child: const Text('Confirm'),
                            ),
                          if (reservation.status == 'confirmed')
                            PopupMenuItem(
                              value: 'seat',
                              child: const Text('Mark Seated'),
                            ),
                        ],
                        onSelected: (value) {
                          if (value == 'confirm') {
                            _showConfirmReservationDialog(reservation);
                          } else if (value == 'seat') {
                            _updateReservationStatus(reservation.reservationId, 'seated');
                          }
                        },
                      ),
                      isThreeLine: true,
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'pending': return Colors.orange;
      case 'confirmed': return Colors.blue;
      case 'seated': return Colors.green;
      case 'completed': return Colors.grey;
      case 'cancelled': return Colors.red;
      default: return Colors.grey;
    }
  }

  Future<List<Reservation>> _getAllReservations() async {
    // Get all customers first, then get their reservations
    List<Customer> customers = await _customerRepository.getAllCustomers();
    List<Reservation> allReservations = [];
    
    for (Customer customer in customers) {
      try {
        List<Reservation> customerReservations = await _reservationRepository.getReservationsByCustomer(customer.customerId);
        allReservations.addAll(customerReservations);
      } catch (e) {
        print('Error getting reservations for ${customer.customerId}: $e');
      }
    }
    
    // Sort by creation date
    allReservations.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return allReservations;
  }

  Future<void> _initializeRichData() async {
    try {
      await RichSampleData.initializeRichData();
      setState(() {}); // Refresh all tabs
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Rich data initialized successfully!'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error initializing data: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _showAddCustomerDialog() {
    // Implementation for adding customer
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Customer'),
        content: const Text('Add customer functionality would be implemented here'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showEditCustomerDialog(Customer customer) {
    // Implementation for editing customer
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Customer'),
        content: Text('Edit customer: ${customer.fullName}'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showUpdatePointsDialog(Customer customer) {
    final TextEditingController pointsController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Update Loyalty Points'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Current points: ${customer.loyaltyPoints}'),
            const SizedBox(height: 16),
            TextField(
              controller: pointsController,
              decoration: const InputDecoration(
                labelText: 'Points to add/subtract',
                hintText: 'Enter positive or negative number',
              ),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              try {
                int points = int.parse(pointsController.text);
                await _customerRepository.updateLoyaltyPoints(customer.customerId, points);
                Navigator.pop(context);
                setState(() {});
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Points updated successfully!')),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Error: $e')),
                );
              }
            },
            child: const Text('Update'),
          ),
        ],
      ),
    );
  }

  void _showAddMenuItemDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Menu Item'),
        content: const Text('Add menu item functionality would be implemented here'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showEditMenuItemDialog(MenuItem item) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Menu Item'),
        content: Text('Edit menu item: ${item.name}'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Future<void> _toggleMenuItemAvailability(MenuItem item) async {
    try {
      await _menuItemRepository.updateMenuItem(item.itemId, {
        'isAvailable': !item.isAvailable,
      });
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${item.name} is now ${!item.isAvailable ? 'available' : 'unavailable'}'),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  void _showConfirmReservationDialog(Reservation reservation) {
    final TextEditingController tableController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Reservation'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Reservation for ${reservation.numberOfGuests} guests'),
            const SizedBox(height: 16),
            TextField(
              controller: tableController,
              decoration: const InputDecoration(
                labelText: 'Table Number',
                hintText: 'e.g., B05',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              try {
                await _reservationRepository.confirmReservation(
                  reservation.reservationId,
                  tableController.text,
                );
                Navigator.pop(context);
                setState(() {});
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Reservation confirmed!')),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Error: $e')),
                );
              }
            },
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
  }

  Future<void> _updateReservationStatus(String reservationId, String status) async {
    try {
      await _reservationRepository.updateReservationStatus(reservationId, status);
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Reservation status updated to $status')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }
}