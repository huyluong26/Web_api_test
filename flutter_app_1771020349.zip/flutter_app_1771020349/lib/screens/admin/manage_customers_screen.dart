import 'package:flutter/material.dart';
import '../../repositories/customer_repository.dart';
import '../../models/customer.dart';

class ManageCustomersScreen extends StatefulWidget {
  const ManageCustomersScreen({super.key});

  @override
  State<ManageCustomersScreen> createState() => _ManageCustomersScreenState();
}

class _ManageCustomersScreenState extends State<ManageCustomersScreen> {
  final CustomerRepository _customerRepository = CustomerRepository();
  List<Customer> _customers = [];
  bool _isLoading = true;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadCustomers();
  }

  Future<void> _loadCustomers() async {
    setState(() => _isLoading = true);
    try {
      _customers = await _customerRepository.getAllCustomers();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi tải khách hàng: $e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  List<Customer> get _filteredCustomers {
    if (_searchQuery.isEmpty) return _customers;
    return _customers.where((customer) {
      return customer.fullName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
             customer.email.toLowerCase().contains(_searchQuery.toLowerCase()) ||
             customer.phoneNumber.contains(_searchQuery);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quản lý khách hàng'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            onPressed: _showAddCustomerDialog,
            icon: const Icon(Icons.add),
            tooltip: 'Thêm khách hàng',
          ),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          Container(
            padding: const EdgeInsets.all(16),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Tìm kiếm khách hàng...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onChanged: (value) {
                setState(() => _searchQuery = value);
              },
            ),
          ),
          
          // Customer count
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Text(
                  'Tổng số khách hàng: ${_filteredCustomers.length}',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                IconButton(
                  onPressed: _loadCustomers,
                  icon: const Icon(Icons.refresh),
                  tooltip: 'Làm mới',
                ),
              ],
            ),
          ),
          
          // Customer list
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredCustomers.isEmpty
                    ? const Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.people_outline, size: 64, color: Colors.grey),
                            SizedBox(height: 16),
                            Text('Không có khách hàng nào'),
                          ],
                        ),
                      )
                    : ListView.builder(
                        itemCount: _filteredCustomers.length,
                        itemBuilder: (context, index) {
                          final customer = _filteredCustomers[index];
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundColor: customer.isAdmin ? Colors.red : Colors.blue,
                                child: Text(
                                  customer.fullName.isNotEmpty ? customer.fullName[0] : '?',
                                  style: const TextStyle(color: Colors.white),
                                ),
                              ),
                              title: Row(
                                children: [
                                  Expanded(child: Text(customer.fullName)),
                                  if (customer.isAdmin)
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: Colors.red,
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: const Text(
                                        'ADMIN',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(customer.email),
                                  Text('SĐT: ${customer.phoneNumber}'),
                                  Text('Điểm tích lũy: ${customer.loyaltyPoints}'),
                                  if (customer.preferences.isNotEmpty)
                                    Text('Sở thích: ${customer.preferences.join(', ')}'),
                                ],
                              ),
                              trailing: PopupMenuButton(
                                itemBuilder: (context) => [
                                  const PopupMenuItem(
                                    value: 'edit',
                                    child: Row(
                                      children: [
                                        Icon(Icons.edit, size: 16),
                                        SizedBox(width: 8),
                                        Text('Sửa'),
                                      ],
                                    ),
                                  ),
                                  const PopupMenuItem(
                                    value: 'points',
                                    child: Row(
                                      children: [
                                        Icon(Icons.stars, size: 16),
                                        SizedBox(width: 8),
                                        Text('Cập nhật điểm'),
                                      ],
                                    ),
                                  ),
                                  if (!customer.isAdmin)
                                    const PopupMenuItem(
                                      value: 'delete',
                                      child: Row(
                                        children: [
                                          Icon(Icons.delete, size: 16, color: Colors.red),
                                          SizedBox(width: 8),
                                          Text('Xóa', style: TextStyle(color: Colors.red)),
                                        ],
                                      ),
                                    ),
                                ],
                                onSelected: (value) {
                                  switch (value) {
                                    case 'edit':
                                      _showEditCustomerDialog(customer);
                                      break;
                                    case 'points':
                                      _showUpdatePointsDialog(customer);
                                      break;
                                    case 'delete':
                                      _showDeleteConfirmDialog(customer);
                                      break;
                                  }
                                },
                              ),
                              isThreeLine: true,
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  void _showAddCustomerDialog() {
    final formKey = GlobalKey<FormState>();
    final emailController = TextEditingController();
    final nameController = TextEditingController();
    final phoneController = TextEditingController();
    final addressController = TextEditingController();
    List<String> selectedPreferences = [];

    final availablePreferences = ['vegetarian', 'spicy', 'seafood', 'meat', 'dessert', 'healthy'];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Thêm khách hàng mới'),
        content: SizedBox(
          width: double.maxFinite,
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: emailController,
                    decoration: const InputDecoration(labelText: 'Email'),
                    validator: (value) => value?.isEmpty ?? true ? 'Vui lòng nhập email' : null,
                  ),
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(labelText: 'Họ tên'),
                    validator: (value) => value?.isEmpty ?? true ? 'Vui lòng nhập họ tên' : null,
                  ),
                  TextFormField(
                    controller: phoneController,
                    decoration: const InputDecoration(labelText: 'Số điện thoại'),
                    validator: (value) => value?.isEmpty ?? true ? 'Vui lòng nhập số điện thoại' : null,
                  ),
                  TextFormField(
                    controller: addressController,
                    decoration: const InputDecoration(labelText: 'Địa chỉ'),
                    validator: (value) => value?.isEmpty ?? true ? 'Vui lòng nhập địa chỉ' : null,
                  ),
                  const SizedBox(height: 16),
                  const Text('Sở thích:', style: TextStyle(fontWeight: FontWeight.bold)),
                  StatefulBuilder(
                    builder: (context, setState) => Wrap(
                      spacing: 8,
                      children: availablePreferences.map((pref) {
                        return FilterChip(
                          label: Text(pref),
                          selected: selectedPreferences.contains(pref),
                          onSelected: (selected) {
                            setState(() {
                              if (selected) {
                                selectedPreferences.add(pref);
                              } else {
                                selectedPreferences.remove(pref);
                              }
                            });
                          },
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (formKey.currentState!.validate()) {
                try {
                  final customer = Customer(
                    customerId: '',
                    email: emailController.text,
                    fullName: nameController.text,
                    phoneNumber: phoneController.text,
                    address: addressController.text,
                    preferences: selectedPreferences,
                    createdAt: DateTime.now(),
                  );
                  
                  await _customerRepository.addCustomer(customer);
                  Navigator.pop(context);
                  _loadCustomers();
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Thêm khách hàng thành công!')),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Lỗi: $e')),
                  );
                }
              }
            },
            child: const Text('Thêm'),
          ),
        ],
      ),
    );
  }

  void _showEditCustomerDialog(Customer customer) {
    final formKey = GlobalKey<FormState>();
    final nameController = TextEditingController(text: customer.fullName);
    final phoneController = TextEditingController(text: customer.phoneNumber);
    final addressController = TextEditingController(text: customer.address);
    List<String> selectedPreferences = List.from(customer.preferences);

    final availablePreferences = ['vegetarian', 'spicy', 'seafood', 'meat', 'dessert', 'healthy'];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sửa thông tin khách hàng'),
        content: SizedBox(
          width: double.maxFinite,
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(labelText: 'Họ tên'),
                    validator: (value) => value?.isEmpty ?? true ? 'Vui lòng nhập họ tên' : null,
                  ),
                  TextFormField(
                    controller: phoneController,
                    decoration: const InputDecoration(labelText: 'Số điện thoại'),
                    validator: (value) => value?.isEmpty ?? true ? 'Vui lòng nhập số điện thoại' : null,
                  ),
                  TextFormField(
                    controller: addressController,
                    decoration: const InputDecoration(labelText: 'Địa chỉ'),
                    validator: (value) => value?.isEmpty ?? true ? 'Vui lòng nhập địa chỉ' : null,
                  ),
                  const SizedBox(height: 16),
                  const Text('Sở thích:', style: TextStyle(fontWeight: FontWeight.bold)),
                  StatefulBuilder(
                    builder: (context, setState) => Wrap(
                      spacing: 8,
                      children: availablePreferences.map((pref) {
                        return FilterChip(
                          label: Text(pref),
                          selected: selectedPreferences.contains(pref),
                          onSelected: (selected) {
                            setState(() {
                              if (selected) {
                                selectedPreferences.add(pref);
                              } else {
                                selectedPreferences.remove(pref);
                              }
                            });
                          },
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (formKey.currentState!.validate()) {
                try {
                  await _customerRepository.updateCustomer(customer.customerId, {
                    'fullName': nameController.text,
                    'phoneNumber': phoneController.text,
                    'address': addressController.text,
                    'preferences': selectedPreferences,
                  });
                  
                  Navigator.pop(context);
                  _loadCustomers();
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Cập nhật thành công!')),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Lỗi: $e')),
                  );
                }
              }
            },
            child: const Text('Cập nhật'),
          ),
        ],
      ),
    );
  }

  void _showUpdatePointsDialog(Customer customer) {
    final pointsController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Cập nhật điểm tích lũy'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Điểm hiện tại: ${customer.loyaltyPoints}'),
            const SizedBox(height: 16),
            TextField(
              controller: pointsController,
              decoration: const InputDecoration(
                labelText: 'Điểm cần thêm/trừ',
                hintText: 'Nhập số dương để cộng, số âm để trừ',
              ),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                int points = int.parse(pointsController.text);
                await _customerRepository.updateLoyaltyPoints(customer.customerId, points);
                Navigator.pop(context);
                _loadCustomers();
                
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Cập nhật điểm thành công!')),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Lỗi: $e')),
                );
              }
            },
            child: const Text('Cập nhật'),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmDialog(Customer customer) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Xác nhận xóa'),
        content: Text('Bạn có chắc chắn muốn xóa khách hàng "${customer.fullName}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                await _customerRepository.updateCustomer(customer.customerId, {
                  'isActive': false,
                });
                Navigator.pop(context);
                _loadCustomers();
                
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Xóa khách hàng thành công!')),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Lỗi: $e')),
                );
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Xóa', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}