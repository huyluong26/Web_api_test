import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../repositories/reservation_repository.dart';
import '../../repositories/customer_repository.dart';
import '../../models/reservation.dart';
import '../../models/customer.dart';

class ManageReservationsScreen extends StatefulWidget {
  const ManageReservationsScreen({super.key});

  @override
  State<ManageReservationsScreen> createState() => _ManageReservationsScreenState();
}

class _ManageReservationsScreenState extends State<ManageReservationsScreen> {
  final ReservationRepository _reservationRepository = ReservationRepository();
  final CustomerRepository _customerRepository = CustomerRepository();
  List<Reservation> _reservations = [];
  Map<String, Customer> _customersMap = {};
  bool _isLoading = true;
  String? _selectedStatus;

  final List<String> _statuses = [
    'pending',
    'confirmed', 
    'seated',
    'completed',
    'cancelled',
    'no_show'
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      // Load customers first
      List<Customer> customers = await _customerRepository.getAllCustomers();
      _customersMap = {for (var c in customers) c.customerId: c};
      
      // Load all reservations
      _reservations = [];
      for (Customer customer in customers) {
        try {
          List<Reservation> customerReservations = 
              await _reservationRepository.getReservationsByCustomer(customer.customerId);
          _reservations.addAll(customerReservations);
        } catch (e) {
          print('Error loading reservations for ${customer.customerId}: $e');
        }
      }
      
      // Sort by creation date
      _reservations.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi tải dữ liệu: $e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  List<Reservation> get _filteredReservations {
    if (_selectedStatus == null) return _reservations;
    return _reservations.where((r) => r.status == _selectedStatus).toList();
  }

  String _getStatusText(String status) {
    switch (status) {
      case 'pending': return 'Chờ xác nhận';
      case 'confirmed': return 'Đã xác nhận';
      case 'seated': return 'Đã nhận bàn';
      case 'completed': return 'Hoàn thành';
      case 'cancelled': return 'Đã hủy';
      case 'no_show': return 'Không đến';
      default: return status;
    }
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'pending': return Colors.orange;
      case 'confirmed': return Colors.blue;
      case 'seated': return Colors.green;
      case 'completed': return Colors.grey;
      case 'cancelled': return Colors.red;
      case 'no_show': return Colors.red[300]!;
      default: return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quản lý đặt bàn'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          // Filter by status
          Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      FilterChip(
                        label: const Text('Tất cả'),
                        selected: _selectedStatus == null,
                        onSelected: (selected) {
                          setState(() => _selectedStatus = null);
                        },
                      ),
                      const SizedBox(width: 8),
                      ..._statuses.map((status) {
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: FilterChip(
                            label: Text(_getStatusText(status)),
                            selected: _selectedStatus == status,
                            selectedColor: _getStatusColor(status).withOpacity(0.3),
                            onSelected: (selected) {
                              setState(() {
                                _selectedStatus = selected ? status : null;
                              });
                            },
                          ),
                        );
                      }),
                    ],
                  ),
                ),
              ],
            ),
          ),
          
          // Reservation count
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Text(
                  'Tổng số đặt bàn: ${_filteredReservations.length}',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                IconButton(
                  onPressed: _loadData,
                  icon: const Icon(Icons.refresh),
                  tooltip: 'Làm mới',
                ),
              ],
            ),
          ),
          
          // Reservations list
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredReservations.isEmpty
                    ? const Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.book_online, size: 64, color: Colors.grey),
                            SizedBox(height: 16),
                            Text('Không có đặt bàn nào'),
                          ],
                        ),
                      )
                    : ListView.builder(
                        itemCount: _filteredReservations.length,
                        itemBuilder: (context, index) {
                          final reservation = _filteredReservations[index];
                          final customer = _customersMap[reservation.customerId];
                          
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            child: ExpansionTile(
                              leading: CircleAvatar(
                                backgroundColor: _getStatusColor(reservation.status),
                                child: Text('${reservation.numberOfGuests}'),
                              ),
                              title: Text(
                                customer?.fullName ?? 'Unknown Customer',
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Ngày: ${DateFormat('dd/MM/yyyy HH:mm').format(reservation.reservationDate)}'),
                                  Text('Trạng thái: ${_getStatusText(reservation.status)}'),
                                  if (reservation.tableNumber != null)
                                    Text('Bàn: ${reservation.tableNumber}'),
                                ],
                              ),
                              trailing: PopupMenuButton(
                                itemBuilder: (context) => [
                                  if (reservation.status == 'pending')
                                    const PopupMenuItem(
                                      value: 'confirm',
                                      child: Text('Xác nhận'),
                                    ),
                                  if (reservation.status == 'confirmed')
                                    const PopupMenuItem(
                                      value: 'seat',
                                      child: Text('Nhận bàn'),
                                    ),
                                  if (reservation.status == 'pending' || reservation.status == 'confirmed')
                                    const PopupMenuItem(
                                      value: 'cancel',
                                      child: Text('Hủy', style: TextStyle(color: Colors.red)),
                                    ),
                                ],
                                onSelected: (value) {
                                  switch (value) {
                                    case 'confirm':
                                      _showConfirmDialog(reservation);
                                      break;
                                    case 'seat':
                                      _updateStatus(reservation.reservationId, 'seated');
                                      break;
                                    case 'cancel':
                                      _updateStatus(reservation.reservationId, 'cancelled');
                                      break;
                                  }
                                },
                              ),
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      if (customer != null) ...[
                                        Text('Email: ${customer.email}'),
                                        Text('SĐT: ${customer.phoneNumber}'),
                                        const SizedBox(height: 8),
                                      ],
                                      if (reservation.specialRequests != null)
                                        Text('Yêu cầu: ${reservation.specialRequests}'),
                                      const SizedBox(height: 8),
                                      if (reservation.orderItems.isNotEmpty) ...[
                                        const Text('Món đã đặt:', style: TextStyle(fontWeight: FontWeight.bold)),
                                        ...reservation.orderItems.map((item) {
                                          return Padding(
                                            padding: const EdgeInsets.only(left: 16, top: 4),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Text('${item.itemName} x${item.quantity}'),
                                                Text('${item.subtotal.toStringAsFixed(0)}đ'),
                                              ],
                                            ),
                                          );
                                        }),
                                        const Divider(),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            const Text('Tổng cộng:', style: TextStyle(fontWeight: FontWeight.bold)),
                                            Text(
                                              '${reservation.total.toStringAsFixed(0)}đ',
                                              style: const TextStyle(
                                                fontWeight: FontWeight.bold,
                                                color: Colors.green,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  void _showConfirmDialog(Reservation reservation) {
    final tableController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Xác nhận đặt bàn'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Đặt bàn cho ${reservation.numberOfGuests} khách'),
            const SizedBox(height: 16),
            TextField(
              controller: tableController,
              decoration: const InputDecoration(
                labelText: 'Số bàn',
                hintText: 'VD: B05, A12',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (tableController.text.isNotEmpty) {
                try {
                  await _reservationRepository.confirmReservation(
                    reservation.reservationId,
                    tableController.text,
                  );
                  Navigator.pop(context);
                  _loadData();
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Xác nhận đặt bàn thành công!')),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Lỗi: $e')),
                  );
                }
              }
            },
            child: const Text('Xác nhận'),
          ),
        ],
      ),
    );
  }

  Future<void> _updateStatus(String reservationId, String status) async {
    try {
      await _reservationRepository.updateReservationStatus(reservationId, status);
      _loadData();
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Cập nhật trạng thái thành công!')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi: $e')),
      );
    }
  }
}