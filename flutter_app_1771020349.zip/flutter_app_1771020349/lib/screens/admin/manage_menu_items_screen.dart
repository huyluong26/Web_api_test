import 'package:flutter/material.dart';
import '../../repositories/menu_item_repository.dart';
import '../../models/menu_item.dart';

class ManageMenuItemsScreen extends StatefulWidget {
  const ManageMenuItemsScreen({super.key});

  @override
  State<ManageMenuItemsScreen> createState() => _ManageMenuItemsScreenState();
}

class _ManageMenuItemsScreenState extends State<ManageMenuItemsScreen> {
  final MenuItemRepository _menuItemRepository = MenuItemRepository();
  List<MenuItem> _menuItems = [];
  bool _isLoading = true;
  String _searchQuery = '';
  String? _selectedCategory;

  final List<String> _categories = [
    'Main Course',
    'Appetizer', 
    'Soup',
    'Beverage',
    'Dessert',
    'Test Category'
  ];

  // Helper method để validate category
  String _validateCategory(String? category) {
    if (category == null || category.isEmpty) {
      return _categories.first;
    }
    return _categories.contains(category) ? category : _categories.first;
  }

  @override
  void initState() {
    super.initState();
    _loadMenuItems();
  }

  Future<void> _loadMenuItems() async {
    setState(() => _isLoading = true);
    try {
      _menuItems = await _menuItemRepository.getAllMenuItems();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi tải menu: $e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  List<MenuItem> get _filteredMenuItems {
    List<MenuItem> filtered = _menuItems;
    
    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((item) {
        return item.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
               item.description.toLowerCase().contains(_searchQuery.toLowerCase());
      }).toList();
    }
    
    if (_selectedCategory != null) {
      filtered = filtered.where((item) => item.category == _selectedCategory).toList();
    }
    
    return filtered;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quản lý menu'),
        backgroundColor: Colors.orange,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            onPressed: _showAddMenuItemDialog,
            icon: const Icon(Icons.add),
            tooltip: 'Thêm món ăn',
          ),
        ],
      ),
      body: Column(
        children: [
          // Search and filter
          Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                TextField(
                  decoration: InputDecoration(
                    hintText: 'Tìm kiếm món ăn...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  onChanged: (value) {
                    setState(() => _searchQuery = value);
                  },
                ),
                const SizedBox(height: 12),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      FilterChip(
                        label: const Text('Tất cả'),
                        selected: _selectedCategory == null,
                        onSelected: (selected) {
                          setState(() => _selectedCategory = null);
                        },
                      ),
                      const SizedBox(width: 8),
                      ..._categories.map((category) {
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: FilterChip(
                            label: Text(category),
                            selected: _selectedCategory == category,
                            onSelected: (selected) {
                              setState(() {
                                _selectedCategory = selected ? category : null;
                              });
                            },
                          ),
                        );
                      }),
                    ],
                  ),
                ),
              ],
            ),
          ),
          
          // Menu count
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Text(
                  'Tổng số món: ${_filteredMenuItems.length}',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                IconButton(
                  onPressed: _loadMenuItems,
                  icon: const Icon(Icons.refresh),
                  tooltip: 'Làm mới',
                ),
              ],
            ),
          ),
          
          // Menu items list
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredMenuItems.isEmpty
                    ? const Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.restaurant_menu, size: 64, color: Colors.grey),
                            SizedBox(height: 16),
                            Text('Không có món ăn nào'),
                          ],
                        ),
                      )
                    : ListView.builder(
                        itemCount: _filteredMenuItems.length,
                        itemBuilder: (context, index) {
                          final item = _filteredMenuItems[index];
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundColor: item.isAvailable ? Colors.green : Colors.red,
                                child: Text(
                                  item.name.isNotEmpty ? item.name[0] : '?',
                                  style: const TextStyle(color: Colors.white),
                                ),
                              ),
                              title: Row(
                                children: [
                                  Expanded(child: Text(item.name)),
                                  if (item.isVegetarian)
                                    const Icon(Icons.eco, color: Colors.green, size: 16),
                                  if (item.isSpicy)
                                    const Icon(Icons.local_fire_department, color: Colors.red, size: 16),
                                ],
                              ),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Danh mục: ${item.category}'),
                                  Text('Giá: ${item.price.toStringAsFixed(0)}đ'),
                                  Text('Đánh giá: ${item.rating}/5.0'),
                                  Text('Thời gian: ${item.preparationTime} phút'),
                                  if (!item.isAvailable)
                                    const Text(
                                      'HẾT MÓN',
                                      style: TextStyle(
                                        color: Colors.red,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                ],
                              ),
                              trailing: PopupMenuButton(
                                itemBuilder: (context) => [
                                  const PopupMenuItem(
                                    value: 'edit',
                                    child: Row(
                                      children: [
                                        Icon(Icons.edit, size: 16),
                                        SizedBox(width: 8),
                                        Text('Sửa'),
                                      ],
                                    ),
                                  ),
                                  PopupMenuItem(
                                    value: 'toggle',
                                    child: Row(
                                      children: [
                                        Icon(
                                          item.isAvailable ? Icons.visibility_off : Icons.visibility,
                                          size: 16,
                                        ),
                                        const SizedBox(width: 8),
                                        Text(item.isAvailable ? 'Ẩn món' : 'Hiện món'),
                                      ],
                                    ),
                                  ),
                                  const PopupMenuItem(
                                    value: 'delete',
                                    child: Row(
                                      children: [
                                        Icon(Icons.delete, size: 16, color: Colors.red),
                                        SizedBox(width: 8),
                                        Text('Xóa', style: TextStyle(color: Colors.red)),
                                      ],
                                    ),
                                  ),
                                ],
                                onSelected: (value) {
                                  switch (value) {
                                    case 'edit':
                                      _showEditMenuItemDialog(item);
                                      break;
                                    case 'toggle':
                                      _toggleAvailability(item);
                                      break;
                                    case 'delete':
                                      _showDeleteConfirmDialog(item);
                                      break;
                                  }
                                },
                              ),
                              isThreeLine: true,
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  void _showAddMenuItemDialog() {
    _showMenuItemDialog(null);
  }

  void _showEditMenuItemDialog(MenuItem item) {
    _showMenuItemDialog(item);
  }

  void _showMenuItemDialog(MenuItem? item) {
    final formKey = GlobalKey<FormState>();
    final nameController = TextEditingController(text: item?.name ?? '');
    final descriptionController = TextEditingController(text: item?.description ?? '');
    final priceController = TextEditingController(text: item?.price.toString() ?? '');
    final imageUrlController = TextEditingController(text: item?.imageUrl ?? '');
    final preparationTimeController = TextEditingController(text: item?.preparationTime.toString() ?? '');
    final ratingController = TextEditingController(text: item?.rating.toString() ?? '4.0');
    
    // Xử lý category - sử dụng helper method
    String selectedCategory = _validateCategory(item?.category);
    
    bool isVegetarian = item?.isVegetarian ?? false;
    bool isSpicy = item?.isSpicy ?? false;
    bool isAvailable = item?.isAvailable ?? true;
    List<String> ingredients = List.from(item?.ingredients ?? []);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(item == null ? 'Thêm món ăn mới' : 'Sửa món ăn'),
        content: SizedBox(
          width: double.maxFinite,
          height: 500,
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(labelText: 'Tên món ăn'),
                    validator: (value) => value?.isEmpty ?? true ? 'Vui lòng nhập tên món' : null,
                  ),
                  TextFormField(
                    controller: descriptionController,
                    decoration: const InputDecoration(labelText: 'Mô tả'),
                    maxLines: 2,
                    validator: (value) => value?.isEmpty ?? true ? 'Vui lòng nhập mô tả' : null,
                  ),
                  DropdownButtonFormField<String>(
                    value: selectedCategory,
                    decoration: const InputDecoration(labelText: 'Danh mục'),
                    items: _categories.map((category) {
                      return DropdownMenuItem(value: category, child: Text(category));
                    }).toList(),
                    onChanged: (value) => selectedCategory = value!,
                  ),
                  TextFormField(
                    controller: priceController,
                    decoration: const InputDecoration(labelText: 'Giá (VNĐ)'),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value?.isEmpty ?? true) return 'Vui lòng nhập giá';
                      if (double.tryParse(value!) == null) return 'Giá không hợp lệ';
                      return null;
                    },
                  ),
                  TextFormField(
                    controller: imageUrlController,
                    decoration: const InputDecoration(labelText: 'URL hình ảnh'),
                  ),
                  TextFormField(
                    controller: preparationTimeController,
                    decoration: const InputDecoration(labelText: 'Thời gian chế biến (phút)'),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value?.isEmpty ?? true) return 'Vui lòng nhập thời gian';
                      if (int.tryParse(value!) == null) return 'Thời gian không hợp lệ';
                      return null;
                    },
                  ),
                  TextFormField(
                    controller: ratingController,
                    decoration: const InputDecoration(labelText: 'Đánh giá (0-5)'),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value?.isEmpty ?? true) return 'Vui lòng nhập đánh giá';
                      double? rating = double.tryParse(value!);
                      if (rating == null || rating < 0 || rating > 5) return 'Đánh giá từ 0-5';
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  StatefulBuilder(
                    builder: (context, setState) => Column(
                      children: [
                        CheckboxListTile(
                          title: const Text('Món chay'),
                          value: isVegetarian,
                          onChanged: (value) => setState(() => isVegetarian = value!),
                        ),
                        CheckboxListTile(
                          title: const Text('Món cay'),
                          value: isSpicy,
                          onChanged: (value) => setState(() => isSpicy = value!),
                        ),
                        CheckboxListTile(
                          title: const Text('Còn phục vụ'),
                          value: isAvailable,
                          onChanged: (value) => setState(() => isAvailable = value!),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text('Nguyên liệu:', style: TextStyle(fontWeight: FontWeight.bold)),
                  StatefulBuilder(
                    builder: (context, setState) => Column(
                      children: [
                        ...ingredients.asMap().entries.map((entry) {
                          int index = entry.key;
                          String ingredient = entry.value;
                          return Row(
                            children: [
                              Expanded(
                                child: TextFormField(
                                  initialValue: ingredient,
                                  decoration: InputDecoration(labelText: 'Nguyên liệu ${index + 1}'),
                                  onChanged: (value) => ingredients[index] = value,
                                ),
                              ),
                              IconButton(
                                onPressed: () => setState(() => ingredients.removeAt(index)),
                                icon: const Icon(Icons.remove_circle, color: Colors.red),
                              ),
                            ],
                          );
                        }),
                        ElevatedButton.icon(
                          onPressed: () => setState(() => ingredients.add('')),
                          icon: const Icon(Icons.add),
                          label: const Text('Thêm nguyên liệu'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (formKey.currentState!.validate()) {
                try {
                  final menuItem = MenuItem(
                    itemId: item?.itemId ?? '',
                    name: nameController.text,
                    description: descriptionController.text,
                    category: selectedCategory,
                    price: double.parse(priceController.text),
                    imageUrl: imageUrlController.text,
                    ingredients: ingredients.where((i) => i.isNotEmpty).toList(),
                    isVegetarian: isVegetarian,
                    isSpicy: isSpicy,
                    preparationTime: int.parse(preparationTimeController.text),
                    isAvailable: isAvailable,
                    rating: double.parse(ratingController.text),
                    createdAt: item?.createdAt ?? DateTime.now(),
                  );
                  
                  if (item == null) {
                    await _menuItemRepository.addMenuItem(menuItem);
                  } else {
                    await _menuItemRepository.updateMenuItem(item.itemId, menuItem.toFirestore());
                  }
                  
                  Navigator.pop(context);
                  _loadMenuItems();
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(item == null ? 'Thêm món thành công!' : 'Cập nhật món thành công!')),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Lỗi: $e')),
                  );
                }
              }
            },
            child: Text(item == null ? 'Thêm' : 'Cập nhật'),
          ),
        ],
      ),
    );
  }

  Future<void> _toggleAvailability(MenuItem item) async {
    try {
      await _menuItemRepository.updateMenuItem(item.itemId, {
        'isAvailable': !item.isAvailable,
      });
      _loadMenuItems();
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${item.name} đã ${!item.isAvailable ? 'hiện' : 'ẩn'}'),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi: $e')),
      );
    }
  }

  void _showDeleteConfirmDialog(MenuItem item) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Xác nhận xóa'),
        content: Text('Bạn có chắc chắn muốn xóa món "${item.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                await _menuItemRepository.updateMenuItem(item.itemId, {
                  'isAvailable': false,
                });
                Navigator.pop(context);
                _loadMenuItems();
                
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Xóa món thành công!')),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Lỗi: $e')),
                );
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Xóa', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}