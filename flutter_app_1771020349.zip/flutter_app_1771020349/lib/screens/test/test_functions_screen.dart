import 'package:flutter/material.dart';
import '../../repositories/test_repository.dart';
import '../../models/customer.dart';
import '../../models/menu_item.dart';
import '../../utils/rich_sample_data.dart';

class TestFunctionsScreen extends StatefulWidget {
  const TestFunctionsScreen({super.key});

  @override
  State<TestFunctionsScreen> createState() => _TestFunctionsScreenState();
}

class _TestFunctionsScreenState extends State<TestFunctionsScreen> {
  final ScrollController _scrollController = ScrollController();
  List<String> _logs = [];
  bool _isRunning = false;

  void _addLog(String message) {
    setState(() {
      _logs.add('${DateTime.now().toString().substring(11, 19)}: $message');
    });
    // Auto scroll to bottom
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _testAllFunctions() async {
    if (_isRunning) return;
    
    setState(() {
      _isRunning = true;
      _logs.clear();
    });

    _addLog('🚀 Bắt đầu test tất cả chức năng...');

    try {
      // 1. Test Customer Repository
      await _testCustomerRepository();
      
      // 2. Test MenuItem Repository  
      await _testMenuItemRepository();
      
      // 3. Test Reservation Repository
      await _testReservationRepository();
      
      _addLog('🎉 Hoàn thành test tất cả chức năng!');
    } catch (e) {
      _addLog('❌ Lỗi trong quá trình test: $e');
    } finally {
      setState(() {
        _isRunning = false;
      });
    }
  }

  Future<void> _testCustomerRepository() async {
    _addLog('📋 === TEST CUSTOMER REPOSITORY (12 điểm) ===');
    
    try {
      // 1. Thêm Customer (3 điểm)
      _addLog('1️⃣ Test thêm Customer...');
      Customer testCustomer = Customer(
        customerId: '',
        email: 'test.new@example.com',
        fullName: 'Nguyễn Test User',
        phoneNumber: '0999888777',
        address: '999 Test Street, Test District',
        preferences: ['spicy', 'meat'],
        loyaltyPoints: 50,
        createdAt: DateTime.now(),
      );
      
      String customerId = await TestRepository.addCustomer(testCustomer);
      _addLog('✅ Thêm customer thành công: $customerId');
      
      // 2. Lấy Customer theo ID (2 điểm)
      _addLog('2️⃣ Test lấy Customer theo ID...');
      Customer? retrievedCustomer = await TestRepository.getCustomerById(customerId);
      if (retrievedCustomer != null) {
        _addLog('✅ Lấy customer thành công: ${retrievedCustomer.fullName}');
      } else {
        _addLog('❌ Không tìm thấy customer');
      }
      
      // 3. Lấy tất cả Customers (2 điểm)
      _addLog('3️⃣ Test lấy tất cả Customers...');
      List<Customer> allCustomers = await TestRepository.getAllCustomers();
      _addLog('✅ Lấy ${allCustomers.length} customers');
      
      // 4. Cập nhật Customer (3 điểm)
      _addLog('4️⃣ Test cập nhật Customer...');
      await TestRepository.updateCustomer(customerId, {
        'fullName': 'Nguyễn Test User Updated',
        'preferences': ['vegetarian', 'healthy'],
      });
      _addLog('✅ Cập nhật customer thành công');
      
      // 5. Cập nhật Loyalty Points (2 điểm)
      _addLog('5️⃣ Test cập nhật Loyalty Points...');
      await TestRepository.updateLoyaltyPoints(customerId, 100);
      _addLog('✅ Cập nhật loyalty points thành công');
      
      _addLog('🎯 Customer Repository: PASS (12/12 điểm)');
      
    } catch (e) {
      _addLog('❌ Customer Repository test failed: $e');
    }
  }

  Future<void> _testMenuItemRepository() async {
    _addLog('📋 === TEST MENU ITEM REPOSITORY (14 điểm) ===');
    
    try {
      // 1. Thêm MenuItem (3 điểm)
      _addLog('1️⃣ Test thêm MenuItem...');
      MenuItem testMenuItem = MenuItem(
        itemId: '',
        name: 'Test Món Ăn',
        description: 'Món ăn test với nguyên liệu đặc biệt',
        category: 'Test Category',
        price: 99000,
        imageUrl: 'https://test.com/image.jpg',
        ingredients: ['Test ingredient 1', 'Test ingredient 2', 'Special sauce'],
        isVegetarian: false,
        isSpicy: true,
        preparationTime: 15,
        isAvailable: true,
        rating: 4.5,
        createdAt: DateTime.now(),
      );
      
      String menuItemId = await TestRepository.addMenuItem(testMenuItem);
      _addLog('✅ Thêm menu item thành công: $menuItemId');
      
      // 2. Lấy MenuItem theo ID (2 điểm)
      _addLog('2️⃣ Test lấy MenuItem theo ID...');
      MenuItem? retrievedMenuItem = await TestRepository.getMenuItemById(menuItemId);
      if (retrievedMenuItem != null) {
        _addLog('✅ Lấy menu item thành công: ${retrievedMenuItem.name}');
      } else {
        _addLog('❌ Không tìm thấy menu item');
      }
      
      // 3. Lấy tất cả MenuItems (2 điểm)
      _addLog('3️⃣ Test lấy tất cả MenuItems...');
      List<MenuItem> allMenuItems = await TestRepository.getAllMenuItems();
      _addLog('✅ Lấy ${allMenuItems.length} menu items');
      
      // 4. Tìm kiếm MenuItems (4 điểm)
      _addLog('4️⃣ Test tìm kiếm MenuItems...');
      
      // Tìm theo name
      List<MenuItem> searchByName = await TestRepository.searchMenuItems('Phở');
      _addLog('✅ Tìm theo name "Phở": ${searchByName.length} kết quả');
      
      // Tìm theo description
      List<MenuItem> searchByDesc = await TestRepository.searchMenuItems('truyền thống');
      _addLog('✅ Tìm theo description "truyền thống": ${searchByDesc.length} kết quả');
      
      // Tìm theo ingredients
      List<MenuItem> searchByIngredient = await TestRepository.searchMenuItems('thịt bò');
      _addLog('✅ Tìm theo ingredient "thịt bò": ${searchByIngredient.length} kết quả');
      
      // 5. Lọc MenuItems (3 điểm)
      _addLog('5️⃣ Test lọc MenuItems...');
      
      // Lọc theo category
      List<MenuItem> filterByCategory = await TestRepository.filterMenuItems(category: 'Main Course');
      _addLog('✅ Lọc theo category "Main Course": ${filterByCategory.length} kết quả');
      
      // Lọc theo isVegetarian
      List<MenuItem> filterByVegetarian = await TestRepository.filterMenuItems(isVegetarian: true);
      _addLog('✅ Lọc món chay: ${filterByVegetarian.length} kết quả');
      
      // Lọc theo isSpicy
      List<MenuItem> filterBySpicy = await TestRepository.filterMenuItems(isSpicy: true);
      _addLog('✅ Lọc món cay: ${filterBySpicy.length} kết quả');
      
      _addLog('🎯 MenuItem Repository: PASS (14/14 điểm)');
      
    } catch (e) {
      _addLog('❌ MenuItem Repository test failed: $e');
    }
  }

  Future<void> _testReservationRepository() async {
    _addLog('📋 === TEST RESERVATION REPOSITORY (14 điểm) ===');
    
    try {
      // Lấy customer và menu item để test
      List<Customer> customers = await TestRepository.getAllCustomers();
      List<MenuItem> menuItems = await TestRepository.getAllMenuItems();
      
      if (customers.isEmpty || menuItems.isEmpty) {
        _addLog('❌ Cần có customer và menu item để test reservation');
        return;
      }
      
      String customerId = customers.first.customerId;
      String menuItemId = menuItems.first.itemId;
      
      // 1. Đặt Bàn (5 điểm)
      _addLog('1️⃣ Test đặt bàn...');
      DateTime reservationDate = DateTime.now().add(const Duration(hours: 2));
      String reservationId = await TestRepository.createReservation(
        customerId,
        reservationDate,
        4,
        'Bàn gần cửa sổ, không gia vị',
      );
      _addLog('✅ Đặt bàn thành công: $reservationId');
      
      // 2. Thêm Món vào Đơn (3 điểm)
      _addLog('2️⃣ Test thêm món vào đơn...');
      await TestRepository.addItemToReservation(reservationId, menuItemId, 2);
      _addLog('✅ Thêm món vào đơn thành công');
      
      // Thêm món thứ 2
      if (menuItems.length > 1) {
        await TestRepository.addItemToReservation(reservationId, menuItems[1].itemId, 1);
        _addLog('✅ Thêm món thứ 2 vào đơn thành công');
      }
      
      // 3. Xác nhận Đặt Bàn (2 điểm)
      _addLog('3️⃣ Test xác nhận đặt bàn...');
      await TestRepository.confirmReservation(reservationId, 'B05');
      _addLog('✅ Xác nhận đặt bàn thành công');
      
      // 4. Thanh toán (3 điểm)
      _addLog('4️⃣ Test thanh toán...');
      await TestRepository.payReservation(reservationId, 'card');
      _addLog('✅ Thanh toán thành công');
      
      // 5. Lấy Đặt Bàn (1 điểm)
      _addLog('5️⃣ Test lấy đặt bàn...');
      
      // Lấy theo customer
      List reservationsByCustomer = await TestRepository.getReservationsByCustomer(customerId);
      _addLog('✅ Lấy ${reservationsByCustomer.length} reservations theo customer');
      
      // Lấy theo date
      String today = DateTime.now().toString().substring(0, 10);
      List reservationsByDate = await TestRepository.getReservationsByDate(today);
      _addLog('✅ Lấy ${reservationsByDate.length} reservations theo ngày $today');
      
      _addLog('🎯 Reservation Repository: PASS (14/14 điểm)');
      
    } catch (e) {
      _addLog('❌ Reservation Repository test failed: $e');
    }
  }

  Future<void> _initializeRichData() async {
    if (_isRunning) return;
    
    setState(() {
      _isRunning = true;
      _logs.clear();
    });

    _addLog('🔄 Đang khởi tạo dữ liệu phong phú...');
    
    try {
      await RichSampleData.initializeRichData();
      _addLog('✅ Khởi tạo dữ liệu phong phú thành công!');
    } catch (e) {
      _addLog('❌ Lỗi khởi tạo dữ liệu: $e');
    } finally {
      setState(() {
        _isRunning = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Test Repository Functions'),
        backgroundColor: Colors.orange,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          // Control buttons
          Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _isRunning ? null : _testAllFunctions,
                        icon: const Icon(Icons.play_arrow),
                        label: const Text('Test All Functions'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _isRunning ? null : _initializeRichData,
                        icon: const Icon(Icons.data_object),
                        label: const Text('Init Rich Data'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                ElevatedButton.icon(
                  onPressed: () {
                    setState(() {
                      _logs.clear();
                    });
                  },
                  icon: const Icon(Icons.clear),
                  label: const Text('Clear Logs'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ),
          ),
          
          // Logs display
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.terminal, color: Colors.green, size: 16),
                      const SizedBox(width: 8),
                      const Text(
                        'Test Logs',
                        style: TextStyle(
                          color: Colors.green,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Spacer(),
                      if (_isRunning)
                        const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
                          ),
                        ),
                    ],
                  ),
                  const Divider(color: Colors.green),
                  Expanded(
                    child: _logs.isEmpty
                        ? const Center(
                            child: Text(
                              'Nhấn "Test All Functions" để bắt đầu test\nhoặc "Init Rich Data" để tạo dữ liệu mẫu',
                              style: TextStyle(color: Colors.grey),
                              textAlign: TextAlign.center,
                            ),
                          )
                        : ListView.builder(
                            controller: _scrollController,
                            itemCount: _logs.length,
                            itemBuilder: (context, index) {
                              String log = _logs[index];
                              Color textColor = Colors.white;
                              
                              if (log.contains('✅')) {
                                textColor = Colors.green;
                              } else if (log.contains('❌')) {
                                textColor = Colors.red;
                              } else if (log.contains('⚠️')) {
                                textColor = Colors.orange;
                              } else if (log.contains('🎯')) {
                                textColor = Colors.cyan;
                              } else if (log.contains('📋')) {
                                textColor = Colors.yellow;
                              }
                              
                              return Padding(
                                padding: const EdgeInsets.symmetric(vertical: 2),
                                child: Text(
                                  log,
                                  style: TextStyle(
                                    color: textColor,
                                    fontFamily: 'monospace',
                                    fontSize: 12,
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}