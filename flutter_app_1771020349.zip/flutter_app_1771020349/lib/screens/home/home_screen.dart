import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/menu_provider.dart';
import '../../providers/reservation_provider.dart';
import '../menu/menu_screen.dart';
import '../reservation/create_reservation_screen.dart';
import '../reservation/my_reservations_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  
  final List<Widget> _screens = [
    const MenuScreen(),
    const CreateReservationScreen(),
    const MyReservationsScreen(),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadData();
    });
  }

  void _loadData() {
    final menuProvider = Provider.of<MenuProvider>(context, listen: false);
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final reservationProvider = Provider.of<ReservationProvider>(context, listen: false);
    
    menuProvider.loadAvailableMenuItems();
    
    if (authProvider.currentCustomer != null) {
      reservationProvider.loadCustomerReservations(authProvider.currentCustomer!.customerId);
    }
  }

  void _logout() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Đăng xuất'),
        content: const Text('Bạn có chắc chắn muốn đăng xuất?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Hủy'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Provider.of<AuthProvider>(context, listen: false).logout();
            },
            child: const Text('Đăng xuất'),
          ),
        ],
      ),
    );
  }
  @
override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Restaurant App - 2151061234'),
        actions: [
          Consumer<AuthProvider>(
            builder: (context, authProvider, child) {
              return Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (authProvider.currentCustomer != null) ...[
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          authProvider.currentCustomer!.fullName,
                          style: const TextStyle(fontSize: 12),
                        ),
                        Text(
                          'Điểm: ${authProvider.currentCustomer!.loyaltyPoints}',
                          style: const TextStyle(fontSize: 10),
                        ),
                      ],
                    ),
                    const SizedBox(width: 8),
                  ],
                  IconButton(
                    onPressed: _logout,
                    icon: const Icon(Icons.logout),
                  ),
                ],
              );
            },
          ),
        ],
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.orange,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.restaurant_menu),
            label: 'Menu',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_circle),
            label: 'Đặt bàn',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.list_alt),
            label: 'Đặt bàn của tôi',
          ),
        ],
      ),
    );
  }
}