import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/customer.dart';

class AdminProvider extends ChangeNotifier {
  bool _isAdminLoggedIn = false;
  String? _adminId;
  String? _adminName;
  
  // Hardcoded admin credentials for demo
  static const String _adminUsername = 'admin';
  static const String _adminPassword = 'admin123';
  
  bool get isAdminLoggedIn => _isAdminLoggedIn;
  String? get adminId => _adminId;
  String? get adminName => _adminName;
  
  Future<bool> adminLogin(String username, String password) async {
    try {
      if (username == _adminUsername && password == _adminPassword) {
        _isAdminLoggedIn = true;
        _adminId = 'admin_001';
        _adminName = 'Administrator';
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print('Admin login error: $e');
      return false;
    }
  }
  
  void adminLogout() {
    _isAdminLoggedIn = false;
    _adminId = null;
    _adminName = null;
    notifyListeners();
  }
  
  // Check if current user has admin privileges
  Future<bool> checkAdminPrivileges(String userId) async {
    try {
      final doc = await FirebaseFirestore.instance
          .collection('customers')
          .doc(userId)
          .get();
      
      if (doc.exists) {
        final customer = Customer.fromFirestore(doc);
        return customer.role == 'admin';
      }
      return false;
    } catch (e) {
      print('Error checking admin privileges: $e');
      return false;
    }
  }
}