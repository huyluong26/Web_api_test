import 'package:flutter/foundation.dart';
import '../models/menu_item.dart';
import '../repositories/menu_item_repository.dart';
import '../repositories/backup_repository.dart';

class MenuProvider with ChangeNotifier {
  List<MenuItem> _menuItems = [];
  List<MenuItem> _filteredItems = [];
  bool _isLoading = false;
  String? _error;
  String _searchQuery = '';
  String? _selectedCategory;
  bool _showVegetarianOnly = false;
  bool _showSpicyOnly = false;

  List<MenuItem> get menuItems => _filteredItems;
  List<MenuItem> get allMenuItems => _menuItems;
  bool get isLoading => _isLoading;
  String? get error => _error;
  String get searchQuery => _searchQuery;
  String? get selectedCategory => _selectedCategory;
  bool get showVegetarianOnly => _showVegetarianOnly;
  bool get showSpicyOnly => _showSpicyOnly;

  final MenuItemRepository _menuItemRepository = MenuItemRepository();

  // Danh sách categories
  List<String> get categories {
    Set<String> categorySet = _menuItems.map((item) => item.category).toSet();
    return categorySet.toList()..sort();
  }

  // Load tất cả menu items
  Future<void> loadMenuItems() async {
    _setLoading(true);
    _error = null;

    try {
      _menuItems = await _menuItemRepository.getAllMenuItems();
      _applyFilters();
    } catch (e) {
      _error = 'Lỗi khi tải menu: ${e.toString()}';
      print('MenuProvider Error: $e'); // Debug log
    } finally {
      _setLoading(false);
    }
  }

  // Tìm kiếm
  Future<void> searchMenuItems(String query) async {
    _searchQuery = query;
    
    if (query.isEmpty) {
      _applyFilters();
      return;
    }

    _setLoading(true);
    _error = null;

    try {
      List<MenuItem> searchResults = await _menuItemRepository.searchMenuItems(query);
      _filteredItems = searchResults;
      _applyCurrentFilters();
    } catch (e) {
      _error = e.toString();
    } finally {
      _setLoading(false);
    }
  }

  // Lọc theo category
  void filterByCategory(String? category) {
    _selectedCategory = category;
    _applyFilters();
  }

  // Lọc món chay
  void toggleVegetarianFilter(bool showVegetarianOnly) {
    _showVegetarianOnly = showVegetarianOnly;
    _applyFilters();
  }

  // Lọc món cay
  void toggleSpicyFilter(bool showSpicyOnly) {
    _showSpicyOnly = showSpicyOnly;
    _applyFilters();
  }

  // Clear tất cả filters
  void clearFilters() {
    _searchQuery = '';
    _selectedCategory = null;
    _showVegetarianOnly = false;
    _showSpicyOnly = false;
    _applyFilters();
  }

  // Áp dụng filters
  void _applyFilters() {
    List<MenuItem> filtered = List.from(_menuItems);

    // Filter theo search query
    if (_searchQuery.isNotEmpty) {
      String searchLower = _searchQuery.toLowerCase();
      filtered = filtered.where((item) {
        return item.name.toLowerCase().contains(searchLower) ||
               item.description.toLowerCase().contains(searchLower) ||
               item.ingredients.any((ingredient) => 
                   ingredient.toLowerCase().contains(searchLower));
      }).toList();
    }

    _applyCurrentFilters(filtered);
  }

  // Áp dụng filters hiện tại lên danh sách cho trước
  void _applyCurrentFilters([List<MenuItem>? items]) {
    List<MenuItem> filtered = items ?? List.from(_menuItems);

    // Filter theo category
    if (_selectedCategory != null) {
      filtered = filtered.where((item) => item.category == _selectedCategory).toList();
    }

    // Filter món chay
    if (_showVegetarianOnly) {
      filtered = filtered.where((item) => item.isVegetarian).toList();
    }

    // Filter món cay
    if (_showSpicyOnly) {
      filtered = filtered.where((item) => item.isSpicy).toList();
    }

    _filteredItems = filtered;
    notifyListeners();
  }

  // Lấy menu item theo ID
  MenuItem? getMenuItemById(String itemId) {
    try {
      return _menuItems.firstWhere((item) => item.itemId == itemId);
    } catch (e) {
      return null;
    }
  }

  // Load available menu items only
  Future<void> loadAvailableMenuItems() async {
    _setLoading(true);
    _error = null;

    try {
      try {
        _menuItems = await _menuItemRepository.getAvailableMenuItems();
      } catch (e) {
        print('MenuItemRepository failed, using BackupRepository: $e');
        _menuItems = await BackupRepository.getAvailableMenuItems();
      }
      _applyFilters();
    } catch (e) {
      _error = 'Lỗi khi tải menu: ${e.toString()}';
      print('MenuProvider Error: $e'); // Debug log
    } finally {
      _setLoading(false);
    }
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  // Refresh menu items
  Future<void> refresh() async {
    await loadMenuItems();
  }
}