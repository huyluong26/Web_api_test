import 'package:flutter/foundation.dart';
import '../models/customer.dart';
import '../repositories/customer_repository.dart';
import '../repositories/backup_repository.dart';

class AuthProvider with ChangeNotifier {
  Customer? _currentCustomer;
  bool _isLoading = false;
  String? _error;

  Customer? get currentCustomer => _currentCustomer;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isLoggedIn => _currentCustomer != null;

  final CustomerRepository _customerRepository = CustomerRepository();

  // Đăng nhập
  Future<bool> login(String email) async {
    _setLoading(true);
    _error = null;
    
    try {
      Customer? customer;
      try {
        customer = await _customerRepository.getCustomerByEmail(email);
      } catch (e) {
        print('CustomerRepository failed, using BackupRepository: $e');
        customer = await BackupRepository.getCustomerByEmail(email);
      }
      
      if (customer != null) {
        _currentCustomer = customer;
        notifyListeners();
        return true;
      } else {
        _error = 'Không tìm thấy tài khoản với email này';
        return false;
      }
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Đăng ký
  Future<bool> register({
    required String email,
    required String fullName,
    required String phoneNumber,
    required String address,
    required List<String> preferences,
  }) async {
    _setLoading(true);
    _error = null;
    
    try {
      // Kiểm tra email đã tồn tại chưa
      Customer? existingCustomer;
      try {
        existingCustomer = await _customerRepository.getCustomerByEmail(email);
      } catch (e) {
        print('CustomerRepository failed, using BackupRepository: $e');
        existingCustomer = await BackupRepository.getCustomerByEmail(email);
      }
      
      if (existingCustomer != null) {
        _error = 'Email đã được sử dụng';
        return false;
      }

      // Tạo customer mới
      Customer newCustomer = Customer(
        customerId: '',
        email: email,
        fullName: fullName,
        phoneNumber: phoneNumber,
        address: address,
        preferences: preferences,
        createdAt: DateTime.now(),
      );

      String customerId;
      try {
        customerId = await _customerRepository.addCustomer(newCustomer);
      } catch (e) {
        print('CustomerRepository failed, using BackupRepository: $e');
        customerId = await BackupRepository.addCustomer(newCustomer);
      }
      
      _currentCustomer = newCustomer.copyWith();
      
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Đăng xuất
  void logout() {
    _currentCustomer = null;
    _error = null;
    notifyListeners();
  }

  // Cập nhật thông tin customer
  Future<bool> updateCustomerInfo({
    String? fullName,
    String? phoneNumber,
    String? address,
    List<String>? preferences,
  }) async {
    if (_currentCustomer == null) return false;

    _setLoading(true);
    _error = null;

    try {
      Map<String, dynamic> updates = {};
      if (fullName != null) updates['fullName'] = fullName;
      if (phoneNumber != null) updates['phoneNumber'] = phoneNumber;
      if (address != null) updates['address'] = address;
      if (preferences != null) updates['preferences'] = preferences;

      await _customerRepository.updateCustomer(_currentCustomer!.customerId, updates);
      
      // Cập nhật local state
      _currentCustomer = _currentCustomer!.copyWith(
        fullName: fullName,
        phoneNumber: phoneNumber,
        address: address,
        preferences: preferences,
      );
      
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Đăng nhập admin
  Future<bool> loginAsAdmin(String email) async {
    _setLoading(true);
    _error = null;
    
    try {
      // Tạo admin user tạm thời
      Customer adminUser = Customer(
        customerId: 'admin_001',
        email: email,
        fullName: 'Administrator',
        phoneNumber: '0000000000',
        address: 'Restaurant Admin',
        preferences: [],
        loyaltyPoints: 0,
        createdAt: DateTime.now(),
        isActive: true,
        role: 'admin',
      );
      
      _currentCustomer = adminUser;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  // Refresh customer data
  Future<void> refreshCustomerData() async {
    if (_currentCustomer == null) return;

    try {
      Customer? updatedCustomer = await _customerRepository.getCustomerById(_currentCustomer!.customerId);
      if (updatedCustomer != null) {
        _currentCustomer = updatedCustomer;
        notifyListeners();
      }
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}