import 'package:flutter/foundation.dart';
import '../models/reservation.dart';
import '../models/order_item.dart';
import '../repositories/reservation_repository.dart';
import '../repositories/backup_repository.dart';

class ReservationProvider with ChangeNotifier {
  List<Reservation> _reservations = [];
  Reservation? _currentReservation;
  bool _isLoading = false;
  String? _error;

  List<Reservation> get reservations => _reservations;
  Reservation? get currentReservation => _currentReservation;
  bool get isLoading => _isLoading;
  String? get error => _error;

  final ReservationRepository _reservationRepository = ReservationRepository();

  // Load reservations của customer
  Future<void> loadCustomerReservations(String customerId) async {
    _setLoading(true);
    _error = null;

    try {
      // Thử sử dụng simple method trước
      try {
        _reservations = await _reservationRepository.getReservationsByCustomerSimple(customerId);
      } catch (e) {
        print('SimpleRepository failed, using BackupRepository: $e');
        // Fallback to backup repository
        _reservations = await BackupRepository.getReservationsByCustomer(customerId);
      }
    } catch (e) {
      _error = 'Lỗi khi tải đặt bàn: ${e.toString()}';
      print('ReservationProvider Error: $e'); // Debug log
    } finally {
      _setLoading(false);
    }
  }

  // Tạo reservation mới
  Future<String?> createReservation({
    required String customerId,
    required DateTime reservationDate,
    required int numberOfGuests,
    String? specialRequests,
  }) async {
    _setLoading(true);
    _error = null;

    try {
      String reservationId = await _reservationRepository.createReservation(
        customerId,
        reservationDate,
        numberOfGuests,
        specialRequests,
      );
      
      // Load lại danh sách reservations
      await loadCustomerReservations(customerId);
      
      return reservationId;
    } catch (e) {
      _error = 'Lỗi khi tạo đặt bàn: ${e.toString()}';
      print('CreateReservation Error: $e'); // Debug log
      return null;
    } finally {
      _setLoading(false);
    }
  }

  // Set current reservation để edit
  void setCurrentReservation(String reservationId) {
    _currentReservation = _reservations.firstWhere(
      (reservation) => reservation.reservationId == reservationId,
    );
    notifyListeners();
  }

  // Thêm món vào reservation
  Future<bool> addItemToReservation(String reservationId, String itemId, int quantity) async {
    _setLoading(true);
    _error = null;

    try {
      await _reservationRepository.addItemToReservation(reservationId, itemId, quantity);
      
      // Cập nhật current reservation nếu đang edit
      if (_currentReservation?.reservationId == reservationId) {
        Reservation? updated = await _reservationRepository.getReservationById(reservationId);
        if (updated != null) {
          _currentReservation = updated;
        }
      }
      
      // Refresh danh sách reservations
      if (_reservations.isNotEmpty) {
        String customerId = _reservations.first.customerId;
        await loadCustomerReservations(customerId);
      }
      
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Xóa món khỏi reservation
  Future<bool> removeItemFromReservation(String reservationId, String itemId) async {
    _setLoading(true);
    _error = null;

    try {
      await _reservationRepository.removeItemFromReservation(reservationId, itemId);
      
      // Cập nhật current reservation
      if (_currentReservation?.reservationId == reservationId) {
        Reservation? updated = await _reservationRepository.getReservationById(reservationId);
        if (updated != null) {
          _currentReservation = updated;
        }
      }
      
      // Refresh danh sách reservations
      if (_reservations.isNotEmpty) {
        String customerId = _reservations.first.customerId;
        await loadCustomerReservations(customerId);
      }
      
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Xác nhận reservation
  Future<bool> confirmReservation(String reservationId, String tableNumber) async {
    _setLoading(true);
    _error = null;

    try {
      await _reservationRepository.confirmReservation(reservationId, tableNumber);
      
      // Refresh danh sách
      if (_reservations.isNotEmpty) {
        String customerId = _reservations.first.customerId;
        await loadCustomerReservations(customerId);
      }
      
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Thanh toán
  Future<bool> payReservation(String reservationId, String paymentMethod) async {
    _setLoading(true);
    _error = null;

    try {
      await _reservationRepository.payReservation(reservationId, paymentMethod);
      
      // Refresh danh sách
      if (_reservations.isNotEmpty) {
        String customerId = _reservations.first.customerId;
        await loadCustomerReservations(customerId);
      }
      
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Cập nhật status
  Future<bool> updateReservationStatus(String reservationId, String status) async {
    _setLoading(true);
    _error = null;

    try {
      await _reservationRepository.updateReservationStatus(reservationId, status);
      
      // Refresh danh sách
      if (_reservations.isNotEmpty) {
        String customerId = _reservations.first.customerId;
        await loadCustomerReservations(customerId);
      }
      
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Lấy reservation theo ID
  Future<Reservation?> getReservationById(String reservationId) async {
    try {
      return await _reservationRepository.getReservationById(reservationId);
    } catch (e) {
      _error = e.toString();
      return null;
    }
  }

  // Clear current reservation
  void clearCurrentReservation() {
    _currentReservation = null;
    notifyListeners();
  }

  // Lọc reservations theo status
  List<Reservation> getReservationsByStatus(String status) {
    return _reservations.where((reservation) => reservation.status == status).toList();
  }

  // Lấy pending reservations
  List<Reservation> get pendingReservations => getReservationsByStatus('pending');
  
  // Lấy confirmed reservations
  List<Reservation> get confirmedReservations => getReservationsByStatus('confirmed');
  
  // Lấy completed reservations
  List<Reservation> get completedReservations => getReservationsByStatus('completed');

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  // Refresh reservations
  Future<void> refresh(String customerId) async {
    await loadCustomerReservations(customerId);
  }
}