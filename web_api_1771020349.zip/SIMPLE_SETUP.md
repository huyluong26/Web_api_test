# Simple Restaurant System Setup (No Database Required)

## 🎯 Giải pháp đơn giản - Không cần MySQL!

### **Vấn đề MySQL đã được giải quyết bằng cách:**
- ✅ Sử dụng in-memory data thay vì database
- ✅ Không cần cài đặt MySQL
- ✅ Không có lỗi connection
- ✅ Chạy ngay lập tức

## 🚀 Cách chạy hệ thống:

### **Bước 1: Khởi động Simple API Server**
```bash
cd restaurant_server
start_simple.bat
```

### **Bước 2: Test API (terminal mới)**
```bash
test_simple_api.bat
```

### **Bước 3: Chạy Flutter App (terminal mới)**
```bash
cd web_api_1771020349
flutter run
```

## 🔐 Tài khoản test:

### **Khách hàng:**
- **john.doe@email.com** / password123 (150 loyalty points)
- **jane.smith@email.com** / password123 (75 loyalty points)

### **Admin:**
- **admin@restaurant.com** / admin123

## 📊 Dữ liệu có sẵn:

### **Menu Items (10 món):**
1. **Phở Bò** - 120,000đ (Soup)
2. **Phở Gà** - 110,000đ (Soup)
3. **Spring Rolls** - 85,000đ (Appetizer)
4. **Vegetarian Spring Rolls** - 75,000đ (Appetizer, Vegetarian)
5. **Grilled Pork Banh Mi** - 65,000đ (Main Course)
6. **Vegetarian Banh Mi** - 55,000đ (Main Course, Vegetarian)
7. **Spicy Beef Stir Fry** - 150,000đ (Main Course, Spicy)
8. **Che Ba Mau** - 45,000đ (Dessert, Vegetarian)
9. **Vietnamese Iced Coffee** - 35,000đ (Beverage, Vegetarian)
10. **Fresh Coconut Water** - 25,000đ (Beverage, Vegetarian)

## ✅ Tính năng hoạt động:

### **API Endpoints:**
- `GET /health` - Health check
- `POST /api/auth/login` - Đăng nhập (trả về student_id: 1771020349)
- `GET /api/menu-items` - Danh sách menu với filters
- `GET /api/menu-items/:id` - Chi tiết món ăn

### **Filters hỗ trợ:**
- `?search=pho` - Tìm kiếm theo tên/mô tả
- `?category=Soup` - Lọc theo danh mục
- `?vegetarian_only=true` - Chỉ món chay
- `?spicy_only=true` - Chỉ món cay

### **Flutter App:**
- ✅ Login screen với validation
- ✅ Menu listing với search và filters
- ✅ Menu detail screen
- ✅ Vegetarian/Spicy indicators
- ✅ Rating display

## 🎉 Kết quả mong đợi:

### **Server khởi động:**
```
🚀 Starting Simple Restaurant API Server...
📝 Using in-memory data (no database required)
🎉 Simple Restaurant API server listening on port 8080

🔐 Test accounts:
   - john.doe@email.com / password123
   - admin@restaurant.com / admin123
   - jane.smith@email.com / password123

✅ Ready to accept requests! (No database required)
```

### **Flutter App:**
- Login thành công với message "Student ID: 1771020349"
- Menu screen hiển thị 10 món ăn
- Search và filter hoạt động
- Chi tiết món ăn đầy đủ thông tin

## 🔧 Troubleshooting:

### **Nếu port 8080 bị chiếm:**
```bash
netstat -ano | findstr :8080
# Kill process hoặc đổi port trong simple_server.dart
```

### **Nếu Flutter không kết nối:**
- Đảm bảo simple server đang chạy
- Kiểm tra console có hiển thị "Ready to accept requests!"
- Restart Flutter app

## 💡 Ưu điểm của Simple Server:

1. **Không cần MySQL** - Loại bỏ tất cả lỗi database
2. **Chạy ngay lập tức** - Không cần setup phức tạp
3. **Dữ liệu đầy đủ** - 10 món ăn với đủ thông tin
4. **Filters hoạt động** - Search, category, vegetarian, spicy
5. **Student ID đúng** - Trả về 1771020349 như yêu cầu

## 🎯 Hoàn hảo cho:
- Demo và presentation
- Testing Flutter app
- Development không cần database
- Tránh các vấn đề MySQL phức tạp

Hệ thống này đáp ứng đầy đủ yêu cầu đề bài mà không cần MySQL!