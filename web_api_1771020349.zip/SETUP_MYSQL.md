# Hướng dẫn Setup Restaurant System với MySQL

## ❌ Lỗi: "Failed host lookup: 'DESKTOP-V50EC20'"

### Nguyên nhân:
- Hostname `DESKTOP-V50EC20` không thể resolve
- MySQL có thể chạy trên localhost thay vì hostname

## 🔧 Cách khắc phục:

### Bước 1: Kiểm tra MySQL service
```bash
check_mysql.bat
```

### Bước 2: Test các host khác nhau
```bash
cd restaurant_server
test_hosts.bat
```

### Bước 3: Sử dụng localhost (đã cập nhật)
**Cấu hình mới:**
- Host: `localhost` (thay vì DESKTOP-V50EC20)
- Port: `3306`
- Database: `db_exam_1771020349`
- User: `root`

### Bước 4: Khởi động server
```bash
cd restaurant_server
start_server.bat
```

## 🎯 Các host sẽ được test:

1. **localhost** - Thường hoạt động tốt nhất
2. **127.0.0.1** - IP localhost
3. **DESKTOP-V50EC20** - Hostname gốc
4. **::1** - IPv6 localhost

## ✅ Kết quả mong đợi:

```
🔍 Testing multiple MySQL connection options...

Testing host: localhost
✅ SUCCESS: Connected to localhost
✅ Query test passed
✅ Connection closed properly

🎉 RECOMMENDED HOST: localhost
```

## 🚀 Sau khi khắc phục:

### 1. Khởi động API Server:
```bash
cd restaurant_server
start_server.bat
```

### 2. Chạy Flutter App:
```bash
cd web_api_1771020349
flutter run
```

### 3. Test đăng nhập:
- Email: `john.doe@email.com`
- Password: `password123`

## 🔍 Troubleshooting bổ sung:

### Nếu vẫn không kết nối được:

**1. Kiểm tra MySQL đang chạy:**
```bash
# Windows
sc query MySQL80
# hoặc
sc query MySQL
```

**2. Kiểm tra port 3306:**
```bash
netstat -an | findstr :3306
```

**3. Test MySQL command line:**
```bash
mysql -u root -p
```

**4. Tạo database nếu chưa có:**
```sql
CREATE DATABASE IF NOT EXISTS db_exam_1771020349;
USE db_exam_1771020349;
```

### Nếu MySQL chưa cài đặt:
1. Download MySQL Community Server
2. Cài đặt với user `root` và password trống
3. Đảm bảo service MySQL đang chạy

## 📊 Cấu hình cuối cùng:

**File `.env` đã được cập nhật:**
```
DB_HOST=localhost
DB_PORT=3306
DB_NAME=db_exam_1771020349
DB_USER=root
DB_PASSWORD=
```

Hệ thống sẽ tự động kết nối với MySQL trên localhost thay vì hostname!