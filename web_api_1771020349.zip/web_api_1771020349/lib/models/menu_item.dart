class MenuItem {
  final int id;
  final String name;
  final String? description;
  final String category;
  final double price;
  final String? imageUrl;
  final int? preparationTime;
  final bool isVegetarian;
  final bool isSpicy;
  final bool isAvailable;
  final double rating;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  MenuItem({
    required this.id,
    required this.name,
    this.description,
    required this.category,
    required this.price,
    this.imageUrl,
    this.preparationTime,
    this.isVegetarian = false,
    this.isSpicy = false,
    this.isAvailable = true,
    this.rating = 0.0,
    this.createdAt,
    this.updatedAt,
  });

  factory MenuItem.fromJson(Map<String, dynamic> json) {
    return MenuItem(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      category: json['category'],
      price: (json['price'] as num).toDouble(),
      imageUrl: json['image_url'],
      preparationTime: json['preparation_time'],
      isVegetarian: json['is_vegetarian'] ?? false,
      isSpicy: json['is_spicy'] ?? false,
      isAvailable: json['is_available'] ?? true,
      rating: (json['rating'] as num?)?.toDouble() ?? 0.0,
      createdAt: json['created_at'] != null ? DateTime.parse(json['created_at']) : null,
      updatedAt: json['updated_at'] != null ? DateTime.parse(json['updated_at']) : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'category': category,
      'price': price,
      'image_url': imageUrl,
      'preparation_time': preparationTime,
      'is_vegetarian': isVegetarian,
      'is_spicy': isSpicy,
      'is_available': isAvailable,
      'rating': rating,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }
}