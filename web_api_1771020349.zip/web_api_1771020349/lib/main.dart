import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/login_screen.dart';
import 'screens/menu_screen.dart';
import 'screens/admin_dashboard.dart';
import 'services/api_service.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Restaurant App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.orange),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkAuthStatus();
  }

  Future<void> _checkAuthStatus() async {
    // Add a small delay for splash effect
    await Future.delayed(const Duration(seconds: 2));
    
    // Check if server is running first
    final isServerRunning = await ApiService.checkServerConnection();
    if (!isServerRunning) {
      // Show error and go to login anyway
      print('Server not running, but continuing to login screen');
    }
    
    final token = await ApiService.getToken();
    
    if (mounted) {
      if (token != null && token != 'fake-jwt-token-for-testing') {
        try {
          // Get current user to check role
          final user = await ApiService.getCurrentUser();
          
          print('🔍 Current user email: ${user.email}'); // Debug log
          
          if (user.email == 'admin@restaurant.com') {
            print('✅ ADMIN AUTO-LOGIN - Going to Admin Dashboard'); // Debug log
            // Admin user, go to admin dashboard
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (context) => const AdminDashboard()),
            );
          } else {
            print('👤 USER AUTO-LOGIN - Going to Menu Screen'); // Debug log
            // Regular user, go to menu screen
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (context) => const MenuScreen()),
            );
          }
        } catch (e) {
          print('❌ Token validation failed: $e'); // Debug log
          // Token invalid, go to login
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => const LoginScreen()),
          );
        }
      } else {
        print('🔑 No valid token - Going to Login Screen'); // Debug log
        // User is not logged in, go to login screen
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => const LoginScreen()),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.orange,
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.restaurant,
              size: 100,
              color: Colors.white,
            ),
            SizedBox(height: 24),
            Text(
              'Restaurant App',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 16),
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}