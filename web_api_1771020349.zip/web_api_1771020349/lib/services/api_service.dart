import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/menu_item.dart';
import '../models/user.dart';

class ApiService {
  static const String baseUrl = 'http://localhost:8080/api';
  
  // Get stored token
  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }
  
  // Save token
  static Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
  }
  
  // Remove token
  static Future<void> removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
  }
  
  // Get headers with auth token
  static Future<Map<String, String>> getHeaders() async {
    final token = await getToken();
    final headers = {
      'Content-Type': 'application/json',
    };
    
    if (token != null) {
      headers['Authorization'] = 'Bearer $token';
    }
    
    return headers;
  }
  
  // Login
  static Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      print('Attempting to login with: $email');
      print('API URL: $baseUrl/auth/login');
      
      final response = await http.post(
        Uri.parse('$baseUrl/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'email': email,
          'password': password,
        }),
      ).timeout(Duration(seconds: 10));
      
      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          await saveToken(data['data']['token']);
          return data;
        } else {
          throw Exception(data['message'] ?? 'Login failed');
        }
      } else {
        try {
          final error = jsonDecode(response.body);
          throw Exception(error['message'] ?? 'Login failed');
        } catch (e) {
          throw Exception('Server error: ${response.statusCode}');
        }
      }
    } catch (e) {
      print('Login error: $e');
      if (e.toString().contains('TimeoutException')) {
        throw Exception('Connection timeout. Please check if the server is running.');
      } else if (e.toString().contains('SocketException')) {
        throw Exception('Cannot connect to server. Please check if the API server is running on localhost:8080');
      } else {
        throw Exception('Login failed: ${e.toString()}');
      }
    }
  }
  
  // Register
  static Future<Map<String, dynamic>> register({
    required String email,
    required String password,
    required String fullName,
    String? phoneNumber,
    String? address,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'email': email,
        'password': password,
        'full_name': fullName,
        'phone_number': phoneNumber,
        'address': address,
      }),
    );
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['success']) {
        return data;
      } else {
        throw Exception(data['message'] ?? 'Registration failed');
      }
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Registration failed');
    }
  }
  
  // Get current user
  static Future<User> getCurrentUser() async {
    final headers = await getHeaders();
    final response = await http.get(
      Uri.parse('$baseUrl/auth/me'),
      headers: headers,
    );
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['success']) {
        return User.fromJson(data['data']);
      } else {
        throw Exception(data['message'] ?? 'Failed to get user');
      }
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to get user');
    }
  }
  
  // Get menu items
  static Future<List<MenuItem>> getMenuItems({
    int page = 1,
    int limit = 20,
    String? search,
    String? category,
    bool? vegetarianOnly,
    bool? spicyOnly,
    bool availableOnly = true,
  }) async {
    final queryParams = <String, String>{
      'page': page.toString(),
      'limit': limit.toString(),
    };
    
    if (search != null && search.isNotEmpty) {
      queryParams['search'] = search;
    }
    
    if (category != null && category.isNotEmpty) {
      queryParams['category'] = category;
    }
    
    if (vegetarianOnly != null) {
      queryParams['vegetarian_only'] = vegetarianOnly.toString();
    }
    
    if (spicyOnly != null) {
      queryParams['spicy_only'] = spicyOnly.toString();
    }
    
    if (availableOnly) {
      queryParams['available_only'] = 'true';
    }
    
    final uri = Uri.parse('$baseUrl/menu-items').replace(queryParameters: queryParams);
    final response = await http.get(uri);
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['success']) {
        final List<dynamic> itemsJson = data['data'];
        return itemsJson.map((json) => MenuItem.fromJson(json)).toList();
      } else {
        throw Exception(data['message'] ?? 'Failed to get menu items');
      }
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to get menu items');
    }
  }
  
  // Get menu item by ID
  static Future<MenuItem> getMenuItem(int id) async {
    final response = await http.get(
      Uri.parse('$baseUrl/menu-items/$id'),
    );
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['success']) {
        return MenuItem.fromJson(data['data']);
      } else {
        throw Exception(data['message'] ?? 'Failed to get menu item');
      }
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to get menu item');
    }
  }
  
  // Search menu items
  static Future<List<MenuItem>> searchMenuItems(String query, {String? category}) async {
    final queryParams = <String, String>{
      'q': query,
    };
    
    if (category != null && category.isNotEmpty) {
      queryParams['category'] = category;
    }
    
    final uri = Uri.parse('$baseUrl/menu-items/search').replace(queryParameters: queryParams);
    final response = await http.get(uri);
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['success']) {
        final List<dynamic> itemsJson = data['data'];
        return itemsJson.map((json) => MenuItem.fromJson(json)).toList();
      } else {
        throw Exception(data['message'] ?? 'Failed to search menu items');
      }
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to search menu items');
    }
  }
  
  // Get customers (admin only)
  static Future<List<Map<String, dynamic>>> getCustomers() async {
    final headers = await getHeaders();
    final response = await http.get(
      Uri.parse('$baseUrl/customers'),
      headers: headers,
    );
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['success']) {
        return List<Map<String, dynamic>>.from(data['data']);
      } else {
        throw Exception(data['message'] ?? 'Failed to get customers');
      }
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to get customers');
    }
  }
  
  // Update customer
  static Future<void> updateCustomer(int id, {String? fullName, String? phoneNumber, String? address}) async {
    final headers = await getHeaders();
    final body = <String, dynamic>{};
    
    if (fullName != null) body['full_name'] = fullName;
    if (phoneNumber != null) body['phone_number'] = phoneNumber;
    if (address != null) body['address'] = address;
    
    final response = await http.put(
      Uri.parse('$baseUrl/customers/$id'),
      headers: headers,
      body: jsonEncode(body),
    );
    
    if (response.statusCode != 200) {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to update customer');
    }
  }
  
  // Create menu item (admin only)
  static Future<void> createMenuItem({
    required String name,
    String? description,
    required String category,
    required double price,
    int? preparationTime,
    String? imageUrl,
    bool isVegetarian = false,
    bool isSpicy = false,
    bool isAvailable = true,
  }) async {
    final headers = await getHeaders();
    final response = await http.post(
      Uri.parse('$baseUrl/menu-items'),
      headers: headers,
      body: jsonEncode({
        'name': name,
        'description': description,
        'category': category,
        'price': price,
        'preparation_time': preparationTime,
        'image_url': imageUrl,
        'is_vegetarian': isVegetarian,
        'is_spicy': isSpicy,
        'is_available': isAvailable,
      }),
    );
    
    if (response.statusCode != 200) {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to create menu item');
    }
  }
  
  // Update menu item (admin only)
  static Future<void> updateMenuItem(int id, {
    String? name,
    String? description,
    String? category,
    double? price,
    int? preparationTime,
    String? imageUrl,
    bool? isVegetarian,
    bool? isSpicy,
    bool? isAvailable,
  }) async {
    final headers = await getHeaders();
    final body = <String, dynamic>{};
    
    if (name != null) body['name'] = name;
    if (description != null) body['description'] = description;
    if (category != null) body['category'] = category;
    if (price != null) body['price'] = price;
    if (preparationTime != null) body['preparation_time'] = preparationTime;
    if (imageUrl != null) body['image_url'] = imageUrl;
    if (isVegetarian != null) body['is_vegetarian'] = isVegetarian;
    if (isSpicy != null) body['is_spicy'] = isSpicy;
    if (isAvailable != null) body['is_available'] = isAvailable;
    
    final response = await http.put(
      Uri.parse('$baseUrl/menu-items/$id'),
      headers: headers,
      body: jsonEncode(body),
    );
    
    if (response.statusCode != 200) {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to update menu item');
    }
  }
  
  // Delete menu item (admin only)
  static Future<void> deleteMenuItem(int id) async {
    final headers = await getHeaders();
    final response = await http.delete(
      Uri.parse('$baseUrl/menu-items/$id'),
      headers: headers,
    );
    
    if (response.statusCode != 200) {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to delete menu item');
    }
  }
  
  // Get tables
  static Future<List<Map<String, dynamic>>> getTables({bool availableOnly = false}) async {
    final uri = availableOnly 
        ? Uri.parse('$baseUrl/tables?available_only=true')
        : Uri.parse('$baseUrl/tables');
    
    final response = await http.get(uri);
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['success']) {
        return List<Map<String, dynamic>>.from(data['data']);
      } else {
        throw Exception(data['message'] ?? 'Failed to get tables');
      }
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to get tables');
    }
  }
  
  // Create table (admin only)
  static Future<void> createTable({required String tableNumber, required int capacity}) async {
    final headers = await getHeaders();
    final response = await http.post(
      Uri.parse('$baseUrl/tables'),
      headers: headers,
      body: jsonEncode({
        'table_number': tableNumber,
        'capacity': capacity,
      }),
    );
    
    if (response.statusCode != 200) {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to create table');
    }
  }
  
  // Update table (admin only)
  static Future<void> updateTable(int id, {String? tableNumber, int? capacity, bool? isAvailable}) async {
    final headers = await getHeaders();
    final body = <String, dynamic>{};
    
    if (tableNumber != null) body['table_number'] = tableNumber;
    if (capacity != null) body['capacity'] = capacity;
    if (isAvailable != null) body['is_available'] = isAvailable;
    
    final response = await http.put(
      Uri.parse('$baseUrl/tables/$id'),
      headers: headers,
      body: jsonEncode(body),
    );
    
    if (response.statusCode != 200) {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to update table');
    }
  }
  
  // Delete table (admin only)
  static Future<void> deleteTable(int id) async {
    final headers = await getHeaders();
    final response = await http.delete(
      Uri.parse('$baseUrl/tables/$id'),
      headers: headers,
    );
    
    if (response.statusCode != 200) {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to delete table');
    }
  }
  
  // Confirm reservation (admin only)
  static Future<void> confirmReservation(int id, String tableNumber) async {
    final headers = await getHeaders();
    final response = await http.put(
      Uri.parse('$baseUrl/reservations/$id/confirm'),
      headers: headers,
      body: jsonEncode({
        'table_number': tableNumber,
      }),
    );
    
    if (response.statusCode != 200) {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to confirm reservation');
    }
  }
  
  // Cancel reservation (admin only)
  static Future<void> cancelReservation(int id) async {
    final headers = await getHeaders();
    final response = await http.put(
      Uri.parse('$baseUrl/reservations/$id/cancel'),
      headers: headers,
    );
    
    if (response.statusCode != 200) {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to cancel reservation');
    }
  }
  
  // Get reservations (admin only)
  static Future<List<Map<String, dynamic>>> getReservations() async {
    final headers = await getHeaders();
    final response = await http.get(
      Uri.parse('$baseUrl/reservations'),
      headers: headers,
    );
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['success']) {
        return List<Map<String, dynamic>>.from(data['data']);
      } else {
        throw Exception(data['message'] ?? 'Failed to get reservations');
      }
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to get reservations');
    }
  }
  
  // Create reservation (customer)
  static Future<void> createReservation({
    required String customerName,
    required String phoneNumber,
    required DateTime reservationDateTime,
    required int numberOfGuests,
    required int tableId,
    String? specialRequests,
  }) async {
    final headers = await getHeaders();
    final response = await http.post(
      Uri.parse('$baseUrl/reservations'),
      headers: headers,
      body: jsonEncode({
        'customer_name': customerName,
        'phone_number': phoneNumber,
        'reservation_date': reservationDateTime.toIso8601String(),
        'number_of_guests': numberOfGuests,
        'table_id': tableId,
        'special_requests': specialRequests,
      }),
    );
    
    if (response.statusCode != 200) {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to create reservation');
    }
  }
  
  // Check server connection
  static Future<bool> checkServerConnection() async {
    try {
      final response = await http.get(
        Uri.parse('http://localhost:8080/health'),
      ).timeout(Duration(seconds: 5));
      
      return response.statusCode == 200;
    } catch (e) {
      print('Server connection check failed: $e');
      return false;
    }
  }
  
  // Logout
  static Future<void> logout() async {
    await removeToken();
  }
}