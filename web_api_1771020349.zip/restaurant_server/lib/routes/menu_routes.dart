import 'dart:convert';
import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';
import '../database/database.dart';
import '../models/menu_item.dart';

class MenuRoutes {
  final Router router = Router();
  
  MenuRoutes() {
    router.get('/', _getMenuItems);
    router.get('/<id>', _getMenuItem);
  }
  
  Future<Response> _getMenuItems(Request request) async {
    try {
      print('🍽️ Getting menu items...');
      
      final uri = request.requestedUri;
      final page = int.tryParse(uri.queryParameters['page'] ?? '1') ?? 1;
      final limit = int.tryParse(uri.queryParameters['limit'] ?? '20') ?? 20;
      final offset = (page - 1) * limit;
      
      final search = uri.queryParameters['search'];
      final category = uri.queryParameters['category'];
      final vegetarianOnly = uri.queryParameters['vegetarian_only'] == 'true';
      final spicyOnly = uri.queryParameters['spicy_only'] == 'true';
      final availableOnly = uri.queryParameters['available_only'] == 'true';
      
      String query = 'SELECT * FROM menu_items WHERE 1=1';
      List<dynamic> params = [];
      
      if (search != null && search.isNotEmpty) {
        query += ' AND (name LIKE ? OR description LIKE ?)';
        params.addAll(['%$search%', '%$search%']);
      }
      
      if (category != null && category.isNotEmpty) {
        query += ' AND category = ?';
        params.add(category);
      }
      
      if (vegetarianOnly) {
        query += ' AND is_vegetarian = 1';
      }
      
      if (spicyOnly) {
        query += ' AND is_spicy = 1';
      }
      
      if (availableOnly) {
        query += ' AND is_available = 1';
      }
      
      query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
      params.addAll([limit, offset]);
      
      final result = await Database.connection.query(query, params);
      
      // Get total count
      String countQuery = 'SELECT COUNT(*) as total FROM menu_items WHERE 1=1';
      List<dynamic> countParams = [];
      
      if (search != null && search.isNotEmpty) {
        countQuery += ' AND (name LIKE ? OR description LIKE ?)';
        countParams.addAll(['%$search%', '%$search%']);
      }
      
      if (category != null && category.isNotEmpty) {
        countQuery += ' AND category = ?';
        countParams.add(category);
      }
      
      if (vegetarianOnly) {
        countQuery += ' AND is_vegetarian = 1';
      }
      
      if (spicyOnly) {
        countQuery += ' AND is_spicy = 1';
      }
      
      if (availableOnly) {
        countQuery += ' AND is_available = 1';
      }
      
      final countResult = await Database.connection.query(countQuery, countParams);
      
      final menuItems = result.map((row) => MenuItem.fromMap(row.fields).toJson()).toList();
      final total = countResult.first['total'] as int;
      
      print('✅ Found ${menuItems.length} menu items');
      
      return Response.ok(
        jsonEncode({
          'success': true,
          'data': menuItems,
          'pagination': {
            'page': page,
            'limit': limit,
            'total': total,
            'pages': (total / limit).ceil(),
          },
        }),
        headers: {'content-type': 'application/json'},
      );
    } catch (e) {
      print('❌ Menu items error: $e');
      return Response(500,
        headers: {'content-type': 'application/json'},
        body: jsonEncode({
          'success': false,
          'message': 'Failed to get menu items: ${e.toString()}'
        })
      );
    }
  }
  
  Future<Response> _getMenuItem(Request request) async {
    try {
      final id = int.tryParse(request.params['id']!);
      if (id == null) {
        return Response(400,
          headers: {'content-type': 'application/json'},
          body: jsonEncode({
            'success': false,
            'message': 'Invalid menu item ID'
          })
        );
      }
      
      final result = await Database.connection.query(
        'SELECT * FROM menu_items WHERE id = ?',
        [id]
      );
      
      if (result.isEmpty) {
        return Response(404,
          headers: {'content-type': 'application/json'},
          body: jsonEncode({
            'success': false,
            'message': 'Menu item not found'
          })
        );
      }
      
      final menuItem = MenuItem.fromMap(result.first.fields);
      
      return Response.ok(
        jsonEncode({
          'success': true,
          'data': menuItem.toJson(),
        }),
        headers: {'content-type': 'application/json'},
      );
    } catch (e) {
      print('❌ Menu item error: $e');
      return Response(500,
        headers: {'content-type': 'application/json'},
        body: jsonEncode({
          'success': false,
          'message': 'Failed to get menu item: ${e.toString()}'
        })
      );
    }
  }
}