import 'dart:convert';
import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';
import 'package:dart_jsonwebtoken/dart_jsonwebtoken.dart';
import 'package:dotenv/dotenv.dart';
import '../database/database.dart';
import '../models/customer.dart';

class AuthRoutes {
  final Router router = Router();
  final _env = DotEnv(includePlatformEnvironment: true)..load();
  
  AuthRoutes() {
    router.post('/login', _login);
    router.post('/register', _register);
  }
  
  Future<Response> _login(Request request) async {
    try {
      print('🔐 Login endpoint called');
      
      final body = await request.readAsString();
      print('📝 Request body: $body');
      
      final data = jsonDecode(body) as Map<String, dynamic>;
      final email = data['email'] as String?;
      final password = data['password'] as String?;
      
      print('👤 Login attempt: $email');
      
      if (email == null || password == null) {
        return Response(400,
          headers: {'content-type': 'application/json'},
          body: jsonEncode({
            'success': false,
            'message': 'Email and password are required'
          })
        );
      }
      
      // Find user in database
      print('🔍 Querying database for user: $email');
      final result = await Database.connection.query(
        'SELECT * FROM customers WHERE email = ? AND is_active = 1',
        [email]
      );
      
      print('📊 Query result count: ${result.length}');
      
      if (result.isEmpty) {
        return Response(401,
          headers: {'content-type': 'application/json'},
          body: jsonEncode({
            'success': false,
            'message': 'Invalid credentials - user not found'
          })
        );
      }
      
      final user = result.first.fields;
      print('✅ Found user: ${user['email']}');
      
      // Simple password check (you can add bcrypt later)
      if (password != user['password']) {
        return Response(401,
          headers: {'content-type': 'application/json'},
          body: jsonEncode({
            'success': false,
            'message': 'Invalid credentials - wrong password'
          })
        );
      }
      
      // Generate JWT token
      final jwt = JWT({
        'user_id': user['id'],
        'email': user['email'],
        'is_admin': email == 'admin@restaurant.com',
        'iat': DateTime.now().millisecondsSinceEpoch ~/ 1000,
        'exp': DateTime.now().add(Duration(days: 7)).millisecondsSinceEpoch ~/ 1000,
      });
      
      final token = jwt.sign(SecretKey(_env['JWT_SECRET']!));
      
      final customer = Customer.fromMap(user);
      
      print('🎉 Login successful for: $email');
      
      return Response.ok(
        jsonEncode({
          'success': true,
          'message': 'Login successful',
          'data': {
            'token': token,
            'user': customer.toJson(),
            'student_id': '1771020349',
          },
        }),
        headers: {'content-type': 'application/json'},
      );
    } catch (e) {
      print('❌ Login error: $e');
      return Response(500,
        headers: {'content-type': 'application/json'},
        body: jsonEncode({
          'success': false,
          'message': 'Login failed: ${e.toString()}'
        })
      );
    }
  }
  
  Future<Response> _register(Request request) async {
    try {
      final body = await request.readAsString();
      final data = jsonDecode(body) as Map<String, dynamic>;
      
      if (data['email'] == null || data['password'] == null || data['full_name'] == null) {
        return Response(400, 
          headers: {'content-type': 'application/json'},
          body: jsonEncode({
            'success': false,
            'message': 'Email, password, and full_name are required'
          })
        );
      }
      
      final email = data['email'] as String;
      final password = data['password'] as String;
      final fullName = data['full_name'] as String;
      final phoneNumber = data['phone_number'] as String?;
      final address = data['address'] as String?;
      
      // Check if email already exists
      final existingUser = await Database.connection.query(
        'SELECT id FROM customers WHERE email = ?',
        [email]
      );
      
      if (existingUser.isNotEmpty) {
        return Response(400,
          headers: {'content-type': 'application/json'},
          body: jsonEncode({
            'success': false,
            'message': 'Email already exists'
          })
        );
      }
      
      // Insert new customer
      final result = await Database.connection.query(
        '''INSERT INTO customers (email, password, full_name, phone_number, address) 
           VALUES (?, ?, ?, ?, ?)''',
        [email, password, fullName, phoneNumber, address]
      );
      
      final customerId = result.insertId!;
      
      // Get created customer
      final customerResult = await Database.connection.query(
        'SELECT * FROM customers WHERE id = ?',
        [customerId]
      );
      
      final customer = Customer.fromMap(customerResult.first.fields);
      
      return Response.ok(
        jsonEncode({
          'success': true,
          'message': 'Customer registered successfully',
          'data': customer.toJson(),
        }),
        headers: {'content-type': 'application/json'},
      );
    } catch (e) {
      print('Register error: $e');
      return Response(500,
        headers: {'content-type': 'application/json'},
        body: jsonEncode({
          'success': false,
          'message': 'Registration failed: ${e.toString()}'
        })
      );
    }
  }
}