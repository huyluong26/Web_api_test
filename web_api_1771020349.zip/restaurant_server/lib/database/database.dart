import 'package:mysql1/mysql1.dart';
import 'package:dotenv/dotenv.dart';

class Database {
  static MySqlConnection? _connection;
  static late DotEnv _env;
  
  static Future<void> initialize() async {
    _env = DotEnv(includePlatformEnvironment: true)..load();
    
    final settings = ConnectionSettings(
      host: _env['DB_HOST'] ?? 'localhost',
      port: int.parse(_env['DB_PORT'] ?? '3306'),
      user: _env['DB_USER'] ?? 'root',
      password: _env['DB_PASSWORD'] ?? '',
      db: _env['DB_NAME'] ?? 'db_exam_1771020349',
    );
    
    print('Connecting to MySQL server...');
    print('Host: ${settings.host}');
    print('Port: ${settings.port}');
    print('Database: ${settings.db}');
    print('User: ${settings.user}');
    
    try {
      _connection = await MySqlConnection.connect(settings);
      print('✅ Database connected successfully to ${settings.host}');
    } catch (e) {
      print('❌ Database connection failed: $e');
      print('Please check:');
      print('1. MySQL server is running on ${settings.host}');
      print('2. Database ${settings.db} exists');
      print('3. User ${settings.user} has access permissions');
      rethrow;
    }
  }
  
  static MySqlConnection get connection {
    if (_connection == null) {
      throw Exception('Database not initialized');
    }
    return _connection!;
  }
  
  static Future<void> close() async {
    await _connection?.close();
  }
}