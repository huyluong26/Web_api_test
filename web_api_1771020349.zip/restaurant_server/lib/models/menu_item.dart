class MenuItem {
  final int? id;
  final String name;
  final String? description;
  final String category;
  final double price;
  final String? imageUrl;
  final int? preparationTime;
  final bool isVegetarian;
  final bool isSpicy;
  final bool isAvailable;
  final double rating;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  
  MenuItem({
    this.id,
    required this.name,
    this.description,
    required this.category,
    required this.price,
    this.imageUrl,
    this.preparationTime,
    this.isVegetarian = false,
    this.isSpicy = false,
    this.isAvailable = true,
    this.rating = 0.0,
    this.createdAt,
    this.updatedAt,
  });
  
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'category': category,
      'price': price,
      'image_url': imageUrl,
      'preparation_time': preparationTime,
      'is_vegetarian': isVegetarian,
      'is_spicy': isSpicy,
      'is_available': isAvailable,
      'rating': rating,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }
  
  factory MenuItem.fromMap(Map<String, dynamic> map) {
    return MenuItem(
      id: map['id'],
      name: map['name'],
      description: map['description'],
      category: map['category'],
      price: (map['price'] as num).toDouble(),
      imageUrl: map['image_url'],
      preparationTime: map['preparation_time'],
      isVegetarian: map['is_vegetarian'] == 1,
      isSpicy: map['is_spicy'] == 1,
      isAvailable: map['is_available'] == 1,
      rating: (map['rating'] as num?)?.toDouble() ?? 0.0,
      createdAt: map['created_at'],
      updatedAt: map['updated_at'],
    );
  }
}