class Customer {
  final int? id;
  final String email;
  final String password;
  final String fullName;
  final String? phoneNumber;
  final String? address;
  final int loyaltyPoints;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final bool isActive;
  
  Customer({
    this.id,
    required this.email,
    required this.password,
    required this.fullName,
    this.phoneNumber,
    this.address,
    this.loyaltyPoints = 0,
    this.createdAt,
    this.updatedAt,
    this.isActive = true,
  });
  
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'full_name': fullName,
      'phone_number': phoneNumber,
      'address': address,
      'loyalty_points': loyaltyPoints,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
      'is_active': isActive,
    };
  }
  
  factory Customer.fromMap(Map<String, dynamic> map) {
    return Customer(
      id: map['id'],
      email: map['email'],
      password: map['password'] ?? '',
      fullName: map['full_name'],
      phoneNumber: map['phone_number'],
      address: map['address'],
      loyaltyPoints: map['loyalty_points'] ?? 0,
      createdAt: map['created_at'],
      updatedAt: map['updated_at'],
      isActive: map['is_active'] == 1,
    );
  }
}