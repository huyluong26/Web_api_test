#!/usr/bin/env python3
import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import threading
from datetime import datetime

# In-memory storage for reservations
reservations = [
    {
        'id': 1,
        'reservation_number': 'RES0001',
        'customer_id': 1,
        'customer_name': 'John Doe',
        'phone_number': '0123456789',
        'reservation_date': '2025-01-15T19:00:00',
        'number_of_guests': 2,
        'table_id': 1,
        'table_number': None,
        'special_requests': 'Window seat please',
        'status': 'pending',
        'subtotal': 0,
        'service_charge': 0,
        'total': 0,
        'payment_status': 'pending',
        'created_at': '2025-01-13T10:00:00',
    },
    {
        'id': 2,
        'reservation_number': 'RES0002',
        'customer_id': 1,
        'customer_name': 'Jane Smith',
        'phone_number': '0987654321',
        'reservation_date': '2025-01-16T20:00:00',
        'number_of_guests': 4,
        'table_id': 2,
        'table_number': 'T02',
        'special_requests': 'Birthday celebration',
        'status': 'confirmed',
        'subtotal': 0,
        'service_charge': 0,
        'total': 0,
        'payment_status': 'pending',
        'created_at': '2025-01-13T11:00:00',
    }
]
next_reservation_id = 3

class RequestHandler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()

    def do_GET(self):
        if self.path == '/health':
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(b'OK')
        elif self.path == '/api/tables':
            self._handle_get_tables()
        elif self.path == '/api/tables?available_only=true':
            self._handle_get_available_tables()
        elif self.path == '/api/reservations':
            self._handle_get_reservations()
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == '/api/auth/login':
            self._handle_login()
        elif self.path == '/api/reservations':
            self._handle_create_reservation()
        else:
            self.send_response(404)
            self.end_headers()

    def do_PUT(self):
        if '/api/reservations/' in self.path and '/confirm' in self.path:
            self._handle_confirm_reservation()
        elif '/api/reservations/' in self.path and '/cancel' in self.path:
            self._handle_cancel_reservation()
        else:
            self.send_response(404)
            self.end_headers()

    def _handle_login(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        try:
            data = json.loads(post_data.decode('utf-8'))
            email = data.get('email')
            password = data.get('password')
            
            print(f"Login attempt: {email}")
            
            if email == 'admin@restaurant.com' and password == 'admin123':
                user_data = {
                    'id': 2,
                    'email': 'admin@restaurant.com',
                    'full_name': 'Admin User',
                    'phone_number': '0987654321',
                    'address': 'Admin Office',
                    'loyalty_points': 0,
                    'is_active': True,
                }
            elif email == 'john.doe@email.com' and password == 'password123':
                user_data = {
                    'id': 1,
                    'email': 'john.doe@email.com',
                    'full_name': 'John Doe',
                    'phone_number': '0123456789',
                    'address': '123 Main St',
                    'loyalty_points': 150,
                    'is_active': True,
                }
            else:
                self.send_response(401)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                response = {'success': False, 'message': 'Invalid credentials'}
                self.wfile.write(json.dumps(response).encode('utf-8'))
                return
            
            response = {
                'success': True,
                'message': 'Login successful',
                'data': {
                    'token': 'fake-jwt-token-for-testing',
                    'user': user_data,
                    'student_id': '1771020349',
                },
            }
            
            print(f"Sending response: {json.dumps(response)}")
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps(response).encode('utf-8'))
            
        except Exception as e:
            print(f"Error: {e}")
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {'success': False, 'message': str(e)}
            self.wfile.write(json.dumps(response).encode('utf-8'))

    def _handle_get_tables(self):
        tables = [
            {'id': 1, 'table_number': 'T01', 'capacity': 2, 'is_available': True},
            {'id': 2, 'table_number': 'T02', 'capacity': 4, 'is_available': True},
            {'id': 3, 'table_number': 'T03', 'capacity': 6, 'is_available': True},
            {'id': 4, 'table_number': 'T04', 'capacity': 2, 'is_available': True},
            {'id': 5, 'table_number': 'T05', 'capacity': 4, 'is_available': False},
        ]
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        response = {'success': True, 'data': tables}
        self.wfile.write(json.dumps(response).encode('utf-8'))

    def _handle_get_available_tables(self):
        tables = [
            {'id': 1, 'table_number': 'T01', 'capacity': 2, 'is_available': True},
            {'id': 2, 'table_number': 'T02', 'capacity': 4, 'is_available': True},
            {'id': 3, 'table_number': 'T03', 'capacity': 6, 'is_available': True},
            {'id': 4, 'table_number': 'T04', 'capacity': 2, 'is_available': True},
        ]
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        response = {'success': True, 'data': tables}
        self.wfile.write(json.dumps(response).encode('utf-8'))

    def _handle_create_reservation(self):
        global next_reservation_id
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        try:
            data = json.loads(post_data.decode('utf-8'))
            
            reservation = {
                'id': next_reservation_id,
                'reservation_number': f'RES{next_reservation_id:04d}',
                'customer_id': 1,  # Default customer ID
                'customer_name': data['customer_name'],
                'phone_number': data['phone_number'],
                'reservation_date': data['reservation_date'],
                'number_of_guests': data['number_of_guests'],
                'table_id': data['table_id'],
                'table_number': None,  # Will be assigned when confirmed
                'special_requests': data.get('special_requests'),
                'status': 'pending',
                'subtotal': 0,
                'service_charge': 0,
                'total': 0,
                'payment_status': 'pending',
                'created_at': datetime.now().isoformat(),
            }
            
            reservations.append(reservation)
            next_reservation_id += 1
            
            print(f"New reservation created: {reservation}")
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {'success': True, 'message': 'Reservation created successfully', 'data': reservation}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            
        except Exception as e:
            print(f"Error creating reservation: {e}")
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {'success': False, 'message': str(e)}
            self.wfile.write(json.dumps(response).encode('utf-8'))

    def _handle_get_reservations(self):
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        response = {'success': True, 'data': reservations}
        self.wfile.write(json.dumps(response).encode('utf-8'))

    def _handle_confirm_reservation(self):
        try:
            # Extract reservation ID from path
            path_parts = self.path.split('/')
            reservation_id = int(path_parts[3])
            
            # Get table number from request body
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length > 0:
                post_data = self.rfile.read(content_length)
                data = json.loads(post_data.decode('utf-8'))
                table_number = data.get('table_number')
            else:
                table_number = f'T{reservation_id:02d}'  # Default table number
            
            # Find and update reservation
            for reservation in reservations:
                if reservation['id'] == reservation_id:
                    reservation['status'] = 'confirmed'
                    reservation['table_number'] = table_number
                    print(f"Reservation {reservation_id} confirmed with table {table_number}")
                    break
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {'success': True, 'message': 'Reservation confirmed'}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            
        except Exception as e:
            print(f"Error confirming reservation: {e}")
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {'success': False, 'message': str(e)}
            self.wfile.write(json.dumps(response).encode('utf-8'))

    def _handle_cancel_reservation(self):
        try:
            # Extract reservation ID from path
            path_parts = self.path.split('/')
            reservation_id = int(path_parts[3])
            
            # Find and update reservation
            for reservation in reservations:
                if reservation['id'] == reservation_id:
                    reservation['status'] = 'cancelled'
                    print(f"Reservation {reservation_id} cancelled")
                    break
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {'success': True, 'message': 'Reservation cancelled'}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            
        except Exception as e:
            print(f"Error cancelling reservation: {e}")
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {'success': False, 'message': str(e)}
            self.wfile.write(json.dumps(response).encode('utf-8'))

def run_server():
    server = HTTPServer(('localhost', 8080), RequestHandler)
    print('🚀 Simple test server running at http://localhost:8080')
    print('📧 Test accounts:')
    print('   Admin: admin@restaurant.com / admin123')
    print('   User:  john.doe@email.com / password123')
    print('📋 Available endpoints:')
    print('   POST /api/auth/login')
    print('   GET  /api/tables')
    print('   POST /api/reservations')
    print('   GET  /api/reservations')
    print('   PUT  /api/reservations/{id}/confirm')
    print('   PUT  /api/reservations/{id}/cancel')
    print('Press Ctrl+C to stop')
    server.serve_forever()

if __name__ == '__main__':
    run_server()