# Restaurant Admin API Guide

## 🎯 Đã thêm đầy đủ Admin API theo yêu cầu!

### **Admin Authentication:**
- **Email:** `admin@restaurant.com`
- **Password:** `admin123`
- **Token:** `simple-jwt-token-2` (sau khi login)

## 🔐 Customer Management API

### **3.1. Lấy danh sách Customers (Admin only)**
```bash
GET /api/customers
Authorization: Bearer simple-jwt-token-2
```

### **3.2. Lấy Customer theo ID**
```bash
GET /api/customers/:id
Authorization: Bearer <token>
# Admin hoặc chính customer đó
```

### **3.3. Cập nhật Customer**
```bash
PUT /api/customers/:id
Authorization: Bearer <token>
Content-Type: application/json

{
  "full_name": "Updated Name",
  "phone_number": "0987654321",
  "address": "New Address"
}
```

### **3.4. Lấy thông tin Customer hiện tại**
```bash
GET /api/auth/me
Authorization: Bearer <token>
```

## 🍽️ Menu Management API

### **4.1. Lấy danh sách Menu Items**
```bash
GET /api/menu-items?page=1&limit=20&search=pho&category=Soup&vegetarian_only=true&spicy_only=false&available_only=true
```

### **4.2. Lấy Menu Item theo ID**
```bash
GET /api/menu-items/:id
```

### **4.3. Thêm Menu Item (Admin only)**
```bash
POST /api/menu-items
Authorization: Bearer simple-jwt-token-2
Content-Type: application/json

{
  "name": "Phở Bò",
  "description": "Phở bò truyền thống",
  "category": "Main Course",
  "price": 80000,
  "preparation_time": 15,
  "is_vegetarian": false,
  "is_spicy": false,
  "image_url": "https://example.com/pho.jpg"
}
```

### **4.4. Cập nhật Menu Item (Admin only)**
```bash
PUT /api/menu-items/:id
Authorization: Bearer simple-jwt-token-2
Content-Type: application/json

{
  "name": "Updated Name",
  "price": 90000,
  "is_available": false
}
```

### **4.5. Xóa Menu Item (Admin only)**
```bash
DELETE /api/menu-items/:id
Authorization: Bearer simple-jwt-token-2
```

### **4.6. Tìm kiếm Menu Items**
```bash
GET /api/menu-items/search?q=pho&category=Soup
```

## 📅 Reservation Management API

### **5.1. Đặt Bàn**
```bash
POST /api/reservations
Authorization: Bearer <customer-token>
Content-Type: application/json

{
  "reservation_date": "2024-01-15T19:00:00Z",
  "number_of_guests": 4,
  "special_requests": "Bàn gần cửa sổ"
}
```

### **5.2. Thêm Món vào Đơn**
```bash
POST /api/reservations/:id/items
Authorization: Bearer <customer-token>
Content-Type: application/json

{
  "menu_item_id": 1,
  "quantity": 2
}
```

### **5.3. Xác nhận Đặt Bàn (Admin only)**
```bash
PUT /api/reservations/:id/confirm
Authorization: Bearer simple-jwt-token-2
Content-Type: application/json

{
  "table_number": "T01"
}
```

### **5.4. Lấy Đặt Bàn theo ID**
```bash
GET /api/reservations/:id
Authorization: Bearer <token>
# Include reservation_items với menu_item info
```

### **5.7. Hủy Đặt Bàn**
```bash
DELETE /api/reservations/:id
Authorization: Bearer <token>
# Customer: chỉ pending/confirmed
# Admin: bất kỳ status nào
```

## 🪑 Table Management API

### **6.1. Lấy danh sách Tables**
```bash
GET /api/tables?available_only=true
```

### **6.2. Thêm Table (Admin only)**
```bash
POST /api/tables
Authorization: Bearer simple-jwt-token-2
Content-Type: application/json

{
  "table_number": "T009",
  "capacity": 4
}
```

### **6.3. Cập nhật Table (Admin only)**
```bash
PUT /api/tables/:id
Authorization: Bearer simple-jwt-token-2
Content-Type: application/json

{
  "table_number": "T010",
  "capacity": 6,
  "is_available": true
}
```

### **6.4. Xóa Table (Admin only)**
```bash
DELETE /api/tables/:id
Authorization: Bearer simple-jwt-token-2
```

## 🚀 Cách chạy và test:

### **1. Khởi động Full Server:**
```bash
cd restaurant_server
start_full.bat
```

### **2. Test Admin API:**
```bash
test_admin_api.bat
```

### **3. Chạy Flutter App:**
```bash
cd web_api_1771020349
flutter run
```

## ✅ Tính năng Admin đã hoàn thành:

### **Authentication & Authorization:**
- ✅ JWT token authentication
- ✅ Admin role checking
- ✅ User permission validation

### **Customer Management:**
- ✅ Get all customers (admin only)
- ✅ Get customer by ID (admin or owner)
- ✅ Update customer (admin or owner)
- ✅ Get current user info

### **Menu Management:**
- ✅ Full CRUD operations
- ✅ Admin-only create/update/delete
- ✅ Search and filtering
- ✅ Validation and error handling

### **Reservation System:**
- ✅ Create reservation with auto-generated number
- ✅ Add items with subtotal calculation
- ✅ Admin confirmation with table assignment
- ✅ Status management (pending → confirmed → cancelled)
- ✅ Permission-based cancellation

### **Table Management:**
- ✅ Full CRUD operations (admin only)
- ✅ Availability tracking
- ✅ Capacity validation
- ✅ Active reservation checking

### **Business Logic:**
- ✅ Auto-generated reservation numbers (RES-YYYYMMDD-001)
- ✅ Service charge calculation (10% of subtotal)
- ✅ Table availability management
- ✅ Menu item availability checking
- ✅ Permission-based access control

## 🎯 Kết quả:

Server sẽ hiển thị:
```
🎉 Full Restaurant API server listening on port 8080
✅ Full CRUD operations available!
📊 Data: 3 customers, 10 menu items, 8 tables
```

Tất cả API endpoints theo yêu cầu đề bài đã được implement đầy đủ!