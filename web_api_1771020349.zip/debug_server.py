#!/usr/bin/env python3
import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime

# Sample reservations for testing
reservations = [
    {
        'id': 1,
        'reservation_number': 'RES0001',
        'customer_id': 1,
        'customer_name': 'John Doe',
        'phone_number': '0123456789',
        'reservation_date': '2025-01-15T19:00:00',
        'number_of_guests': 2,
        'table_id': 1,
        'table_number': None,
        'special_requests': 'Window seat please',
        'status': 'pending',
        'subtotal': 0,
        'service_charge': 0,
        'total': 0,
        'payment_status': 'pending',
        'created_at': '2025-01-13T10:00:00',
    }
]

class DebugHandler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()

    def do_GET(self):
        print(f"GET request to: {self.path}")
        
        if self.path == '/health':
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(b'OK')
            
        elif self.path == '/api/reservations':
            print(f"Returning {len(reservations)} reservations")
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {'success': True, 'data': reservations}
            response_json = json.dumps(response)
            print(f"Response: {response_json}")
            self.wfile.write(response_json.encode('utf-8'))
            
        else:
            print(f"404 - Path not found: {self.path}")
            self.send_response(404)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {'success': False, 'message': 'Route not found'}
            self.wfile.write(json.dumps(response).encode('utf-8'))

def run_debug_server():
    server = HTTPServer(('localhost', 8080), DebugHandler)
    print('🐛 Debug server running at http://localhost:8080')
    print('Available endpoints:')
    print('  GET /health')
    print('  GET /api/reservations')
    server.serve_forever()

if __name__ == '__main__':
    run_debug_server()